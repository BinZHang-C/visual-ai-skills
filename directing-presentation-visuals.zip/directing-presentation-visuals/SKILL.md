---
name: directing-presentation-visuals
description: "Direct, preview, approve, produce, package, or validate slide-deck visuals with a default visual-first two-stage workflow, page-family coherence, representative gates, assets, alignment, and Windows PowerPoint release QA."
---

# Directing Presentation Visuals

## Outcome

Turn a communication brief into a hash-bound Visual DNA, prove it on representative pages, and deliver a fast non-editable visual preview before investing in native PowerPoint production. After explicit visual approval, hand approved contracts to the `Presentations` production layer and release only from Windows PowerPoint evidence. Temporary style names are cues, never a closed taxonomy. The 22-sample registry remains an open Gold quality floor, not a template library.

## Required sequence

```text
communication job
→ three non-editable cover directions + recommendation
→ approved VisualDirectionLock / Visual DNA
→ three non-editable representative-page renders
→ representative-page Gold gate
→ complete non-editable visual preview: slide images + PDF + montage
→ explicit VisualApprovalReceipt or declared ONE_PASS_EDITABLE override
→ SlideVisualContracts
→ DeckCoherenceContract
→ AssetEvidenceReceipts
→ native editable PPTX through Presentations
→ Windows PowerPoint PNG + PDF + montage
→ Integrity
→ rendered alignment QA
→ deck-coherence montage gate
→ Gold Visual Quality
→ safe local repair (maximum two rounds) + affected-slide rerender
→ release package
```

Do not infer a later pass from an earlier artifact. Coordinates, source code, thumbnails, optical offsets, and self-authored totals are not rendered evidence.

## Route modules

Read [modules.json](modules.json) and load only the current phase:

- Always use `core`.
- For an approved scope change, cross-session resume, repeated failure, multi-agent overlap, save/reopen/export mismatch, or a disputed delivery claim, read [delivery-governance.md](references/delivery-governance.md). Do not load it for an ordinary first pass or low-risk edit.
- For any new deck, visual-direction revision, first-version delivery, or request for faster iteration, read [two-stage-delivery.md](references/two-stage-delivery.md). Use the visual-first path unless the user explicitly requests one-pass editable production.
- For direction and slide contracts, read [style-system.md](references/style-system.md) and [page-roles.md](references/page-roles.md). Load one matching recipe only when its mechanisms fit the communication job.
- For logos, photographs, screenshots, illustrations, generated images, icons, or external sources, read [asset-truth.md](references/asset-truth.md).
- For charts, tables, metrics, processes, systems, comparisons, or analytical diagrams, read [data-graphics.md](references/data-graphics.md).
- For a client-facing office or workplace concept deck, read [office-concept-deck-joint-gate.md](references/office-concept-deck-joint-gate.md) and require a current design-director handoff before visual production. Use the office design director to own content, spatial proof and evidence boundaries; use this skill to own visual hierarchy, layout, alignment, whitespace, image grammar and rendered quality.
- For office framework acceptance, a rendered chapter-family review, continuation from a human-approved chapter, or freeze/regression work, also read [office-stage1-acceptance-baseline.md](references/office-stage1-acceptance-baseline.md). Use collaborative Mode A＋B; do not report publication acceptance.
- Before full production, montage review, visual-consistency repair, or completion, read [deck-coherence.md](references/deck-coherence.md).
- Before direction approval, representative-page approval, a quality claim, or completion, retrieve only two or three communication-fit entries from [gold-visual-baseline.json](references/gold-visual-baseline.json) and verify their fingerprints with [gold-reference-receipt.json](references/gold-reference-receipt.json). Never load, imitate, or redistribute all 22 samples.
- Before native production, read [release-pipeline.md](references/release-pipeline.md). Before validation or repair, also read [render-qa.md](references/render-qa.md).

## Direct the Visual DNA

Present exactly three non-editable cover-direction renders. State one recommendation, aesthetic ceiling, primary gain, and risk for each. After approval, lock attention, space/depth, material, type voice, hierarchy ratios, canonical ink axes, whitespace, image grammar, light/contrast, accent behavior, brand-without-logo mechanisms, and anti-rules.

Do not begin native editable production yet. Produce one rational strategy page, one relationship/process/analysis page, and one immersive climax page. They must share one DNA while differing materially in silhouette, scale, density, and behavior. Reject the direction when any applicable Gold dimension is below its floor. After the representative gate passes, complete the same non-editable visual system across the deck and deliver the Stage 1 preview package defined in [two-stage-delivery.md](references/two-stage-delivery.md).

For decks of eight or more slides, require at least two scales, two densities, two background modes, and legible opening, argument, pivot, climax, and decision closure.

## Joint gate for office concept decks

An office concept deck passes only when content and visual form pass together. The office design director must supply one audience-facing claim, project evidence, spatial consequence, visible proof, evidence boundary and chapter connection for every retained page. This skill must give that proof an appropriate page role, dominant visual object, readable scale, shared format grammar, canonical alignment and purposeful whitespace.

Do not use cards, small plan thumbnails, decorative rules, repeated text blocks or empty canvas to conceal missing spatial proof. Do not compress approved evidence merely to preserve a preferred layout. When content and composition cannot coexist, return `JOINT_GATE_REVISE` with the content gap, visual conflict and responsible owner instead of allowing either skill to pass independently.

## Lock deck coherence

Variation must occur inside one system. Before full production, bind shared invariants, page-family membership, background-mode budget, image treatment, accent policy, and planned exceptions in a `DeckCoherenceContract`.

Concept alternatives must share one page-family grammar; express their differences through subject, mood, material emphasis, or mirrored composition, not unrelated black bars, title systems, or color grades. Comparison pages inherit the analytical family instead of introducing a separate report/dashboard palette.

Inspect the complete Windows PowerPoint montage and every slide at full size. Bind `DeckCoherenceEvidence` to the direction, contract, montage, and reviewed slide IDs. Missing evidence returns `REVIEW_REQUIRED`. Any undeclared family, background, typography, image-treatment, accent, or adjacent-transition outlier emits `PAGE_FAMILY_DRIFT` and blocks release.

## Model anchors and ownership

- Distinguish `BoxAnchor` (PowerPoint geometry), `InkAnchor` (first/last rendered visible pixel), and `ContentAnchor` (meaningful visible image edge).
- Judge declared relationships from 3840×2160 Windows PowerPoint PNGs normalized to 1920×1080. More than 2 px absolute deviation is `ALIGNMENT_DRIFT` and blocks release.
- Give every critical shape a stable PowerPoint name, kind, semantic owner, lock state, auto-repair policy, and relationship IDs.
- Lock titles, body text, logos, hero images, charts, and tables by default with `autoRepair: NONE`.
- Model reusable relationships with `TextRulePair`, `ImageTextAxis`, `AlignedGroup`, and `OwnedRule` contracts.
- Give every visible line one of `LABEL_MARKER`, `REGION_SEPARATOR`, `SEQUENCE`, or `BOUNDARY`, plus start anchor, end anchor, and semantic owner. Otherwise emit `ORPHAN_RULE`.

## Permit only safe repair

Move the declared dependent decoration or helper, not the content anchor. Permit line endpoint/position changes, movable helper-shape translation, shared-axis restoration, or a declared group nudge only when the contract allows it. Require `maxAutoNudgePx ≤ 32`.

Never change copy, font, size, weight, tracking, leading, paragraph structure, image crop/focus, grid, hierarchy, page family, locked content, or an undeclared relationship. Compare pre/post PowerPoint object inventories and accept only allowed `left`/`top` changes. Rerun boundary, collision, wrap, crop, hierarchy, Integrity, and rendered alignment checks. Stop after two rounds or on any new defect.

## Resolve conflicts

Apply this precedence: facts/rights/lineage; accessibility/native editability; page role/semantics; Visual DNA/style grammar; decoration. Every contract field has one owner in `modules.json`. Emit `CONTRACT_CONFLICT` when requirements cannot coexist and `CAPABILITY_GAP` when PowerPoint or the asset set cannot satisfy a required field.

## Preserve execution authority

The host may execute only reviewed `HOST_ACTIONS_V1` action `COMPILE_VISUAL_DIRECTION` through entrypoint `directing-presentation-visuals`. Package scripts are explicit operator/CI tools, never automatic host actions. Read [host-integration.md](references/host-integration.md) before integration and [contracts.md](references/contracts.md) before emitting artifact JSON.

## Stop and release

Stop before preview generation without an approved lock and before an unknown-rights asset. For an office concept deck, also stop when the design-director handoff or joint content–visual gate is incomplete. Stop before native editable production without either an explicit `VisualApprovalReceipt` bound to the accepted preview hashes or a user-declared `ONE_PASS_EDITABLE` override. Stop before production with incomplete slide or deck-coherence contracts, and before final Visual Quality until Integrity, rendered alignment, and deck coherence pass. If Windows desktop PowerPoint, full-size renders, PDF, montage-bound coherence evidence, font/glyph evidence, source evidence, Gold references, both order-reversed judgments, all six rationales, or render hashes are missing from Stage 2, return `REVIEW_REQUIRED`, never `PASS`.

For Stage 1, deliver a clearly labeled non-editable visual PDF, one image per slide, montage, preview hashes, and approval status; an optional image-based PPTX may contain one full-slide raster per page. For Stage 2, deliver the editable PPTX, PowerPoint PDF, one PNG per slide, montage, file/render hashes, asset/font/native-layer evidence, rendered-alignment evidence, deck-coherence evidence, safe-repair ledger, Gold evidence, and QA ledger. Preserve accepted slides, verified sources, native layers, receipts, the approved preview, and the direction lock during repair.
