param([Parameter(Mandatory = $true)][string]$Output)

$ErrorActionPreference = 'Stop'
$msoFalse = 0
$msoTextOrientationHorizontal = 1
$msoShapeRectangle = 1
$ppLayoutBlank = 12
$ppSaveAsOpenXMLPresentation = 24

$destination = [System.IO.Path]::GetFullPath($Output)
if (Test-Path -LiteralPath $destination) { throw "Fixture already exists: $destination" }
$parent = Split-Path -Parent $destination
if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }

$application = $null
$presentation = $null
try {
    $application = New-Object -ComObject PowerPoint.Application
    $presentation = $application.Presentations.Add($msoFalse)
    $presentation.PageSetup.SlideWidth = 960
    $presentation.PageSetup.SlideHeight = 540
    $slide = $presentation.Slides.Add(1, $ppLayoutBlank)
    $slide.FollowMasterBackground = $msoFalse
    $slide.Background.Fill.Solid()
    $slide.Background.Fill.ForeColor.RGB = 16777215

    $eyebrow = $slide.Shapes.AddTextbox($msoTextOrientationHorizontal, 63, 60, 300, 40)
    $eyebrow.Name = 'cover-eyebrow'
    $eyebrow.TextFrame.MarginLeft = 7.2
    $eyebrow.TextFrame.MarginRight = 0
    $eyebrow.TextFrame.MarginTop = 0
    $eyebrow.TextFrame.MarginBottom = 0
    $eyebrow.TextFrame.TextRange.Text = 'OPPO CEO FLOOR'
    $eyebrow.TextFrame.TextRange.Font.Name = 'Arial'
    $eyebrow.TextFrame.TextRange.Font.Size = 20
    $eyebrow.TextFrame.TextRange.Font.Bold = $msoFalse
    $eyebrow.TextFrame.TextRange.Font.Color.RGB = 0
    $eyebrow.Fill.Visible = $msoFalse
    $eyebrow.Line.Visible = $msoFalse

    $marker = $slide.Shapes.AddShape($msoShapeRectangle, 63, 108, 80, 2)
    $marker.Name = 'green-marker'
    $marker.Fill.Solid()
    $marker.Fill.ForeColor.RGB = 52326
    $marker.Line.Visible = $msoFalse

    $presentation.SaveAs($destination, $ppSaveAsOpenXMLPresentation)
    [ordered]@{
        ok = $true
        fixture = $destination
        powerPointVersion = [string]$application.Version
        expected = [ordered]@{
            slide = 1
            anchor = 'cover-eyebrow'
            dependent = 'green-marker'
            bothBoxLeftPt = 63
            anchorInkLeftLogicalPx = 142
            dependentInkLeftLogicalPx = 126
            initialOffsetLogicalPx = -16
            safeRepairRightPt = 8
            repairedOffsetLogicalPx = 0
        }
    } | ConvertTo-Json -Depth 6
} finally {
    if ($presentation) { try { $presentation.Close() } catch {}; [Runtime.InteropServices.Marshal]::FinalReleaseComObject($presentation) | Out-Null }
    if ($application) { try { $application.Quit() } catch {}; [Runtime.InteropServices.Marshal]::FinalReleaseComObject($application) | Out-Null }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
