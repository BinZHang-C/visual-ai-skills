#!/usr/bin/env python3
"""Regression tests for rendered alignment thresholds and repair safety."""

from __future__ import annotations

import importlib.util
import json
import struct
import tempfile
import zlib
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
QA_PATH = ROOT / "scripts" / "rendered_alignment_qa.py"


def load_qa():
    spec = importlib.util.spec_from_file_location("rendered_alignment_qa_under_test", QA_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot import rendered_alignment_qa.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def chunk(kind: bytes, payload: bytes) -> bytes:
    return struct.pack(">I", len(payload)) + kind + payload + struct.pack(">I", zlib.crc32(kind + payload) & 0xFFFFFFFF)


def write_rect_png(path: Path, bounds: tuple[int, int, int, int], color: tuple[int, int, int, int], width: int = 400, height: int = 225) -> None:
    left, top, right, bottom = bounds
    white = bytes((255, 255, 255, 255))
    pixel = bytes(color)
    rows = []
    for y in range(height):
        row = bytearray(white * width)
        if top <= y < bottom:
            row[left * 4 : right * 4] = pixel * (right - left)
        rows.append(b"\x00" + bytes(row))
    header = struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)
    path.write_bytes(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", header) + chunk(b"IDAT", zlib.compress(b"".join(rows), 9)) + chunk(b"IEND", b""))


def relation(dependent: str = "dependent") -> dict:
    return {
        "relationshipId": f"relation-{dependent}", "component": "AlignedGroup", "anchorObjectId": "anchor",
        "dependentObjectId": dependent, "anchorEdge": "LEFT", "dependentEdge": "LEFT",
        "expectedOffsetPx": 0, "tolerancePx": 2, "repairAxis": "X", "semanticOwner": "regression",
    }


def dependent(kind: str = "RULE", locked: bool = False, policy: str = "NUDGE_X", limit: int = 32) -> dict:
    return {"slideId": "slide-1", "objectId": "dependent", "shapeName": "dependent", "kind": kind, "locked": locked, "autoRepair": policy, "maxAutoNudgePx": limit}


def main() -> int:
    qa = load_qa()
    anchor_box = {"left": 100.0, "top": 100.0, "right": 200.0, "bottom": 140.0}
    drift_results = {}
    for offset in range(0, 11):
        dependent_box = {"left": 100.0 + offset, "top": 200.0, "right": 200.0 + offset, "bottom": 240.0}
        result = qa.compare_relationship(relation(), anchor_box, dependent_box)
        drift_results[offset] = result["decision"]
        assert result["decision"] == ("PASS" if offset <= 2 else "FAIL")
        if offset > 2:
            proposal, error = qa.repair_proposal(relation(), dependent(), float(result["deviationPx"]), 0)
            assert proposal and not error and proposal["deltaLogicalPx"] == -float(offset)

    safety = {
        "locked": dependent(locked=True, policy="NONE", limit=0),
        "text": dependent(kind="BODY"),
        "undeclared": dependent(kind="OTHER", policy="NONE", limit=0),
        "over-limit": dependent(limit=4),
    }
    safety_codes = {}
    for name, item in safety.items():
        proposal, error = qa.repair_proposal(relation(), item, 10.0, 0)
        assert proposal is None
        safety_codes[name] = error
    capped_proposal, capped_error = qa.repair_proposal(relation(), dependent(), 10.0, 2)
    assert capped_proposal is None and capped_error == "AUTO_REPAIR_LIMIT_EXCEEDED"

    geometry_cases = {
        "english-side-bearing": ((28, 20, 92, 44), (0, 0, 0, 255)),
        "cjk-latin-mixed": ((30, 48, 120, 72), (0, 0, 0, 255)),
        "textbox-margin": ((32, 76, 132, 100), (0, 0, 0, 255)),
        "line-cap": ((34, 104, 140, 108), (0, 120, 60, 255)),
        "rotated-object": ((36, 112, 146, 152), (20, 20, 20, 255)),
        "group-object": ((38, 156, 160, 196), (30, 30, 30, 255)),
        "semi-transparent-ui": ((180, 32, 300, 72), (30, 60, 120, 128)),
        "image-content-mask": ((190, 92, 330, 142), (80, 30, 20, 255)),
    }
    with tempfile.TemporaryDirectory() as folder:
        directory = Path(folder)
        for name, (bounds, color) in geometry_cases.items():
            path = directory / f"{name}.png"
            write_rect_png(path, bounds, color)
            width, height, measured = qa.decode_png_bbox(path, 12)
            assert (width, height) == (400, 225)
            assert measured == bounds, (name, measured, bounds)

    print(json.dumps({
        "ok": True,
        "driftInjectionPx": list(drift_results),
        "passRangePx": [0, 2],
        "blockedRangePx": [3, 10],
        "safetyCases": safety_codes,
        "geometryCases": list(geometry_cases),
        "twoRoundCap": True,
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
