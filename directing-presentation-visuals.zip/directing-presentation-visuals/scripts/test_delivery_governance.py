#!/usr/bin/env python3
"""Structural regression test for the optional delivery-governance module."""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8-sig")


def main() -> None:
    modules = json.loads(read("modules.json"))
    by_id = {item["id"]: item for item in modules["modules"]}
    module = by_id["delivery-governance"]
    order = modules["executionOrder"]
    assert order.index("core") < order.index("delivery-governance") < order.index("two-stage-delivery")
    assert module["reference"] == "references/delivery-governance.md"
    assert {
        "scope-change",
        "cross-session-resume",
        "repeated-failure",
        "multi-agent",
        "save-reopen-export-mismatch",
        "delivery-claim",
    } <= set(module["requiredWhen"])
    assert {
        "PresentationGovernanceSnapshot",
        "RepeatedFailureClosure",
        "ParallelEditMatrix",
        "RecoveryPoint",
    } <= set(module["outputs"])

    reference = read("references/delivery-governance.md")
    for term in (
        "PresentationTruth",
        "DecisionChangeRecord",
        "PresentationReadiness",
        "RepeatedFailureClosure",
        "ParallelEditMatrix",
        "RecoveryPoint",
        "Do not activate",
        "VisualApprovalReceipt",
        "AssetEvidenceReceipts",
        "DeckCoherenceContract",
    ):
        assert term in reference, f"missing delivery-governance term: {term}"

    skill = read("SKILL.md")
    for term in ("delivery-governance.md", "scope change", "repeated failure", "multi-agent"):
        assert term in skill, f"missing SKILL route: {term}"

    schema = json.loads(read("schemas/visual-direction-lock.schema.json"))
    assert "delivery-governance" in schema["properties"]["modules"]["items"]["enum"]
    assert '"delivery-governance"' in read("scripts/visual_director.py")
    print("delivery-governance tests: PASS")


if __name__ == "__main__":
    main()
