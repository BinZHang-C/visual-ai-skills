#!/usr/bin/env python3
"""Measure isolated PowerPoint PNGs and enforce rendered alignment contracts.

This operator/CI tool uses only the Python standard library. It does not use OCR,
does not modify PPTX files, and never runs as a host action.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import struct
import sys
import zlib
from collections import Counter
from pathlib import Path
from typing import Any, Iterable


LOGICAL_WIDTH = 1920
LOGICAL_HEIGHT = 1080
RELEASE_WIDTH = 3840
RELEASE_HEIGHT = 2160
PROTECTED_KINDS = {"TITLE", "BODY", "LOGO", "HERO_IMAGE", "CHART", "TABLE"}
X_POLICIES = {"NUDGE_X", "NUDGE_XY", "ADJUST_RULE_ENDPOINT"}
Y_POLICIES = {"NUDGE_Y", "NUDGE_XY", "ADJUST_RULE_ENDPOINT"}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return value


def validate_contract(contract: dict[str, Any]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    if contract.get("schemaVersion") != "1.0.0" or contract.get("logicalCanvas") != {"width": 1920, "height": 1080}:
        raise ValueError("invalid rendered alignment contract")
    objects = contract.get("objects")
    relationships = contract.get("relationships")
    if not isinstance(objects, list) or len(objects) < 2 or not isinstance(relationships, list) or not relationships:
        raise ValueError("contract requires at least two objects and one relationship")
    by_id: dict[str, dict[str, Any]] = {}
    for item in objects:
        if not isinstance(item, dict) or not isinstance(item.get("objectId"), str) or not item["objectId"]:
            raise ValueError("each object requires objectId")
        object_id = item["objectId"]
        if object_id in by_id:
            raise ValueError(f"duplicate objectId: {object_id}")
        if item.get("anchorType") not in {"BoxAnchor", "InkAnchor", "ContentAnchor"}:
            raise ValueError(f"invalid anchorType: {object_id}")
        expected_source = "REVIEWED_CONTENT_MASK" if item.get("anchorType") == "ContentAnchor" else "POWERPOINT_ISOLATED"
        if item.get("diagnosticSource") != expected_source:
            raise ValueError(f"invalid diagnosticSource for {object_id}: expected {expected_source}")
        nudge = item.get("maxAutoNudgePx")
        if not isinstance(nudge, (int, float)) or isinstance(nudge, bool) or not 0 <= nudge <= 32:
            raise ValueError(f"invalid maxAutoNudgePx: {object_id}")
        if item.get("locked") is True and item.get("autoRepair") != "NONE":
            raise ValueError(f"locked object enables repair: {object_id}")
        if item.get("kind") in PROTECTED_KINDS and (item.get("locked") is not True or item.get("autoRepair") != "NONE"):
            raise ValueError(f"protected object is not locked: {object_id}")
        by_id[object_id] = item
    relationship_ids: set[str] = set()
    for relation in relationships:
        if not isinstance(relation, dict) or not isinstance(relation.get("relationshipId"), str) or not relation["relationshipId"]:
            raise ValueError("each relationship requires relationshipId")
        relationship_id = relation["relationshipId"]
        if relationship_id in relationship_ids:
            raise ValueError(f"duplicate relationshipId: {relationship_id}")
        relationship_ids.add(relationship_id)
        anchor_id, dependent_id = relation.get("anchorObjectId"), relation.get("dependentObjectId")
        if anchor_id not in by_id or dependent_id not in by_id:
            raise ValueError(f"relationship references unknown object: {relationship_id}")
        if by_id[anchor_id].get("slideId") != by_id[dependent_id].get("slideId"):
            raise ValueError(f"relationship crosses slides: {relationship_id}")
        tolerance = relation.get("tolerancePx")
        if not isinstance(tolerance, (int, float)) or isinstance(tolerance, bool) or not 0 <= tolerance <= 2:
            raise ValueError(f"relationship tolerance must be 0..2: {relationship_id}")
        if relation.get("repairAxis") not in {"X", "Y", "NONE"}:
            raise ValueError(f"invalid repair axis: {relationship_id}")
    return objects, relationships


def paeth(a: int, b: int, c: int) -> int:
    p = a + b - c
    pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
    return a if pa <= pb and pa <= pc else b if pb <= pc else c


def decode_png(path: Path) -> tuple[int, int, list[tuple[int, int, int, int]]]:
    data = path.read_bytes()
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError(f"not a PNG: {path}")
    offset = 8
    width = height = bit_depth = color_type = interlace = None
    compressed = bytearray()
    while offset + 12 <= len(data):
        length = struct.unpack(">I", data[offset : offset + 4])[0]
        kind = data[offset + 4 : offset + 8]
        payload = data[offset + 8 : offset + 8 + length]
        offset += 12 + length
        if kind == b"IHDR":
            width, height, bit_depth, color_type, _, _, interlace = struct.unpack(">IIBBBBB", payload)
        elif kind == b"IDAT":
            compressed.extend(payload)
        elif kind == b"IEND":
            break
    if None in (width, height, bit_depth, color_type, interlace):
        raise ValueError(f"PNG header is incomplete: {path}")
    if bit_depth != 8 or interlace != 0 or color_type not in {0, 2, 4, 6}:
        raise ValueError(f"unsupported PNG format bitDepth={bit_depth} colorType={color_type} interlace={interlace}")
    channels = {0: 1, 2: 3, 4: 2, 6: 4}[int(color_type)]
    stride = int(width) * channels
    raw = zlib.decompress(bytes(compressed))
    expected = int(height) * (stride + 1)
    if len(raw) != expected:
        raise ValueError(f"unexpected PNG payload length: {len(raw)} != {expected}")
    rows: list[bytearray] = []
    cursor = 0
    previous = bytearray(stride)
    for _ in range(int(height)):
        filter_type = raw[cursor]
        cursor += 1
        encoded = raw[cursor : cursor + stride]
        cursor += stride
        row = bytearray(stride)
        for index, value in enumerate(encoded):
            left = row[index - channels] if index >= channels else 0
            up = previous[index]
            upper_left = previous[index - channels] if index >= channels else 0
            if filter_type == 0:
                predictor = 0
            elif filter_type == 1:
                predictor = left
            elif filter_type == 2:
                predictor = up
            elif filter_type == 3:
                predictor = (left + up) // 2
            elif filter_type == 4:
                predictor = paeth(left, up, upper_left)
            else:
                raise ValueError(f"unsupported PNG filter {filter_type}")
            row[index] = (value + predictor) & 0xFF
        rows.append(row)
        previous = row
    pixels: list[tuple[int, int, int, int]] = []
    for row in rows:
        for index in range(0, len(row), channels):
            if color_type == 0:
                gray = row[index]
                pixels.append((gray, gray, gray, 255))
            elif color_type == 2:
                pixels.append((row[index], row[index + 1], row[index + 2], 255))
            elif color_type == 4:
                gray, alpha = row[index], row[index + 1]
                pixels.append((gray, gray, gray, alpha))
            else:
                pixels.append((row[index], row[index + 1], row[index + 2], row[index + 3]))
    return int(width), int(height), pixels


def decode_png_bbox(path: Path, threshold: int) -> tuple[int, int, tuple[int, int, int, int] | None]:
    """Decode an 8-bit non-interlaced PNG and measure non-background pixels.

    Diagnostic renders use a uniform slide background. The majority of eight
    border samples defines that background, avoiding a top-left-object false pass.
    Rows are retained as bytes rather than millions of Python pixel tuples.
    """
    data = path.read_bytes()
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError(f"not a PNG: {path}")
    offset = 8
    width = height = bit_depth = color_type = interlace = None
    compressed = bytearray()
    while offset + 12 <= len(data):
        length = struct.unpack(">I", data[offset : offset + 4])[0]
        kind = data[offset + 4 : offset + 8]
        payload = data[offset + 8 : offset + 8 + length]
        offset += 12 + length
        if kind == b"IHDR":
            width, height, bit_depth, color_type, _, _, interlace = struct.unpack(">IIBBBBB", payload)
        elif kind == b"IDAT":
            compressed.extend(payload)
        elif kind == b"IEND":
            break
    if None in (width, height, bit_depth, color_type, interlace):
        raise ValueError(f"PNG header is incomplete: {path}")
    if bit_depth != 8 or interlace != 0 or color_type not in {0, 2, 4, 6}:
        raise ValueError(f"unsupported PNG format bitDepth={bit_depth} colorType={color_type} interlace={interlace}")
    channels = {0: 1, 2: 3, 4: 2, 6: 4}[int(color_type)]
    stride = int(width) * channels
    raw = zlib.decompress(bytes(compressed))
    if len(raw) != int(height) * (stride + 1):
        raise ValueError("unexpected PNG payload length")
    rows: list[bytearray] = []
    previous = bytearray(stride)
    cursor = 0
    for _ in range(int(height)):
        filter_type = raw[cursor]
        cursor += 1
        encoded = raw[cursor : cursor + stride]
        cursor += stride
        if filter_type == 0:
            row = bytearray(encoded)
        else:
            row = bytearray(stride)
            for index, value in enumerate(encoded):
                prior = row[index - channels] if index >= channels else 0
                above = previous[index]
                upper_left = previous[index - channels] if index >= channels else 0
                if filter_type == 1:
                    predictor = prior
                elif filter_type == 2:
                    predictor = above
                elif filter_type == 3:
                    predictor = (prior + above) // 2
                elif filter_type == 4:
                    predictor = paeth(prior, above, upper_left)
                else:
                    raise ValueError(f"unsupported PNG filter {filter_type}")
                row[index] = (value + predictor) & 0xFF
        rows.append(row)
        previous = row

    def rgba(row: bytearray, x: int) -> tuple[int, int, int, int]:
        index = x * channels
        if color_type == 0:
            return row[index], row[index], row[index], 255
        if color_type == 2:
            return row[index], row[index + 1], row[index + 2], 255
        if color_type == 4:
            return row[index], row[index], row[index], row[index + 1]
        return row[index], row[index + 1], row[index + 2], row[index + 3]

    border_points = [
        (0, 0), (int(width) - 1, 0), (0, int(height) - 1), (int(width) - 1, int(height) - 1),
        (int(width) // 2, 0), (int(width) // 2, int(height) - 1),
        (0, int(height) // 2), (int(width) - 1, int(height) // 2),
    ]
    background = Counter(rgba(rows[y], x)[:3] for x, y in border_points).most_common(1)[0][0]
    threshold_squared = threshold * threshold
    left, top, right, bottom = int(width), int(height), -1, -1
    for y, row in enumerate(rows):
        for x in range(int(width)):
            red, green, blue, alpha = rgba(row, x)
            if alpha < 16:
                continue
            distance = (red - background[0]) ** 2 + (green - background[1]) ** 2 + (blue - background[2]) ** 2
            if distance > threshold_squared:
                left, top, right, bottom = min(left, x), min(top, y), max(right, x), max(bottom, y)
    box = None if right < left else (left, top, right + 1, bottom + 1)
    return int(width), int(height), box


def background_color(width: int, height: int, pixels: list[tuple[int, int, int, int]]) -> tuple[int, int, int]:
    points = [
        (0, 0), (width - 1, 0), (0, height - 1), (width - 1, height - 1),
        (width // 2, 0), (width // 2, height - 1), (0, height // 2), (width - 1, height // 2),
    ]
    colors = [(pixels[y * width + x][0], pixels[y * width + x][1], pixels[y * width + x][2]) for x, y in points]
    return Counter(colors).most_common(1)[0][0]


def visible_bbox(width: int, height: int, pixels: list[tuple[int, int, int, int]], threshold: int) -> tuple[int, int, int, int] | None:
    bg = background_color(width, height, pixels)
    left, top, right, bottom = width, height, -1, -1
    threshold_squared = threshold * threshold
    for index, (red, green, blue, alpha) in enumerate(pixels):
        if alpha < 16:
            continue
        distance = (red - bg[0]) ** 2 + (green - bg[1]) ** 2 + (blue - bg[2]) ** 2
        if distance <= threshold_squared:
            continue
        x, y = index % width, index // width
        left, top, right, bottom = min(left, x), min(top, y), max(right, x), max(bottom, y)
    return None if right < left else (left, top, right + 1, bottom + 1)


def logical_bbox(box: tuple[int, int, int, int], width: int, height: int) -> dict[str, float]:
    sx, sy = LOGICAL_WIDTH / width, LOGICAL_HEIGHT / height
    left, top, right, bottom = box
    return {"left": left * sx, "top": top * sy, "right": right * sx, "bottom": bottom * sy}


def edge(box: dict[str, float], name: str) -> float:
    if name == "LEFT":
        return box["left"]
    if name == "RIGHT":
        return box["right"]
    if name == "TOP":
        return box["top"]
    if name == "BOTTOM":
        return box["bottom"]
    if name == "CENTER_X":
        return (box["left"] + box["right"]) / 2
    if name == "CENTER_Y":
        return (box["top"] + box["bottom"]) / 2
    raise ValueError(f"unsupported edge: {name}")


def compare_relationship(relation: dict[str, Any], anchor_box: dict[str, float], dependent_box: dict[str, float]) -> dict[str, Any]:
    anchor_value = edge(anchor_box, relation["anchorEdge"])
    dependent_value = edge(dependent_box, relation["dependentEdge"])
    measured_offset = dependent_value - anchor_value
    expected = float(relation["expectedOffsetPx"])
    tolerance = float(relation["tolerancePx"])
    deviation = measured_offset - expected
    return {
        "relationshipId": relation["relationshipId"],
        "anchorObjectId": relation["anchorObjectId"],
        "dependentObjectId": relation["dependentObjectId"],
        "measuredOffsetPx": round(measured_offset, 4),
        "expectedOffsetPx": expected,
        "deviationPx": round(deviation, 4),
        "tolerancePx": tolerance,
        "decision": "PASS" if abs(deviation) <= tolerance + 1e-9 else "FAIL",
    }


def finding(code: str, slide_id: str, object_id: str, message: str, action: str) -> dict[str, Any]:
    return {
        "code": code, "severity": "BLOCKING", "slideId": slide_id, "layerId": object_id,
        "message": message, "action": action,
        "preserve": ["copy", "typography", "crop", "Visual DNA", "locked objects"],
    }


def repair_proposal(relationship: dict[str, Any], dependent: dict[str, Any], deviation: float, repair_round: int) -> tuple[dict[str, Any] | None, str | None]:
    axis = relationship.get("repairAxis")
    policy = dependent.get("autoRepair")
    if dependent.get("locked") is True or dependent.get("kind") in PROTECTED_KINDS or policy == "NONE" or axis == "NONE":
        return None, "AUTO_REPAIR_FORBIDDEN"
    if axis == "X" and policy not in X_POLICIES:
        return None, "AUTO_REPAIR_FORBIDDEN"
    if axis == "Y" and policy not in Y_POLICIES:
        return None, "AUTO_REPAIR_FORBIDDEN"
    delta = -deviation
    limit = min(float(dependent.get("maxAutoNudgePx", 0)), 32.0)
    if abs(delta) > limit:
        return None, "AUTO_REPAIR_LIMIT_EXCEEDED"
    if repair_round >= 2:
        return None, "AUTO_REPAIR_LIMIT_EXCEEDED"
    return {
        "relationshipId": relationship["relationshipId"],
        "slideId": dependent["slideId"],
        "objectId": dependent["objectId"],
        "shapeName": dependent["shapeName"],
        "axis": axis,
        "action": policy,
        "deltaLogicalPx": round(delta, 4),
        "maxAutoNudgePx": limit,
        "repairRound": repair_round + 1,
        "allowedMutationFields": ["left"] if axis == "X" else ["top"],
    }, None


def evaluate(contract_path: Path, pptx_path: Path, diagnostic_dir: Path, renderer_version: str, repair_round: int, threshold: int) -> dict[str, Any]:
    contract = load_json(contract_path)
    objects, relationships = validate_contract(contract)
    by_id: dict[str, dict[str, Any]] = {}
    measurements: list[dict[str, Any]] = []
    findings: list[dict[str, Any]] = []
    missing = False
    for item in objects:
        object_id = item["objectId"]
        by_id[object_id] = item
        render = (diagnostic_dir / str(item.get("diagnosticRender", ""))).resolve()
        if diagnostic_dir.resolve() not in render.parents or not render.is_file():
            missing = True
            code = "CONTENT_ANCHOR_EVIDENCE_MISSING" if item.get("anchorType") == "ContentAnchor" else "ALIGNMENT_EVIDENCE_MISSING"
            findings.append(finding(code, str(item.get("slideId", "unknown")), object_id, "Required diagnostic render is missing.", "Render the declared object from the current PPTX."))
            continue
        width, height, box = decode_png_bbox(render, threshold)
        if (width, height) != (RELEASE_WIDTH, RELEASE_HEIGHT):
            missing = True
            findings.append(finding("ALIGNMENT_EVIDENCE_MISSING", str(item.get("slideId", "unknown")), object_id, f"Diagnostic render is {width}×{height}, expected 3840×2160.", "Re-export from Windows PowerPoint at release dimensions."))
            continue
        if box is None:
            missing = True
            findings.append(finding("ALIGNMENT_EVIDENCE_MISSING", str(item.get("slideId", "unknown")), object_id, "No visible pixels were found in the isolated render.", "Check shape visibility and diagnostic background."))
            continue
        measurements.append({
            "objectId": object_id,
            "slideId": item["slideId"],
            "anchorType": item["anchorType"],
            "evidenceMode": item["diagnosticSource"],
            "renderSha256": sha256_file(render),
            "renderWidth": width,
            "renderHeight": height,
            "logicalBoundingBox": {key: round(value, 4) for key, value in logical_bbox(box, width, height).items()},
        })
    measured = {item["objectId"]: item for item in measurements}
    relationship_results: list[dict[str, Any]] = []
    repairs: list[dict[str, Any]] = []
    drift = False
    for relation in relationships:
        anchor_id, dependent_id = relation.get("anchorObjectId"), relation.get("dependentObjectId")
        if anchor_id not in measured or dependent_id not in measured:
            missing = True
            continue
        result = compare_relationship(relation, measured[anchor_id]["logicalBoundingBox"], measured[dependent_id]["logicalBoundingBox"])
        relationship_results.append(result)
        deviation = float(result["deviationPx"])
        tolerance = float(result["tolerancePx"])
        if result["decision"] == "PASS":
            continue
        drift = True
        proposal, repair_error = repair_proposal(relation, by_id[dependent_id], deviation, repair_round)
        if proposal:
            repairs.append(proposal)
            action = f"Apply guarded {proposal['action']} to the declared dependent, then rerender and retest."
        else:
            action = "Request human review; do not change content or infer design intent."
        findings.append(finding("ALIGNMENT_DRIFT", by_id[dependent_id]["slideId"], dependent_id, f"Rendered deviation is {deviation:.4f} logical px; tolerance is {tolerance:.4f} px.", action))
        if repair_error:
            findings.append(finding(repair_error, by_id[dependent_id]["slideId"], dependent_id, "The failed relationship is not eligible for automatic repair.", action))
    decision = "FAIL" if drift else "REVIEW_REQUIRED" if missing else "PASS"
    return {
        "schemaVersion": "1.0.0",
        "pptxSha256": sha256_file(pptx_path),
        "contractSha256": sha256_file(contract_path),
        "renderer": {"product": "Microsoft PowerPoint", "platform": "Windows", "version": renderer_version, "exportWidth": RELEASE_WIDTH, "exportHeight": RELEASE_HEIGHT},
        "measurements": measurements,
        "relationships": relationship_results,
        "findings": findings,
        "repairProposals": repairs,
        "repairRound": repair_round,
        "decision": decision,
    }


def main(argv: Iterable[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Measure PowerPoint-rendered anchors and enforce a 2 px release tolerance.")
    parser.add_argument("--contract", required=True)
    parser.add_argument("--pptx", required=True)
    parser.add_argument("--diagnostic-dir", required=True)
    parser.add_argument("--renderer-version", required=True)
    parser.add_argument("--repair-round", type=int, choices=[0, 1, 2], default=0)
    parser.add_argument("--color-threshold", type=int, default=12)
    parser.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    try:
        output = evaluate(Path(args.contract).resolve(), Path(args.pptx).resolve(), Path(args.diagnostic_dir).resolve(), args.renderer_version, args.repair_round, args.color_threshold)
        output_path = Path(args.output).resolve()
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(output, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
        print(json.dumps({"ok": output["decision"] == "PASS", "decision": output["decision"], "output": str(output_path), "repairProposalCount": len(output["repairProposals"])}, ensure_ascii=False, indent=2))
        return 0 if output["decision"] == "PASS" else 6
    except Exception as exc:
        print(json.dumps({"ok": False, "decision": "REVIEW_REQUIRED", "error": f"{type(exc).__name__}: {exc}"}, ensure_ascii=False, indent=2))
        return 2


if __name__ == "__main__":
    sys.exit(main())
