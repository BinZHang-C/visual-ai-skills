param(
    [Parameter(Mandatory = $true)][string]$Pptx,
    [Parameter(Mandatory = $true)][string]$OutputDirectory,
    [string]$AlignmentContract,
    [string]$RepairPlan,
    [ValidateRange(0, 2)][int]$RepairRound = 0
)

$ErrorActionPreference = 'Stop'
$msoFalse = 0
$msoTrue = -1
$ppSaveAsPDF = 32

function Get-Sha256([string]$Path) {
    return (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant()
}

function Get-SafeValue([scriptblock]$Getter, $Default = $null) {
    try { return & $Getter } catch { return $Default }
}

function Get-ShapeRecord($Shape, [int]$SlideIndex) {
    $text = ''
    $fontName = ''
    $fontSize = 0.0
    $fontBold = 0
    $fontItalic = 0
    $fontSpacing = 0.0
    $paragraphAlignment = 0
    $spaceBefore = 0.0
    $spaceAfter = 0.0
    $spaceWithin = 0.0
    if ((Get-SafeValue { $Shape.HasTextFrame } 0) -ne 0) {
        $hasText = Get-SafeValue { $Shape.TextFrame.HasText } 0
        if ($hasText -ne 0) {
            $range = $Shape.TextFrame.TextRange
            $text = [string](Get-SafeValue { $range.Text } '')
            $fontName = [string](Get-SafeValue { $range.Font.Name } '')
            $fontSize = [double](Get-SafeValue { $range.Font.Size } 0)
            $fontBold = [int](Get-SafeValue { $range.Font.Bold } 0)
            $fontItalic = [int](Get-SafeValue { $range.Font.Italic } 0)
            $fontSpacing = [double](Get-SafeValue { $range.Font.Spacing } 0)
            $paragraphAlignment = [int](Get-SafeValue { $range.ParagraphFormat.Alignment } 0)
            $spaceBefore = [double](Get-SafeValue { $range.ParagraphFormat.SpaceBefore } 0)
            $spaceAfter = [double](Get-SafeValue { $range.ParagraphFormat.SpaceAfter } 0)
            $spaceWithin = [double](Get-SafeValue { $range.ParagraphFormat.SpaceWithin } 0)
        }
    }
    [ordered]@{
        slideIndex = $SlideIndex
        name = [string]$Shape.Name
        type = [int]$Shape.Type
        left = [double]$Shape.Left
        top = [double]$Shape.Top
        width = [double]$Shape.Width
        height = [double]$Shape.Height
        rotation = [double]$Shape.Rotation
        text = $text
        fontName = $fontName
        fontSize = $fontSize
        fontBold = $fontBold
        fontItalic = $fontItalic
        fontSpacing = $fontSpacing
        paragraphAlignment = $paragraphAlignment
        spaceBefore = $spaceBefore
        spaceAfter = $spaceAfter
        spaceWithin = $spaceWithin
        marginLeft = [double](Get-SafeValue { $Shape.TextFrame.MarginLeft } 0)
        marginRight = [double](Get-SafeValue { $Shape.TextFrame.MarginRight } 0)
        marginTop = [double](Get-SafeValue { $Shape.TextFrame.MarginTop } 0)
        marginBottom = [double](Get-SafeValue { $Shape.TextFrame.MarginBottom } 0)
        wordWrap = [int](Get-SafeValue { $Shape.TextFrame.WordWrap } 0)
        autoSize = [int](Get-SafeValue { $Shape.TextFrame.AutoSize } 0)
        cropLeft = [double](Get-SafeValue { $Shape.PictureFormat.CropLeft } 0)
        cropRight = [double](Get-SafeValue { $Shape.PictureFormat.CropRight } 0)
        cropTop = [double](Get-SafeValue { $Shape.PictureFormat.CropTop } 0)
        cropBottom = [double](Get-SafeValue { $Shape.PictureFormat.CropBottom } 0)
    }
}

function Get-PresentationInventory($Presentation) {
    $records = @()
    for ($slideIndex = 1; $slideIndex -le $Presentation.Slides.Count; $slideIndex++) {
        $slide = $Presentation.Slides.Item($slideIndex)
        for ($shapeIndex = 1; $shapeIndex -le $slide.Shapes.Count; $shapeIndex++) {
            $records += Get-ShapeRecord $slide.Shapes.Item($shapeIndex) $slideIndex
        }
    }
    return @($records | Sort-Object slideIndex,name)
}

function Find-Shape($Presentation, [string]$SlideId, [string]$ShapeName) {
    $slideNumber = 0
    if ($SlideId -match '(\d+)$') { $slideNumber = [int]$Matches[1] }
    if ($slideNumber -lt 1 -or $slideNumber -gt $Presentation.Slides.Count) {
        throw "Cannot resolve slideId '$SlideId' to a PowerPoint slide number."
    }
    $slide = $Presentation.Slides.Item($slideNumber)
    for ($index = 1; $index -le $slide.Shapes.Count; $index++) {
        $shape = $slide.Shapes.Item($index)
        if ([string]$shape.Name -ceq $ShapeName) { return $shape }
    }
    throw "Shape '$ShapeName' was not found on $SlideId."
}

function Assert-InventoryMutation($Before, $After, $Allowed) {
    $beforeMap = @{}
    foreach ($item in $Before) { $beforeMap["$($item.slideIndex)|$($item.name)"] = $item }
    $afterMap = @{}
    foreach ($item in $After) { $afterMap["$($item.slideIndex)|$($item.name)"] = $item }
    if ($beforeMap.Count -ne $afterMap.Count) { throw 'UNSAFE_REPAIR_MUTATION: object count changed.' }
    $allFields = @('type','left','top','width','height','rotation','text','fontName','fontSize','fontBold','fontItalic','fontSpacing','paragraphAlignment','spaceBefore','spaceAfter','spaceWithin','marginLeft','marginRight','marginTop','marginBottom','wordWrap','autoSize','cropLeft','cropRight','cropTop','cropBottom')
    foreach ($key in $beforeMap.Keys) {
        if (-not $afterMap.ContainsKey($key)) { throw "UNSAFE_REPAIR_MUTATION: object disappeared: $key" }
        $allowedFields = @()
        if ($Allowed.ContainsKey($key)) { $allowedFields = @($Allowed[$key]) }
        foreach ($field in $allFields) {
            if ($beforeMap[$key][$field] -ne $afterMap[$key][$field] -and $field -notin $allowedFields) {
                throw "UNSAFE_REPAIR_MUTATION: $key changed forbidden field $field."
            }
        }
    }
}

function New-Montage([string[]]$Images, [string]$Destination) {
    Add-Type -AssemblyName System.Drawing
    $columns = 4
    $cellWidth = 480
    $cellHeight = 270
    $rows = [Math]::Max(1, [Math]::Ceiling($Images.Count / $columns))
    $canvas = New-Object System.Drawing.Bitmap ($columns * $cellWidth), ($rows * $cellHeight)
    $graphics = [System.Drawing.Graphics]::FromImage($canvas)
    $graphics.Clear([System.Drawing.Color]::FromArgb(24, 24, 24))
    try {
        for ($index = 0; $index -lt $Images.Count; $index++) {
            $image = [System.Drawing.Image]::FromFile($Images[$index])
            try {
                $x = ($index % $columns) * $cellWidth
                $y = [Math]::Floor($index / $columns) * $cellHeight
                $graphics.DrawImage($image, $x, $y, $cellWidth, $cellHeight)
            } finally { $image.Dispose() }
        }
        $canvas.Save($Destination, [System.Drawing.Imaging.ImageFormat]::Png)
    } finally {
        $graphics.Dispose()
        $canvas.Dispose()
    }
}

$source = (Resolve-Path -LiteralPath $Pptx).Path
$output = [System.IO.Path]::GetFullPath($OutputDirectory)
if (-not (Test-Path -LiteralPath $output)) { New-Item -ItemType Directory -Path $output -Force | Out-Null }
$renderDirectory = Join-Path $output 'slides'
$diagnosticDirectory = Join-Path $output 'diagnostics'
New-Item -ItemType Directory -Path $renderDirectory,$diagnosticDirectory -Force | Out-Null
$candidate = Join-Path $output 'candidate.pptx'
if (Test-Path -LiteralPath $candidate) { throw "Candidate already exists: $candidate" }
Copy-Item -LiteralPath $source -Destination $candidate

$application = $null
$presentation = $null
try {
    try { $application = New-Object -ComObject PowerPoint.Application } catch {
        [ordered]@{ decision = 'REVIEW_REQUIRED'; finding = 'POWERPOINT_UNAVAILABLE'; error = $_.Exception.Message } | ConvertTo-Json -Depth 4
        exit 7
    }
    $powerPointVersion = [string]$application.Version
    $presentation = $application.Presentations.Open($candidate, $msoFalse, $msoFalse, $msoFalse)
    $alignmentValue = $null
    if ($AlignmentContract) {
        $alignmentValue = Get-Content -Raw -Encoding UTF8 -LiteralPath $AlignmentContract | ConvertFrom-Json
    }
    if ($RepairPlan -and -not $alignmentValue) { throw 'AUTO_REPAIR_FORBIDDEN: AlignmentContract is required when applying a repair plan.' }
    $before = Get-PresentationInventory $presentation
    $allowed = @{}
    $repairLedger = @()
    if ($RepairPlan) {
        if ($RepairRound -ge 2) { throw 'AUTO_REPAIR_LIMIT_EXCEEDED: repair round must be below 2 before applying a new repair.' }
        $planValue = Get-Content -Raw -Encoding UTF8 -LiteralPath $RepairPlan | ConvertFrom-Json
        $proposals = if ($planValue.repairProposals) { @($planValue.repairProposals) } else { @($planValue) }
        $slideWidth = [double]$presentation.PageSetup.SlideWidth
        $slideHeight = [double]$presentation.PageSetup.SlideHeight
        $protectedKinds = @('TITLE','BODY','LOGO','HERO_IMAGE','CHART','TABLE')
        foreach ($proposal in $proposals) {
            $contractObjects = @($alignmentValue.objects | Where-Object { $_.objectId -ceq [string]$proposal.objectId -and $_.slideId -ceq [string]$proposal.slideId -and $_.shapeName -ceq [string]$proposal.shapeName })
            if ($contractObjects.Count -ne 1) { throw "AUTO_REPAIR_FORBIDDEN: contract object mismatch for $($proposal.objectId)" }
            $contractObject = $contractObjects[0]
            $contractRelations = @($alignmentValue.relationships | Where-Object { $_.relationshipId -ceq [string]$proposal.relationshipId -and $_.dependentObjectId -ceq [string]$proposal.objectId })
            if ($contractRelations.Count -ne 1) { throw "AUTO_REPAIR_FORBIDDEN: relationship mismatch for $($proposal.relationshipId)" }
            $contractRelation = $contractRelations[0]
            if ($contractObject.locked -eq $true -or [string]$contractObject.kind -in $protectedKinds -or [string]$contractObject.autoRepair -eq 'NONE') {
                throw "AUTO_REPAIR_FORBIDDEN: protected or locked object $($proposal.objectId)"
            }
            if ([string]$proposal.action -cne [string]$contractObject.autoRepair -or [string]$proposal.axis -cne [string]$contractRelation.repairAxis) {
                throw "AUTO_REPAIR_FORBIDDEN: proposal policy differs from contract for $($proposal.objectId)"
            }
            if ([int]$proposal.repairRound -ne ($RepairRound + 1)) { throw "AUTO_REPAIR_FORBIDDEN: repair round mismatch for $($proposal.objectId)" }
            $contractLimit = [Math]::Min([double]$contractObject.maxAutoNudgePx, 32.0)
            if ([double]$contractObject.maxAutoNudgePx -gt 32 -or [Math]::Abs([double]$proposal.deltaLogicalPx) -gt $contractLimit) {
                throw "AUTO_REPAIR_LIMIT_EXCEEDED: $($proposal.objectId)"
            }
            $shape = Find-Shape $presentation ([string]$proposal.slideId) ([string]$proposal.shapeName)
            $key = "$(if ($proposal.slideId -match '(\d+)$') {[int]$Matches[1]} else {0})|$([string]$shape.Name)"
            if ($proposal.axis -eq 'X') {
                $deltaPoints = [double]$proposal.deltaLogicalPx * $slideWidth / 1920.0
                $shape.Left = [double]$shape.Left + $deltaPoints
                $allowed[$key] = @('left')
            } elseif ($proposal.axis -eq 'Y') {
                $deltaPoints = [double]$proposal.deltaLogicalPx * $slideHeight / 1080.0
                $shape.Top = [double]$shape.Top + $deltaPoints
                $allowed[$key] = @('top')
            } else { throw "AUTO_REPAIR_FORBIDDEN: unsupported axis $($proposal.axis)" }
            $repairLedger += [ordered]@{
                round = $RepairRound + 1
                objectId = [string]$proposal.objectId
                relationshipId = [string]$proposal.relationshipId
                action = [string]$proposal.action
                deltaLogicalPx = [double]$proposal.deltaLogicalPx
                deltaPoints = $deltaPoints
            }
        }
        $presentation.Save()
    }
    $after = Get-PresentationInventory $presentation
    Assert-InventoryMutation $before $after $allowed
    $inventoryPath = Join-Path $output 'object-inventory.json'
    [ordered]@{ before = $before; after = $after; allowedMutations = $allowed } | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $inventoryPath -Encoding UTF8

    $slideImages = @()
    for ($slideIndex = 1; $slideIndex -le $presentation.Slides.Count; $slideIndex++) {
        $slidePath = Join-Path $renderDirectory ('slide-{0:D3}.png' -f $slideIndex)
        $presentation.Slides.Item($slideIndex).Export($slidePath, 'PNG', 3840, 2160)
        if (-not (Test-Path -LiteralPath $slidePath)) { throw "POWERPOINT_EXPORT_FAILED: $slidePath" }
        $slideImages += $slidePath
    }
    $pdfPath = Join-Path $output 'candidate-powerpoint.pdf'
    $presentation.SaveAs($pdfPath, $ppSaveAsPDF)
    if (-not (Test-Path -LiteralPath $pdfPath)) { throw 'POWERPOINT_EXPORT_FAILED: PDF was not created.' }
    $montagePath = Join-Path $output 'montage.png'
    New-Montage $slideImages $montagePath

    if ($alignmentValue) {
        foreach ($object in @($alignmentValue.objects)) {
            $destination = Join-Path $diagnosticDirectory ([string]$object.diagnosticRender)
            $destinationParent = Split-Path -Parent $destination
            if (-not (Test-Path -LiteralPath $destinationParent)) { New-Item -ItemType Directory -Path $destinationParent -Force | Out-Null }
            if ($object.anchorType -eq 'ContentAnchor') {
                if (-not (Test-Path -LiteralPath $destination)) { continue }
            } else {
                $shape = Find-Shape $presentation ([string]$object.slideId) ([string]$object.shapeName)
                $slideNumber = if ($object.slideId -match '(\d+)$') { [int]$Matches[1] } else { throw "Invalid slideId: $($object.slideId)" }
                $slide = $presentation.Slides.Item($slideNumber)
                $visibility = @()
                for ($index = 1; $index -le $slide.Shapes.Count; $index++) {
                    $item = $slide.Shapes.Item($index)
                    $visibility += [int]$item.Visible
                    $item.Visible = if ([string]$item.Name -ceq [string]$shape.Name) { $msoTrue } else { $msoFalse }
                }
                $followMaster = [int](Get-SafeValue { $slide.FollowMasterBackground } $msoTrue)
                try {
                    $slide.FollowMasterBackground = $msoFalse
                    $slide.Background.Fill.Solid()
                    $slide.Background.Fill.ForeColor.RGB = 16777215
                    $slide.Export($destination, 'PNG', 3840, 2160)
                } finally {
                    $slide.FollowMasterBackground = $followMaster
                    for ($index = 1; $index -le $slide.Shapes.Count; $index++) { $slide.Shapes.Item($index).Visible = $visibility[$index - 1] }
                }
            }
        }
    }
    $presentation.Saved = $msoTrue
    $presentation.Close()
    [Runtime.InteropServices.Marshal]::FinalReleaseComObject($presentation) | Out-Null
    $presentation = $null
    $summary = [ordered]@{
        decision = 'RENDERED'
        renderer = [ordered]@{ product = 'Microsoft PowerPoint'; platform = 'Windows'; version = $powerPointVersion }
        sourcePptxSha256 = Get-Sha256 $source
        candidatePptx = $candidate
        candidatePptxSha256 = Get-Sha256 $candidate
        pdf = $pdfPath
        pdfSha256 = Get-Sha256 $pdfPath
        montage = $montagePath
        montageSha256 = Get-Sha256 $montagePath
        renderDirectory = $renderDirectory
        diagnosticDirectory = $diagnosticDirectory
        inventory = $inventoryPath
        inventorySha256 = Get-Sha256 $inventoryPath
        repairRound = $RepairRound
        repairLedger = $repairLedger
    }
    $summaryPath = Join-Path $output 'powerpoint-release.json'
    $summary | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $summaryPath -Encoding UTF8
    $summary | ConvertTo-Json -Depth 8
} finally {
    if ($presentation) { try { $presentation.Close() } catch {} ; [Runtime.InteropServices.Marshal]::FinalReleaseComObject($presentation) | Out-Null }
    if ($application) { try { $application.Quit() } catch {} ; [Runtime.InteropServices.Marshal]::FinalReleaseComObject($application) | Out-Null }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
