#!/usr/bin/env python3
"""Deterministic operator CLI for presentation visual contracts.

This file is never a host action. Run it only through an explicit operator or CI
command after package verification.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace
from typing import Any


EXIT_OK = 0
EXIT_PARSE = 2
EXIT_SCHEMA = 3
EXIT_DIRECTION = 4
EXIT_HARD_VETO = 5
EXIT_QUALITY = 6

SHA256 = set("0123456789abcdef")
MODULES = {
    "core",
    "delivery-governance",
    "two-stage-delivery",
    "style-system",
    "page-roles",
    "deck-coherence",
    "asset-truth",
    "data-graphics",
    "release-pipeline",
    "render-qa",
}
LINE_ROLES = {"LABEL_MARKER", "REGION_SEPARATOR", "SEQUENCE", "BOUNDARY"}
RIGHTS = {"OWNED", "LICENSED", "USER_ASSERTED", "GENERATED", "UNKNOWN", "QUARANTINED"}
HARD_VETO_CODES = {
    "FABRICATED_EVIDENCE",
    "UNKNOWN_RIGHTS_ASSET",
    "CORRUPTED_FILE",
    "MISSING_RENDER",
    "HASH_LINEAGE_MISMATCH",
    "BROKEN_RELATIONSHIP",
    "WHOLE_PAGE_RASTER",
    "FLATTENED_ESSENTIAL_CONTENT",
    "OVERFLOW",
    "OVERLAP",
    "CLIPPING",
    "BROKEN_CROP",
    "BROKEN_CHART",
    "MISSING_GLYPH",
    "FONT_FALLBACK_FAILURE",
    "UNREADABLE_TEXT",
    "ACCIDENTAL_TITLE_WRAP",
    "INSUFFICIENT_CONTRAST",
    "ALIGNMENT_DRIFT",
    "ORPHAN_RULE",
    "POWERPOINT_EXPORT_FAILED",
    "ALIGNMENT_EVIDENCE_MISSING",
    "CONTENT_ANCHOR_EVIDENCE_MISSING",
    "AUTO_REPAIR_FORBIDDEN",
    "AUTO_REPAIR_LIMIT_EXCEEDED",
    "UNSAFE_REPAIR_MUTATION",
    "PAGE_FAMILY_DRIFT",
}
FLOORS = {
    "contentHit": 95,
    "styleFidelity": 85,
    "visualExecution": 85,
    "assetQuality": 85,
    "technicalIntegrity": 95,
    "pageFamilyRhythm": 80,
    "overall": 88,
}
SKILL_ROOT = Path(__file__).resolve().parents[1]
GOLD_REGISTRY_PATH = SKILL_ROOT / "references" / "gold-visual-baseline.json"
GOLD_RECEIPT_PATH = SKILL_ROOT / "references" / "gold-reference-receipt.json"
STYLE_RECIPE_ROOT = SKILL_ROOT / "references" / "style-recipes"


class DirectorError(Exception):
    def __init__(self, code: int, message: str, errors: list[str] | None = None):
        super().__init__(message)
        self.code = code
        self.payload = {"ok": False, "message": message, "errors": errors or []}


def load_json(path: str | Path) -> Any:
    try:
        return json.loads(Path(path).read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as exc:
        raise DirectorError(EXIT_PARSE, f"Cannot read JSON: {path}", [str(exc)]) from exc


def file_sha256(path: Path) -> str:
    try:
        return hashlib.sha256(path.read_bytes()).hexdigest()
    except OSError as exc:
        raise DirectorError(EXIT_PARSE, f"Cannot hash file: {path}", [str(exc)]) from exc


def dump(payload: Any, output: str | None = None) -> None:
    text = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    if output:
        Path(output).parent.mkdir(parents=True, exist_ok=True)
        Path(output).write_text(text, encoding="utf-8", newline="\n")
    print(text, end="")


def is_sha256(value: Any) -> bool:
    return isinstance(value, str) and len(value) == 64 and set(value) <= SHA256


def require_object(value: Any, name: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise DirectorError(EXIT_SCHEMA, f"{name} must be an object")
    return value


def require_fields(value: dict[str, Any], fields: list[str], prefix: str = "") -> list[str]:
    return [f"{prefix}{field} is required" for field in fields if field not in value]


def canonical_hash(value: Any) -> str:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def direction_content(direction: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in direction.items() if key != "directionHash"}


def validate_direction(value: Any) -> dict[str, Any]:
    direction = require_object(value, "direction")
    required = [
        "schemaVersion", "skill", "communicationJob", "visualThesis", "directionId",
        "directionHash", "coverDirectionApproval", "visualDNA", "representativeGatePolicy",
        "modules", "styleAxes", "invariants", "mutableAxes", "deckRhythm",
    ]
    errors = require_fields(direction, required)
    if direction.get("schemaVersion") != "2.0.0":
        errors.append("schemaVersion must be 2.0.0")
    skill = direction.get("skill")
    if not isinstance(skill, dict):
        errors.append("skill must be an object")
    else:
        errors.extend(require_fields(skill, ["id", "version", "sourceHash", "packageHash"], "skill."))
        if skill.get("id") != "directing-presentation-visuals":
            errors.append("skill.id must be directing-presentation-visuals")
        for name in ("sourceHash", "packageHash"):
            if not is_sha256(skill.get(name)):
                errors.append(f"skill.{name} must be lowercase SHA-256")
    if not isinstance(direction.get("communicationJob"), str) or len(direction.get("communicationJob", "")) < 10:
        errors.append("communicationJob must contain at least 10 characters")
    if not isinstance(direction.get("visualThesis"), str) or len(direction.get("visualThesis", "")) < 20:
        errors.append("visualThesis must contain at least 20 characters")
    modules = direction.get("modules")
    if not isinstance(modules, list) or not {"core", "style-system", "page-roles", "deck-coherence", "release-pipeline", "render-qa"} <= set(modules):
        errors.append("modules must include core, style-system, page-roles, deck-coherence, release-pipeline, and render-qa")
    elif not set(modules) <= MODULES or len(modules) != len(set(modules)):
        errors.append("modules contain an unknown or duplicate module")
    axes = direction.get("styleAxes")
    axis_names = ["energy", "rigor", "temporality", "warmth", "contrast", "density", "materiality", "imageAgency"]
    if not isinstance(axes, dict):
        errors.append("styleAxes must be an object")
    else:
        errors.extend(require_fields(axes, axis_names, "styleAxes."))
        for name in axis_names:
            score = axes.get(name)
            if not isinstance(score, int) or isinstance(score, bool) or not 0 <= score <= 100:
                errors.append(f"styleAxes.{name} must be an integer from 0 to 100")
    for field, minimum in (("invariants", 3), ("mutableAxes", 1)):
        items = direction.get(field)
        if not isinstance(items, list) or len(items) < minimum or any(not isinstance(item, str) or not item for item in items):
            errors.append(f"{field} must contain at least {minimum} non-empty strings")
    rhythm = direction.get("deckRhythm")
    if not isinstance(rhythm, dict) or any(not isinstance(rhythm.get(key), list) or not rhythm.get(key) for key in ("scale", "density", "background", "action")):
        errors.append("deckRhythm must define non-empty scale, density, background, and action arrays")
    cover = direction.get("coverDirectionApproval")
    if not isinstance(cover, dict):
        errors.append("coverDirectionApproval must be an object")
    else:
        candidates = cover.get("candidates")
        candidate_ids = [item.get("directionId") for item in candidates if isinstance(item, dict)] if isinstance(candidates, list) else []
        if not isinstance(candidates, list) or len(candidates) != 3 or len(set(candidate_ids)) != 3:
            errors.append("coverDirectionApproval.candidates must contain exactly three unique directions")
        else:
            for index, candidate in enumerate(candidates):
                if not isinstance(candidate, dict) or candidate.get("renderKind") != "NON_EDITABLE_DIRECTION_PREVIEW" or not is_sha256(candidate.get("renderSha256")):
                    errors.append(f"coverDirectionApproval.candidates[{index}] must bind a non-editable preview SHA-256")
                for field in ("aestheticCeiling", "primaryGain", "risk"):
                    if not isinstance(candidate.get(field), str) or len(candidate[field].strip()) < 3:
                        errors.append(f"coverDirectionApproval.candidates[{index}].{field} is required")
            for field in ("recommendedDirectionId", "approvedDirectionId"):
                if cover.get(field) not in candidate_ids:
                    errors.append(f"coverDirectionApproval.{field} must reference a candidate")
    dna = direction.get("visualDNA")
    dna_fields = [
        "attentionMechanism", "spatialMechanism", "materialMechanism", "typeVoice",
        "hierarchyRatios", "canonicalInkAxes", "whitespaceBehavior", "imageGrammar",
        "lightAndContrast", "accentBehavior", "brandWithoutLogo", "antiRules",
    ]
    if not isinstance(dna, dict):
        errors.append("visualDNA must be an object")
    else:
        errors.extend(require_fields(dna, dna_fields, "visualDNA."))
        if not isinstance(dna.get("hierarchyRatios"), dict) or len(dna.get("hierarchyRatios", {})) < 3:
            errors.append("visualDNA.hierarchyRatios must contain at least three ratios")
        if not isinstance(dna.get("canonicalInkAxes"), list) or not dna.get("canonicalInkAxes"):
            errors.append("visualDNA.canonicalInkAxes must be non-empty")
        if not isinstance(dna.get("brandWithoutLogo"), list) or len(dna.get("brandWithoutLogo", [])) < 2:
            errors.append("visualDNA.brandWithoutLogo must contain at least two mechanisms")
        if not isinstance(dna.get("antiRules"), list) or len(dna.get("antiRules", [])) < 3:
            errors.append("visualDNA.antiRules must contain at least three rules")
    representative_policy = direction.get("representativeGatePolicy")
    expected_kinds = ["RATIONAL_STRATEGY", "RELATIONSHIP_ANALYSIS", "IMMERSIVE_CLIMAX"]
    if not isinstance(representative_policy, dict) or representative_policy.get("pageKinds") != expected_kinds or representative_policy.get("renderer") != "WINDOWS_POWERPOINT" or representative_policy.get("goldRequired") is not True or representative_policy.get("productionBlockedUntilPass") is not True:
        errors.append("representativeGatePolicy must require the three page kinds, Windows PowerPoint, Gold, and a production block")
    expected = canonical_hash(direction_content(direction))
    if direction.get("directionHash") != expected:
        errors.append(f"directionHash mismatch: expected {expected}")
    if errors:
        raise DirectorError(EXIT_SCHEMA, "Direction contract is invalid", errors)
    return direction


def command_compile(args: argparse.Namespace) -> dict[str, Any]:
    draft = require_object(load_json(args.input), "direction draft")
    draft = dict(draft)
    draft.pop("directionHash", None)
    draft["directionHash"] = canonical_hash(draft)
    validate_direction(draft)
    return {"ok": True, "direction": draft}


def command_validate_direction(args: argparse.Namespace) -> dict[str, Any]:
    direction = validate_direction(load_json(args.input))
    return {"ok": True, "directionId": direction["directionId"], "directionHash": direction["directionHash"]}


def validate_slides(value: Any, direction: dict[str, Any]) -> dict[str, Any]:
    contract = require_object(value, "slide contracts")
    errors = require_fields(contract, ["schemaVersion", "contractPhase", "directionId", "directionHash", "representativeGateEvidenceSha256", "slides"])
    if contract.get("schemaVersion") != "2.0.0":
        errors.append("schemaVersion must be 2.0.0")
    if contract.get("contractPhase") not in {"REPRESENTATIVE", "FULL_PRODUCTION"}:
        errors.append("contractPhase must be REPRESENTATIVE or FULL_PRODUCTION")
    if contract.get("contractPhase") == "FULL_PRODUCTION" and not is_sha256(contract.get("representativeGateEvidenceSha256")):
        errors.append("FULL_PRODUCTION requires representativeGateEvidenceSha256")
    if contract.get("directionId") != direction["directionId"] or contract.get("directionHash") != direction["directionHash"]:
        raise DirectorError(EXIT_DIRECTION, "Slide contracts do not match the locked direction")
    slides = contract.get("slides")
    if not isinstance(slides, list) or not slides:
        errors.append("slides must be a non-empty array")
        slides = []
    ids: set[str] = set()
    sequences: list[int] = []
    required = [
        "slideId", "sequence", "role", "claim", "takeawayTitle", "semanticTopology",
        "density", "silhouette", "representativeKind", "nativeLayers", "objects", "alignmentRelationshipIds", "structuralLines",
        "assetIds", "accessibility", "continuity", "repairPreserve",
    ]
    for index, slide_value in enumerate(slides):
        prefix = f"slides[{index}]."
        if not isinstance(slide_value, dict):
            errors.append(prefix[:-1] + " must be an object")
            continue
        slide = slide_value
        errors.extend(require_fields(slide, required, prefix))
        slide_id = slide.get("slideId")
        if not isinstance(slide_id, str) or not slide_id or slide_id in ids:
            errors.append(prefix + "slideId must be non-empty and unique")
        else:
            ids.add(slide_id)
        sequence = slide.get("sequence")
        if not isinstance(sequence, int) or isinstance(sequence, bool) or sequence < 1:
            errors.append(prefix + "sequence must be a positive integer")
        else:
            sequences.append(sequence)
        objects = slide.get("objects")
        if not isinstance(objects, list) or not objects:
            errors.append(prefix + "objects must be non-empty")
        else:
            object_ids: set[str] = set()
            protected = {"TITLE", "BODY", "LOGO", "HERO_IMAGE", "CHART", "TABLE"}
            for object_index, item in enumerate(objects):
                op = f"{prefix}objects[{object_index}]."
                if not isinstance(item, dict):
                    errors.append(op[:-1] + " must be an object")
                    continue
                errors.extend(require_fields(item, ["objectId", "shapeName", "kind", "semanticOwner", "locked", "autoRepair", "maxAutoNudgePx", "relationshipIds"], op))
                object_id = item.get("objectId")
                if not isinstance(object_id, str) or not object_id or object_id in object_ids:
                    errors.append(op + "objectId must be non-empty and unique within the slide")
                else:
                    object_ids.add(object_id)
                nudge = item.get("maxAutoNudgePx")
                if not isinstance(nudge, (int, float)) or isinstance(nudge, bool) or not 0 <= nudge <= 32:
                    errors.append(op + "maxAutoNudgePx must be from 0 to 32")
                if item.get("kind") in protected and (item.get("locked") is not True or item.get("autoRepair") != "NONE"):
                    errors.append(op + "protected content kinds must be locked with autoRepair NONE")
                if item.get("locked") is True and item.get("autoRepair") != "NONE":
                    errors.append(op + "locked objects cannot enable autoRepair")
        relationship_ids = slide.get("alignmentRelationshipIds")
        if not isinstance(relationship_ids, list) or len(relationship_ids) != len(set(relationship_ids)):
            errors.append(prefix + "alignmentRelationshipIds must be a unique array")
        lines = slide.get("structuralLines")
        if not isinstance(lines, list):
            errors.append(prefix + "structuralLines must be an array")
        else:
            for line_index, line in enumerate(lines):
                lp = f"{prefix}structuralLines[{line_index}]."
                if not isinstance(line, dict):
                    errors.append(lp[:-1] + " must be an object")
                    continue
                errors.extend(require_fields(line, ["objectId", "role", "startAnchor", "endAnchor", "semanticOwner"], lp))
                if line.get("role") not in LINE_ROLES:
                    errors.append(lp + "role is not allowed")
                if any(not str(line.get(name, "")).strip() for name in ("startAnchor", "endAnchor", "semanticOwner")):
                    errors.append(lp + "startAnchor, endAnchor, and semanticOwner are required")
        accessibility = slide.get("accessibility")
        if not isinstance(accessibility, dict) or not isinstance(accessibility.get("minBodyPt"), (int, float)) or accessibility.get("minBodyPt", 0) < 16:
            errors.append(prefix + "accessibility.minBodyPt must be at least 16")
    if sequences and (len(sequences) != len(set(sequences)) or sequences != sorted(sequences)):
        errors.append("slide sequences must be unique and increasing")
    if contract.get("contractPhase") == "REPRESENTATIVE":
        kinds = [slide.get("representativeKind") for slide in slides if isinstance(slide, dict)]
        if sorted(kinds) != sorted(["RATIONAL_STRATEGY", "RELATIONSHIP_ANALYSIS", "IMMERSIVE_CLIMAX"]):
            errors.append("REPRESENTATIVE contracts require exactly the rational, relationship, and climax page kinds")
    if errors:
        raise DirectorError(EXIT_SCHEMA, "Slide contracts are invalid", errors)
    return contract


def command_validate_slides(args: argparse.Namespace) -> dict[str, Any]:
    direction = validate_direction(load_json(args.direction))
    slides = validate_slides(load_json(args.input), direction)
    return {"ok": True, "directionHash": direction["directionHash"], "slideCount": len(slides["slides"])}


def command_validate_representative_gate(args: argparse.Namespace) -> dict[str, Any]:
    contracts = require_object(load_json(args.contracts), "representative slide contracts")
    if contracts.get("contractPhase") != "REPRESENTATIVE":
        raise DirectorError(EXIT_SCHEMA, "Representative gate requires REPRESENTATIVE slide contracts")
    slides = contracts.get("slides") if isinstance(contracts.get("slides"), list) else []
    required_kinds = {"RATIONAL_STRATEGY", "RELATIONSHIP_ANALYSIS", "IMMERSIVE_CLIMAX"}
    if len(slides) != 3 or {slide.get("representativeKind") for slide in slides if isinstance(slide, dict)} != required_kinds:
        raise DirectorError(EXIT_SCHEMA, "Representative gate requires exactly the rational, relationship, and climax pages")
    evidence = require_object(load_json(args.input), "representative render evidence")
    pptx = evidence.get("pptx") if isinstance(evidence.get("pptx"), dict) else {}
    if pptx.get("slideCount") != 3 or len(evidence.get("slides", [])) != 3:
        raise DirectorError(EXIT_SCHEMA, "Representative evidence must contain exactly three rendered slides")
    result = command_evaluate_qa(SimpleNamespace(input=args.input))
    return {
        "ok": True,
        "decision": result["decision"],
        "directionHash": contracts.get("directionHash"),
        "pageKinds": sorted(required_kinds),
        "evidenceSha256": file_sha256(Path(args.input)),
    }


def command_validate_assets(args: argparse.Namespace) -> dict[str, Any]:
    value = require_object(load_json(args.input), "asset receipts")
    assets = value.get("assets")
    errors: list[str] = []
    blockers: list[dict[str, Any]] = []
    if value.get("schemaVersion") != "1.0.0" or not isinstance(assets, list):
        errors.append("schemaVersion must be 1.0.0 and assets must be an array")
        assets = []
    ids: set[str] = set()
    for index, asset_value in enumerate(assets):
        prefix = f"assets[{index}]"
        if not isinstance(asset_value, dict):
            errors.append(prefix + " must be an object")
            continue
        asset = asset_value
        errors.extend(require_fields(asset, ["assetId", "sha256", "role", "supportsFact", "origin", "rights", "status"], prefix + "."))
        asset_id = asset.get("assetId")
        if not isinstance(asset_id, str) or not asset_id or asset_id in ids:
            errors.append(prefix + ".assetId must be non-empty and unique")
        else:
            ids.add(asset_id)
        if not is_sha256(asset.get("sha256")):
            errors.append(prefix + ".sha256 must be lowercase SHA-256")
        if asset.get("rights") not in RIGHTS:
            errors.append(prefix + ".rights is invalid")
        if asset.get("status") != "READY" or asset.get("rights") in {"UNKNOWN", "QUARANTINED"}:
            blockers.append({"assetId": asset_id, "code": "UNKNOWN_RIGHTS_ASSET", "rights": asset.get("rights"), "status": asset.get("status")})
        if asset.get("supportsFact") is True and asset.get("rights") == "GENERATED":
            blockers.append({"assetId": asset_id, "code": "FABRICATED_EVIDENCE"})
    if errors:
        raise DirectorError(EXIT_SCHEMA, "Asset receipts are invalid", errors)
    if blockers:
        raise DirectorError(EXIT_HARD_VETO, "Asset receipts contain release blockers", [json.dumps(item, ensure_ascii=False) for item in blockers])
    return {"ok": True, "assetCount": len(assets), "coverage": 1.0}


def command_evaluate_qa(args: argparse.Namespace) -> dict[str, Any]:
    evidence = require_object(load_json(args.input), "render evidence")
    findings = evidence.get("findings") if isinstance(evidence.get("findings"), list) else []
    blockers = [finding for finding in findings if isinstance(finding, dict) and finding.get("code") in HARD_VETO_CODES]
    pptx = evidence.get("pptx") if isinstance(evidence.get("pptx"), dict) else {}
    relationships = evidence.get("relationships") if isinstance(evidence.get("relationships"), dict) else {}
    fonts = evidence.get("fonts") if isinstance(evidence.get("fonts"), dict) else {}
    artifacts = evidence.get("artifacts") if isinstance(evidence.get("artifacts"), dict) else {}
    rendered_alignment = evidence.get("renderedAlignment") if isinstance(evidence.get("renderedAlignment"), dict) else {}
    deck_coherence = evidence.get("deckCoherence") if isinstance(evidence.get("deckCoherence"), dict) else None
    review_reasons: list[str] = []
    if evidence.get("schemaVersion") != "2.0.0":
        review_reasons.append("RENDER_EVIDENCE_SCHEMA_MISMATCH")
    if pptx.get("openable") is not True:
        blockers.append({"code": "CORRUPTED_FILE", "slideId": "_deck"})
    if pptx.get("renderer") != "Microsoft PowerPoint" or pptx.get("platform") != "Windows" or not str(pptx.get("rendererVersion", "")).strip():
        review_reasons.append("POWERPOINT_EVIDENCE_MISSING")
    if not is_sha256(artifacts.get("powerPointPdfSha256")) or not is_sha256(artifacts.get("montageSha256")) or artifacts.get("exportWidth") != 3840 or artifacts.get("exportHeight") != 2160:
        review_reasons.append("POWERPOINT_EXPORT_EVIDENCE_MISSING")
    if rendered_alignment.get("decision") != "PASS" or not is_sha256(rendered_alignment.get("evidenceSha256")):
        if rendered_alignment.get("decision") == "FAIL":
            blockers.append({"code": "ALIGNMENT_DRIFT", "slideId": "_deck"})
        else:
            review_reasons.append("ALIGNMENT_EVIDENCE_MISSING")
    if not isinstance(rendered_alignment.get("repairRounds"), int) or not 0 <= rendered_alignment.get("repairRounds", -1) <= 2:
        review_reasons.append("ALIGNMENT_REPAIR_LINEAGE_MISSING")
    if relationships.get("broken", 1) != 0:
        blockers.append({"code": "BROKEN_RELATIONSHIP", "slideId": "_deck"})
    if evidence.get("assetReceiptCoverage") != 1:
        blockers.append({"code": "UNKNOWN_RIGHTS_ASSET", "slideId": "_deck"})
    if fonts.get("missingGlyphs"):
        blockers.append({"code": "MISSING_GLYPH", "slideId": "_deck"})
    if fonts.get("fallbacks"):
        blockers.append({"code": "FONT_FALLBACK_FAILURE", "slideId": "_deck"})
    slides = evidence.get("slides") if isinstance(evidence.get("slides"), list) else []
    if pptx.get("slideCount") != len(slides):
        blockers.append({"code": "MISSING_RENDER", "slideId": "_deck"})
    for slide in slides:
        if not isinstance(slide, dict) or not is_sha256(slide.get("renderSha256")):
            blockers.append({"code": "MISSING_RENDER", "slideId": str(slide.get("slideId", "unknown")) if isinstance(slide, dict) else "unknown"})
        elif slide.get("wholePageRaster") is True:
            blockers.append({"code": "WHOLE_PAGE_RASTER", "slideId": slide.get("slideId")})
    if deck_coherence is None:
        review_reasons.append("DECK_COHERENCE_EVIDENCE_MISSING")
    else:
        rendered_slide_ids = [slide.get("slideId") for slide in slides if isinstance(slide, dict) and isinstance(slide.get("slideId"), str)]
        reviewed_slide_ids = deck_coherence.get("reviewedSlideIds")
        outlier_fields = [
            "pageFamilyOutliers",
            "backgroundModeOutliers",
            "typographyOutliers",
            "imageTreatmentOutliers",
            "accentShareOutliers",
            "adjacentTransitionFindings",
        ]
        malformed = (
            not is_sha256(deck_coherence.get("directionHash"))
            or not is_sha256(deck_coherence.get("contractSha256"))
            or deck_coherence.get("montageSha256") != artifacts.get("montageSha256")
            or not isinstance(deck_coherence.get("reviewMethod"), str)
            or len(deck_coherence.get("reviewMethod", "").strip()) < 12
            or not isinstance(reviewed_slide_ids, list)
            or len(reviewed_slide_ids) != len(set(reviewed_slide_ids))
            or set(reviewed_slide_ids) != set(rendered_slide_ids)
            or any(not isinstance(deck_coherence.get(field), list) for field in outlier_fields)
            or not isinstance(deck_coherence.get("declaredExceptions"), list)
        )
        if malformed:
            review_reasons.append("DECK_COHERENCE_EVIDENCE_MISSING")
        outliers = {
            field: deck_coherence.get(field)
            for field in outlier_fields
            if isinstance(deck_coherence.get(field), list) and deck_coherence.get(field)
        }
        if deck_coherence.get("decision") == "FAIL" or outliers:
            blockers.append({"code": "PAGE_FAMILY_DRIFT", "slideId": "_deck", "outliers": outliers})
        elif deck_coherence.get("decision") != "PASS":
            review_reasons.append("DECK_COHERENCE_REVIEW_REQUIRED")
    scores = evidence.get("scores") if isinstance(evidence.get("scores"), dict) else {}
    floor_failures = {name: {"actual": scores.get(name), "minimum": minimum} for name, minimum in FLOORS.items() if not isinstance(scores.get(name), (int, float)) or scores.get(name) < minimum}
    judgment = evidence.get("visualJudgment") if isinstance(evidence.get("visualJudgment"), dict) else {}
    font_inspection = fonts.get("inspection") if isinstance(fonts.get("inspection"), dict) else {}
    if font_inspection.get("verdict") != "PASS" or not is_sha256(font_inspection.get("evidenceSha256")):
        review_reasons.append("FONT_EVIDENCE_MISSING")
    if judgment.get("available") is not True:
        review_reasons.append("VISUAL_JUDGE_UNAVAILABLE")
    if isinstance(judgment.get("confidence"), (int, float)) and judgment["confidence"] < 0.75:
        review_reasons.append("LOW_CONFIDENCE")
    if isinstance(judgment.get("maxOrderDelta"), (int, float)) and judgment["maxOrderDelta"] > 15:
        review_reasons.append("ORDER_SENSITIVE")
    if any(isinstance(scores.get(name), (int, float)) and abs(scores[name] - floor) <= 3 for name, floor in FLOORS.items()):
        review_reasons.append("THRESHOLD_ADJACENT")
    gold = evidence.get("goldBaseline") if isinstance(evidence.get("goldBaseline"), dict) else None
    gold_floor_failures: dict[str, dict[str, Any]] = {}
    if gold is None:
        review_reasons.append("GOLD_BASELINE_EVIDENCE_MISSING")
    else:
        registry = require_object(load_json(GOLD_REGISTRY_PATH), "Gold registry")
        receipt = require_object(load_json(GOLD_RECEIPT_PATH), "Gold reference receipt")
        expected_registry_hash = file_sha256(GOLD_REGISTRY_PATH)
        expected_receipt_hash = file_sha256(GOLD_RECEIPT_PATH)
        if gold.get("registrySha256") != expected_registry_hash:
            review_reasons.append("GOLD_BASELINE_REGISTRY_MISMATCH")
        if gold.get("referenceReceiptSha256") != expected_receipt_hash:
            review_reasons.append("GOLD_BASELINE_RECEIPT_MISMATCH")

        required_dimensions = registry.get("requiredDimensions")
        policy = registry.get("policy") if isinstance(registry.get("policy"), dict) else {}
        samples = registry.get("samples") if isinstance(registry.get("samples"), list) else []
        valid_ids = {sample.get("id") for sample in samples if isinstance(sample, dict)}
        reference_ids = gold.get("referenceIds")
        candidate_hashes = gold.get("candidateRenderHashes")
        rendered_hashes = [slide.get("renderSha256") for slide in slides if isinstance(slide, dict)]
        reference_assets = gold.get("referenceAssets")
        selection_rationale = gold.get("selectionRationale")
        passes = gold.get("comparisonPasses")
        dimension_evidence = gold.get("dimensionEvidence")
        receipt_assets = receipt.get("assets") if isinstance(receipt.get("assets"), list) else []
        receipt_pairs = {
            (asset.get("styleId"), asset.get("sha256"))
            for asset in receipt_assets
            if isinstance(asset, dict)
            and asset.get("role") == "board"
        }

        base_valid = (
            gold.get("mode") == "INTERNAL_NON_REDISTRIBUTED"
            and isinstance(required_dimensions, list)
            and len(required_dimensions) == 6
            and policy.get("role") == "GOLD_QUALITY_FLOOR"
            and policy.get("closedTaxonomy") is False
            and policy.get("redistributeSourceImages") is False
            and isinstance(reference_ids, list)
            and 2 <= len(reference_ids) <= 3
            and len(reference_ids) == len(set(reference_ids))
            and set(reference_ids) <= valid_ids
            and isinstance(reference_assets, list)
            and len(reference_assets) == len(reference_ids)
            and {item.get("styleId") for item in reference_assets if isinstance(item, dict)} == set(reference_ids)
            and all(
                isinstance(item, dict)
                and is_sha256(item.get("sha256"))
                and (item.get("styleId"), item.get("sha256")) in receipt_pairs
                for item in reference_assets
            )
            and isinstance(selection_rationale, str)
            and len(selection_rationale.strip()) >= 24
            and isinstance(candidate_hashes, list)
            and candidate_hashes == rendered_hashes
            and candidate_hashes == judgment.get("candidateRenderHashes")
            and len(candidate_hashes) == len(set(candidate_hashes))
            and all(is_sha256(value) for value in candidate_hashes)
            and isinstance(passes, list)
            and len(passes) == 2
            and {item.get("order") for item in passes if isinstance(item, dict)} == {"FORWARD", "REVERSE"}
            and len({item.get("judgeId") for item in passes if isinstance(item, dict)}) == 2
            and all(
                isinstance(item, dict)
                and isinstance(item.get("judgeId"), str)
                and len(item["judgeId"].strip()) >= 3
                and isinstance(item.get("confidence"), (int, float))
                and not isinstance(item.get("confidence"), bool)
                and item["confidence"] >= 0.75
                and isinstance(item.get("scores"), dict)
                for item in passes
            )
            and all(
                all(
                    isinstance(item["scores"].get(name), (int, float))
                    and not isinstance(item["scores"].get(name), bool)
                    and 0 <= item["scores"].get(name) <= 100
                    for name in required_dimensions
                )
                for item in passes
            )
            and isinstance(dimension_evidence, dict)
        )
        if not base_valid:
            if candidate_hashes != rendered_hashes or candidate_hashes != judgment.get("candidateRenderHashes"):
                review_reasons.append("GOLD_BASELINE_RENDER_MISMATCH")
            else:
                review_reasons.append("GOLD_BASELINE_EVIDENCE_MISSING")
        else:
            dimension_floor = policy.get("dimensionFloor")
            overall_floor = policy.get("overallFloor")
            if not isinstance(dimension_floor, (int, float)) or not isinstance(overall_floor, (int, float)):
                review_reasons.append("GOLD_BASELINE_REGISTRY_INVALID")
            computed_scores: list[float] = []
            for name in required_dimensions:
                item = dimension_evidence.get(name)
                pass_scores = [run["scores"].get(name) for run in passes]
                item_valid = (
                    isinstance(item, dict)
                    and item.get("applicable") is True
                    and isinstance(item.get("score"), (int, float))
                    and not isinstance(item.get("score"), bool)
                    and isinstance(item.get("rationale"), str)
                    and len(item["rationale"].strip()) >= 16
                    and isinstance(item.get("defects"), list)
                    and isinstance(item.get("referenceSignals"), list)
                    and len(item["referenceSignals"]) >= len(reference_ids)
                    and all(isinstance(value, (int, float)) and not isinstance(value, bool) for value in pass_scores)
                )
                if not item_valid:
                    gold_floor_failures[name] = {"actual": None, "minimum": dimension_floor}
                    continue
                expected_score = sum(pass_scores) / len(pass_scores)
                if abs(float(item["score"]) - expected_score) > 0.01:
                    gold_floor_failures[name] = {"actual": item["score"], "minimum": f"computed {expected_score}"}
                    continue
                computed_scores.append(expected_score)
                if expected_score < dimension_floor:
                    gold_floor_failures[name] = {"actual": expected_score, "minimum": dimension_floor}
                elif 0 <= expected_score - dimension_floor < 3:
                    review_reasons.append(f"GOLD_BASELINE_THRESHOLD_ADJACENT:{name}")
            if len(computed_scores) == len(required_dimensions):
                overall = sum(computed_scores) / len(computed_scores)
                if overall < overall_floor:
                    gold_floor_failures["overall"] = {"actual": overall, "minimum": overall_floor}
            order_deltas = [abs(float(passes[0]["scores"][name]) - float(passes[1]["scores"][name])) for name in required_dimensions]
            if max(order_deltas, default=0) > 15:
                review_reasons.append("GOLD_BASELINE_ORDER_SENSITIVE")
            if gold.get("decision") == "REVIEW_REQUIRED":
                review_reasons.append("GOLD_BASELINE_REVIEW_REQUIRED")
            elif gold.get("decision") != "PASS":
                gold_floor_failures["decision"] = {"actual": gold.get("decision"), "minimum": "PASS"}
    if gold_floor_failures:
        floor_failures.update({f"goldBaseline.{name}": value for name, value in gold_floor_failures.items()})
    if blockers:
        decision, code = "FAIL", EXIT_HARD_VETO
    elif floor_failures:
        decision, code = "FAIL", EXIT_QUALITY
    elif review_reasons:
        decision, code = "REVIEW_REQUIRED", EXIT_QUALITY
    else:
        decision, code = "PASS", EXIT_OK
    payload = {
        "ok": decision == "PASS",
        "decision": decision,
        "exitCode": code,
        "hardVetoes": blockers,
        "floorFailures": floor_failures,
        "reviewReasons": sorted(set(review_reasons)),
        "goldBaselineDecision": "FAIL" if gold_floor_failures else ("REVIEW_REQUIRED" if any(reason.startswith("GOLD_BASELINE") for reason in review_reasons) else "PASS"),
        "repairPlan": evidence.get("repairPlan", []),
    }
    if decision != "PASS":
        raise DirectorError(code, f"QA decision is {decision}", [json.dumps(payload, ensure_ascii=False)])
    return payload


def command_select_style(args: argparse.Namespace) -> dict[str, Any]:
    query = " ".join(str(args.query).lower().split())
    if len(query) < 2:
        raise DirectorError(EXIT_SCHEMA, "Style query must contain at least two characters")
    candidates: list[dict[str, Any]] = []
    for path in sorted(STYLE_RECIPE_ROOT.glob("*.json"), key=lambda value: value.name):
        recipe = require_object(load_json(path), f"StyleRecipe {path.name}")
        terms = recipe.get("queryTerms") if isinstance(recipe.get("queryTerms"), list) else []
        jobs = recipe.get("applicableJobs") if isinstance(recipe.get("applicableJobs"), list) else []
        matched_terms = sorted({str(term) for term in terms if isinstance(term, str) and term.lower() in query})
        matched_jobs = sorted({str(job) for job in jobs if isinstance(job, str) and job.lower() in query})
        score = len(matched_terms) * 2 + len(matched_jobs)
        candidates.append({
            "id": recipe.get("id"),
            "score": score,
            "matchedTerms": matched_terms,
            "matchedJobs": matched_jobs,
            "recipeSha256": file_sha256(path),
            "path": f"references/style-recipes/{path.name}",
        })
    candidates.sort(key=lambda item: (-item["score"], str(item["id"])))
    selected = candidates[0] if candidates and candidates[0]["score"] >= 2 else None
    runner_up = candidates[1] if len(candidates) > 1 and candidates[1]["score"] > 0 else None
    return {
        "ok": True,
        "query": query,
        "minimumScore": 2,
        "selectedRecipe": selected,
        "runnerUp": runner_up,
        "fallback": None if selected else "NEUTRAL_GRAMMAR",
        "selectionRule": "highest score, then lexical recipe id; never fall back to the first registry row",
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Compile and validate presentation visual-direction artifacts.")
    sub = parser.add_subparsers(dest="command", required=True)
    compile_parser = sub.add_parser("compile", help="Hash and validate a VisualDirectionLock draft.")
    compile_parser.add_argument("--input", required=True)
    compile_parser.add_argument("--output")
    compile_parser.set_defaults(handler=command_compile)
    direction_parser = sub.add_parser("validate-direction")
    direction_parser.add_argument("--input", required=True)
    direction_parser.set_defaults(handler=command_validate_direction)
    slides_parser = sub.add_parser("validate-slides")
    slides_parser.add_argument("--input", required=True)
    slides_parser.add_argument("--direction", required=True)
    slides_parser.set_defaults(handler=command_validate_slides)
    representative_parser = sub.add_parser("validate-representative-gate")
    representative_parser.add_argument("--input", required=True)
    representative_parser.add_argument("--contracts", required=True)
    representative_parser.set_defaults(handler=command_validate_representative_gate)
    assets_parser = sub.add_parser("validate-assets")
    assets_parser.add_argument("--input", required=True)
    assets_parser.set_defaults(handler=command_validate_assets)
    qa_parser = sub.add_parser("evaluate-qa")
    qa_parser.add_argument("--input", required=True)
    qa_parser.set_defaults(handler=command_evaluate_qa)
    style_parser = sub.add_parser("select-style", help="Select a composable StyleRecipe without preset fallback.")
    style_parser.add_argument("--query", required=True)
    style_parser.set_defaults(handler=command_select_style)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        payload = args.handler(args)
        output = getattr(args, "output", None)
        if output and args.command == "compile":
            dump(payload["direction"], output)
        else:
            dump(payload)
        return EXIT_OK
    except DirectorError as exc:
        exc.payload["exitCode"] = exc.code
        dump(exc.payload)
        return exc.code
    except Exception as exc:  # Stable JSON for unexpected operator errors.
        dump({"ok": False, "message": "Unexpected visual director error", "errors": [f"{type(exc).__name__}: {exc}"], "exitCode": EXIT_PARSE})
        return EXIT_PARSE


if __name__ == "__main__":
    sys.exit(main())
