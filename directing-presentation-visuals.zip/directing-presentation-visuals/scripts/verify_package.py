#!/usr/bin/env python3
"""Verify a host-compatible directing-presentation-visuals package."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path, PurePosixPath
from typing import Any


SHA_RE = re.compile(r"^[a-f0-9]{64}$")
SEMVER_RE = re.compile(r"^[0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z.-]+)?$")
SAFE_PATH_RE = re.compile(r"^(?!/)(?!.*(?:^|/)\.\.(?:/|$))[A-Za-z0-9._/-]+$")


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError(f"{path.name} must contain a JSON object")
    return value


def canonical_contribution_source(value: dict[str, Any]) -> str:
    source = {
        "schemaVersion": value["schemaVersion"],
        "skill": {
            "id": value["skill"]["id"],
            "version": value["skill"]["version"],
            "source": value["skill"]["source"],
            "license": value["skill"]["license"],
        },
        "applicability": {
            "taskKinds": list(value["applicability"]["taskKinds"]),
            "confidence": value["applicability"]["confidence"],
        },
        "inspiration": {
            "referencePackIds": list(value["inspiration"]["referencePackIds"]),
            "queryHints": list(value["inspiration"]["queryHints"]),
        },
        "visualRules": {
            "composition": list(value["visualRules"]["composition"]),
            "whitespace": list(value["visualRules"]["whitespace"]),
            "hierarchy": list(value["visualRules"]["hierarchy"]),
            "imageTreatment": list(value["visualRules"]["imageTreatment"]),
        },
        "promptFragments": {
            "positive": list(value["promptFragments"]["positive"]),
            "negative": list(value["promptFragments"]["negative"]),
        },
        "suggestedArchetypes": list(value["suggestedArchetypes"]),
        "antiPatterns": list(value["antiPatterns"]),
        "qaRubric": list(value["qaRubric"]),
    }
    return json.dumps(source, ensure_ascii=False, separators=(",", ":"))


def canonical_file_table(files: list[dict[str, str]]) -> str:
    table = [{"path": item["path"], "sha256": item["sha256"]} for item in sorted(files, key=lambda item: item["path"])]
    return json.dumps(table, ensure_ascii=False, separators=(",", ":"))


def regular_files(root: Path) -> dict[str, Path]:
    output: dict[str, Path] = {}
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise ValueError(f"symlink is forbidden: {path}")
        if path.is_file():
            relative = path.relative_to(root).as_posix()
            output[relative] = path
    return output


def verify(skill_root: Path) -> dict[str, Any]:
    manifest_path = skill_root / "manifest.json"
    contribution_path = skill_root / "contribution.json"
    skill_path = skill_root / "SKILL.md"
    if not skill_path.is_file() or not skill_path.read_text(encoding="utf-8").strip():
        raise ValueError("SKILL_MD_EMPTY")
    manifest = load_json(manifest_path)
    contribution = load_json(contribution_path)
    if manifest.get("schemaVersion") != "2.0.0":
        raise ValueError("MANIFEST_SCHEMA_MUST_BE_2.0.0")
    identity = (manifest.get("id"), manifest.get("version"))
    contribution_identity = (contribution.get("skill", {}).get("id"), contribution.get("skill", {}).get("version"))
    if identity != contribution_identity or identity[0] != "directing-presentation-visuals":
        raise ValueError("PACKAGE_IDENTITY_MISMATCH")
    if not SEMVER_RE.fullmatch(str(identity[1])):
        raise ValueError("INVALID_SEMVER")
    runtime = manifest.get("runtime", {})
    if runtime != {
        "protocol": "HOST_ACTIONS_V1",
        "entrypoint": "directing-presentation-visuals",
        "actions": ["COMPILE_VISUAL_DIRECTION"],
        "timeoutMs": 2000,
    }:
        raise ValueError("UNREVIEWED_HOST_RUNTIME")
    source_hash = sha256_bytes(canonical_contribution_source(contribution).encode("utf-8"))
    if source_hash != manifest.get("sourceHash") or source_hash != contribution.get("skill", {}).get("sourceHash"):
        raise ValueError("SOURCE_HASH_MISMATCH")
    integrity = manifest.get("integrity", {})
    if integrity.get("algorithm") != "sha256" or not isinstance(integrity.get("files"), list):
        raise ValueError("INVALID_INTEGRITY_TABLE")
    files = integrity["files"]
    declared: dict[str, str] = {}
    for item in files:
        if not isinstance(item, dict) or set(item) != {"path", "sha256"}:
            raise ValueError("INVALID_INTEGRITY_ENTRY")
        relative = item["path"]
        digest = item["sha256"]
        if not isinstance(relative, str) or not SAFE_PATH_RE.fullmatch(relative) or PurePosixPath(relative).is_absolute():
            raise ValueError(f"UNSAFE_PACKAGE_PATH:{relative}")
        if relative in declared or not isinstance(digest, str) or not SHA_RE.fullmatch(digest):
            raise ValueError(f"INVALID_INTEGRITY_ENTRY:{relative}")
        declared[relative] = digest
    if not {"SKILL.md", "contribution.json"} <= set(declared):
        raise ValueError("PACKAGE_INTEGRITY_REQUIRED_FILE_MISSING")
    actual = regular_files(skill_root)
    actual_without_manifest = {name: path for name, path in actual.items() if name != "manifest.json"}
    if set(actual_without_manifest) != set(declared):
        missing = sorted(set(declared) - set(actual_without_manifest))
        extra = sorted(set(actual_without_manifest) - set(declared))
        raise ValueError(f"PACKAGE_FILE_SET_MISMATCH:missing={missing}:extra={extra}")
    for relative, expected in declared.items():
        digest = sha256_bytes(actual_without_manifest[relative].read_bytes())
        if digest != expected:
            raise ValueError(f"PACKAGE_FILE_HASH_MISMATCH:{relative}")
    root_hash = sha256_bytes(canonical_file_table(files).encode("utf-8"))
    if root_hash != integrity.get("rootHash"):
        raise ValueError("SKILL_PACKAGE_ROOT_HASH_MISMATCH")
    return {
        "ok": True,
        "id": identity[0],
        "version": identity[1],
        "sourceHash": source_hash,
        "rootHash": root_hash,
        "fileCount": len(files),
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Verify Skill identity, host action, contribution hash, and every file hash.")
    parser.add_argument("--skill", required=True)
    args = parser.parse_args(argv)
    try:
        result = verify(Path(args.skill).resolve())
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False, indent=2, sort_keys=True))
        return 1


if __name__ == "__main__":
    sys.exit(main())
