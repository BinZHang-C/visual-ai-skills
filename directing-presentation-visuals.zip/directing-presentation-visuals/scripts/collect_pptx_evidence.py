#!/usr/bin/env python3
"""Collect hash-bound PPTX, OOXML, render, font, and relationship evidence."""

from __future__ import annotations

import argparse
import hashlib
import json
import posixpath
import re
import struct
import sys
import zipfile
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET


NS = {
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "c": "http://schemas.openxmlformats.org/drawingml/2006/chart",
    "p": "http://schemas.openxmlformats.org/presentationml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "pr": "http://schemas.openxmlformats.org/package/2006/relationships",
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json(path: str | None, default: Any) -> Any:
    if not path:
        return default
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def png_size(path: Path) -> tuple[int, int]:
    header = path.read_bytes()[:24]
    if len(header) < 24 or header[:8] != b"\x89PNG\r\n\x1a\n" or header[12:16] != b"IHDR":
        raise ValueError(f"not a PNG: {path}")
    return struct.unpack(">II", header[16:24])


def natural_key(path: Path) -> list[Any]:
    return [int(part) if part.isdigit() else part.lower() for part in re.split(r"(\d+)", path.name)]


def xml(zf: zipfile.ZipFile, name: str) -> ET.Element:
    return ET.fromstring(zf.read(name))


def slide_parts(zf: zipfile.ZipFile) -> list[str]:
    pattern = re.compile(r"^ppt/slides/slide(\d+)\.xml$")
    found = [(int(match.group(1)), name) for name in zf.namelist() if (match := pattern.match(name))]
    return [name for _, name in sorted(found)]


def count_slide_objects(root: ET.Element) -> dict[str, int]:
    text = sum(1 for shape in root.findall(".//p:sp", NS) if shape.find("p:txBody", NS) is not None)
    all_shapes = len(root.findall(".//p:sp", NS)) + len(root.findall(".//p:grpSp", NS))
    line = len(root.findall(".//p:cxnSp", NS))
    image = len(root.findall(".//p:pic", NS))
    chart = len(root.findall(".//c:chart", NS))
    table = len(root.findall(".//a:tbl", NS))
    return {"text": text, "image": image, "shape": max(0, all_shapes - text), "line": line, "chart": chart, "table": table}


def relationship_evidence(zf: zipfile.ZipFile) -> tuple[int, int, list[str]]:
    names = set(zf.namelist())
    external = 0
    broken = 0
    broken_paths: list[str] = []
    for rel_name in sorted(name for name in names if name.endswith(".rels")):
        root = xml(zf, rel_name)
        if "/_rels/" in rel_name:
            prefix, rel_file = rel_name.split("/_rels/", 1)
            owner = f"{prefix}/{rel_file[:-5]}"
        elif rel_name == "_rels/.rels":
            owner = ""
        else:
            continue
        for rel in root.findall("pr:Relationship", NS):
            target = rel.get("Target", "")
            if rel.get("TargetMode") == "External":
                external += 1
                continue
            resolved = posixpath.normpath(posixpath.join(posixpath.dirname(owner), target)).lstrip("/")
            if resolved and resolved not in names:
                broken += 1
                broken_paths.append(f"{rel_name}:{target}->{resolved}")
    return external, broken, broken_paths


def font_evidence(zf: zipfile.ZipFile) -> tuple[list[str], list[str]]:
    declared: set[str] = set()
    for name in zf.namelist():
        if not (name.startswith("ppt/") and name.endswith(".xml")):
            continue
        try:
            root = xml(zf, name)
        except ET.ParseError:
            continue
        for element in root.iter():
            typeface = element.get("typeface")
            if typeface:
                declared.add(typeface)
    embedded = sorted(name for name in zf.namelist() if name.startswith("ppt/fonts/") or name.startswith("ppt/embeddings/"))
    return sorted(declared), embedded


def embedded_image_hashes(zf: zipfile.ZipFile) -> list[str]:
    """Return hashes for distinct embedded media binaries, not slide occurrences."""
    image_suffixes = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff", ".webp", ".svg"}
    hashes = {
        hashlib.sha256(zf.read(name)).hexdigest()
        for name in zf.namelist()
        if name.startswith("ppt/media/") and Path(name).suffix.lower() in image_suffixes
    }
    return sorted(hashes)


def receipt_coverage(receipts: Any, image_hashes: list[str]) -> tuple[float, list[dict[str, Any]]]:
    if not image_hashes:
        return 1.0, []
    assets = receipts.get("assets", []) if isinstance(receipts, dict) else []
    ready_hashes = {
        asset.get("sha256")
        for asset in assets
        if isinstance(asset, dict)
        and asset.get("status") == "READY"
        and asset.get("rights") not in {"UNKNOWN", "QUARANTINED"}
        and isinstance(asset.get("sha256"), str)
    }
    covered = set(image_hashes) & ready_hashes
    findings: list[dict[str, Any]] = []
    coverage = len(covered) / len(image_hashes)
    if coverage < 1:
        findings.append({
            "code": "UNKNOWN_RIGHTS_ASSET",
            "severity": "BLOCKING",
            "slideId": "_deck",
            "layerId": "assets",
            "message": f"Hash-matched ready asset receipts cover {len(covered)} of {len(image_hashes)} distinct embedded images.",
            "action": "Add verified receipts or replace the uncovered images.",
            "preserve": ["verified receipts", "accepted slides", "direction lock"],
        })
    return coverage, findings


def collect(args: argparse.Namespace) -> dict[str, Any]:
    pptx = Path(args.pptx).resolve()
    render_dir = Path(args.render_dir).resolve()
    if not pptx.is_file():
        raise FileNotFoundError(pptx)
    release = load_json(args.powerpoint_release, {})
    if not isinstance(release, dict):
        raise ValueError("powerpoint release JSON must be an object")
    renderer = release.get("renderer") if isinstance(release.get("renderer"), dict) else {}
    pdf_path = Path(str(release.get("pdf", "")))
    montage_path = Path(str(release.get("montage", "")))
    if release.get("candidatePptxSha256") != sha256_file(pptx):
        raise ValueError("powerpoint release summary does not match the candidate PPTX")
    if renderer.get("product") != "Microsoft PowerPoint" or renderer.get("platform") != "Windows" or not str(renderer.get("version", "")).strip():
        raise ValueError("release renderer must be Windows Microsoft PowerPoint")
    if not pdf_path.is_file() or not montage_path.is_file():
        raise ValueError("PowerPoint PDF and montage are required")
    if Path(str(release.get("renderDirectory", ""))).resolve() != render_dir:
        raise ValueError("powerpoint release render directory does not match --render-dir")
    if release.get("pdfSha256") != sha256_file(pdf_path) or release.get("montageSha256") != sha256_file(montage_path):
        raise ValueError("PowerPoint PDF or montage hash does not match the release summary")
    renders = sorted(render_dir.glob("*.png"), key=natural_key)
    with zipfile.ZipFile(pptx) as zf:
        slides = slide_parts(zf)
        presentation = xml(zf, "ppt/presentation.xml")
        slide_size = presentation.find("p:sldSz", NS)
        width = round(int(slide_size.get("cx", "0")) / 9525) if slide_size is not None else 0
        height = round(int(slide_size.get("cy", "0")) / 9525) if slide_size is not None else 0
        counts = [count_slide_objects(xml(zf, name)) for name in slides]
        external, broken, broken_paths = relationship_evidence(zf)
        declared_fonts, embedded_fonts = font_evidence(zf)
        image_hashes = embedded_image_hashes(zf)
    findings: list[dict[str, Any]] = load_json(args.findings, [])
    if not isinstance(findings, list):
        raise ValueError("findings JSON must be an array")
    slide_evidence: list[dict[str, Any]] = []
    for index, slide_name in enumerate(slides):
        if index >= len(renders):
            findings.append({
                "code": "MISSING_RENDER", "severity": "BLOCKING", "slideId": f"slide-{index + 1}", "layerId": "render",
                "message": "No render exists for this slide.", "action": "Render the slide from the current PPTX.",
                "preserve": ["PPTX", "direction lock", "accepted slides"],
            })
            continue
        render = renders[index]
        render_width, render_height = png_size(render)
        native = counts[index]
        whole_page_raster = native["image"] == 1 and sum(native[key] for key in ("text", "shape", "line", "chart", "table")) == 0
        if whole_page_raster:
            findings.append({
                "code": "WHOLE_PAGE_RASTER", "severity": "BLOCKING", "slideId": f"slide-{index + 1}", "layerId": "canvas",
                "message": "The slide contains one image and no essential native objects.", "action": "Restore editable text, data, and diagram layers.",
                "preserve": ["approved visual direction", "verified image"],
            })
        slide_evidence.append({
            "slideId": f"slide-{index + 1}",
            "renderSha256": sha256_file(render),
            "renderWidth": render_width,
            "renderHeight": render_height,
            "nativeCounts": native,
            "wholePageRaster": whole_page_raster,
        })
    if broken:
        findings.append({
            "code": "BROKEN_RELATIONSHIP", "severity": "BLOCKING", "slideId": "_deck", "layerId": "relationships",
            "message": "; ".join(broken_paths[:5]), "action": "Repair or remove broken package relationships.",
            "preserve": ["valid relationships", "native layers", "sources"],
        })
    receipts = load_json(args.asset_receipts, {})
    coverage, receipt_findings = receipt_coverage(receipts, image_hashes)
    findings.extend(receipt_findings)
    scores = load_json(args.scores, {
        "contentHit": 0, "styleFidelity": 0, "visualExecution": 0, "assetQuality": 0,
        "technicalIntegrity": 0, "pageFamilyRhythm": 0, "overall": 0,
    })
    judgment = load_json(args.visual_judgment, {"available": False, "confidence": 0, "maxOrderDelta": 0, "candidateRenderHashes": []})
    gold_baseline = load_json(args.gold_baseline, {})
    font_receipt = load_json(args.font_inspection, {
        "verdict": "UNKNOWN",
        "method": "NOT_PROVIDED",
        "renderer": "UNKNOWN",
        "evidenceSha256": None,
    })
    font_inspection = {
        key: font_receipt.get(key)
        for key in ("verdict", "method", "renderer", "evidenceSha256")
    }
    alignment_path = Path(args.rendered_alignment).resolve() if args.rendered_alignment else None
    alignment = load_json(args.rendered_alignment, {})
    if not isinstance(alignment, dict):
        raise ValueError("rendered alignment evidence must be an object")
    alignment_renderer = alignment.get("renderer") if isinstance(alignment.get("renderer"), dict) else {}
    if not alignment_path or not alignment_path.is_file() or alignment.get("pptxSha256") != sha256_file(pptx):
        raise ValueError("rendered alignment evidence does not match the candidate PPTX")
    if alignment_renderer.get("product") != renderer.get("product") or alignment_renderer.get("platform") != renderer.get("platform") or str(alignment_renderer.get("version")) != str(renderer.get("version")):
        raise ValueError("rendered alignment renderer does not match the PowerPoint release renderer")
    if alignment_renderer.get("exportWidth") != 3840 or alignment_renderer.get("exportHeight") != 2160:
        raise ValueError("rendered alignment evidence must use 3840x2160 PowerPoint renders")
    alignment_deviations = [
        abs(float(item.get("deviationPx", 0)))
        for item in alignment.get("relationships", [])
        if isinstance(item, dict) and isinstance(item.get("deviationPx"), (int, float))
    ]
    coherence_path = Path(args.deck_coherence).resolve()
    deck_coherence = load_json(coherence_path, {})
    if not isinstance(deck_coherence, dict):
        raise ValueError("deck coherence evidence must be an object")
    if deck_coherence.get("montageSha256") != sha256_file(montage_path):
        raise ValueError("deck coherence evidence does not match the PowerPoint montage")
    if set(deck_coherence.get("reviewedSlideIds", [])) != {item["slideId"] for item in slide_evidence}:
        raise ValueError("deck coherence evidence must review every rendered slide ID")
    output = {
        "schemaVersion": "2.0.0",
        "pptx": {
            "sha256": sha256_file(pptx), "openable": True, "slideCount": len(slides), "width": width, "height": height,
            "renderer": renderer["product"], "rendererVersion": str(renderer["version"]), "platform": renderer["platform"],
        },
        "artifacts": {
            "powerPointPdfSha256": sha256_file(pdf_path),
            "montageSha256": sha256_file(montage_path),
            "exportWidth": 3840,
            "exportHeight": 2160,
        },
        "slides": slide_evidence,
        "relationships": {"external": external, "broken": broken},
        "fonts": {"declared": declared_fonts, "embedded": embedded_fonts, "missingGlyphs": [], "fallbacks": [], "inspection": font_inspection},
        "assetReceiptCoverage": coverage,
        "renderedAlignment": {
            "evidenceSha256": sha256_file(alignment_path) if alignment_path and alignment_path.is_file() else None,
            "decision": alignment.get("decision", "REVIEW_REQUIRED"),
            "maxAbsoluteDeviationPx": max(alignment_deviations, default=0),
            "repairRounds": alignment.get("repairRound", 0),
        },
        "deckCoherence": deck_coherence,
        "findings": findings,
        "scores": scores,
        "visualJudgment": judgment,
        "goldBaseline": gold_baseline,
        "decision": args.decision,
        "repairPlan": load_json(args.repair_plan, []),
    }
    return output


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Collect evidence from a real PPTX and its per-slide PNG renders.")
    parser.add_argument("--pptx", required=True)
    parser.add_argument("--render-dir", required=True)
    parser.add_argument("--powerpoint-release", required=True, help="Summary emitted by powerpoint_release.ps1.")
    parser.add_argument("--rendered-alignment", required=True, help="RenderedAlignmentEvidence emitted by rendered_alignment_qa.py.")
    parser.add_argument("--deck-coherence", required=True, help="Montage-bound DeckCoherenceEvidence reviewed against every rendered slide.")
    parser.add_argument("--asset-receipts")
    parser.add_argument("--findings")
    parser.add_argument("--scores")
    parser.add_argument("--visual-judgment")
    parser.add_argument("--gold-baseline", help="Independent Gold comparison evidence bound to the candidate render hashes.")
    parser.add_argument("--font-inspection", help="Render-backed font and glyph inspection receipt. Defaults to UNKNOWN and cannot pass QA.")
    parser.add_argument("--repair-plan")
    parser.add_argument("--decision", choices=["PASS", "FAIL", "REVIEW_REQUIRED"], default="REVIEW_REQUIRED")
    parser.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    try:
        result = collect(args)
        text = json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
        Path(args.output).write_text(text, encoding="utf-8", newline="\n")
        print(json.dumps({"ok": True, "output": str(Path(args.output).resolve()), "pptxSha256": result["pptx"]["sha256"], "slides": len(result["slides"])}, ensure_ascii=False, indent=2))
        return 0
    except Exception as exc:
        print(json.dumps({"ok": False, "error": f"{type(exc).__name__}: {exc}"}, ensure_ascii=False, indent=2))
        return 1


if __name__ == "__main__":
    sys.exit(main())
