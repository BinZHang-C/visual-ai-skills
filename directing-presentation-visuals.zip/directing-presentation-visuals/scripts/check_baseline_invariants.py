#!/usr/bin/env python3
"""Protect inherited Gold, source, threshold, finding-code, and veto invariants."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace
from typing import Any


EXPECTED_GOLD_SHA256 = "325e10fd169d15d0b8a22493965affed70958d0086143174ca5e68a23f0fef50"
EXPECTED_RECEIPT_SHA256 = "811c9a6fdfc72bdadbe0abaa823aee051ad11548fa6d07e4271c02d143564db3"
EXPECTED_SOURCE_IDS = {
    "gold-style-pack-22",
    "gc-minimal-zine-poster",
    "ui-ux-pro-max",
    "design-resources-for-developers",
    "directing-presentation-visuals-2.0.1",
}
EXPECTED_FLOORS = {
    "contentHit": 95,
    "styleFidelity": 85,
    "visualExecution": 85,
    "assetQuality": 85,
    "technicalIntegrity": 95,
    "pageFamilyRhythm": 80,
    "overall": 88,
}
EXPECTED_FINDING_CODES = {
    "CONTRACT_CONFLICT", "CAPABILITY_GAP", "ALIGNMENT_DRIFT", "ORPHAN_RULE",
    "GOLD_BASELINE_EVIDENCE_MISSING", "GOLD_BASELINE_REGISTRY_MISMATCH",
    "GOLD_BASELINE_RECEIPT_MISMATCH", "GOLD_BASELINE_RENDER_MISMATCH",
    "PAGE_FAMILY_DRIFT", "DECK_COHERENCE_EVIDENCE_MISSING",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain an object")
    return value


def import_director(path: Path):
    spec = importlib.util.spec_from_file_location("visual_director_under_test", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot import visual_director.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def build_gold(root: Path, scores: dict[str, float], decision: str) -> dict[str, Any]:
    registry = load(root / "references" / "gold-visual-baseline.json")
    receipt = load(root / "references" / "gold-reference-receipt.json")
    reference_ids = [item["id"] for item in registry["samples"][:2]]
    board_assets = []
    for style_id in reference_ids:
        match = next(item for item in receipt["assets"] if item.get("styleId") == style_id and item.get("role") == "board")
        board_assets.append({"styleId": style_id, "sha256": match["sha256"]})
    evidence = {
        name: {
            "score": value,
            "applicable": True,
            "rationale": f"Independent rendered rationale for {name} against both selected Gold anchors.",
            "defects": [] if value >= 88 else ["Below the inherited Gold dimension floor."],
            "referenceSignals": [f"{style_id} signal" for style_id in reference_ids],
        }
        for name, value in scores.items()
    }
    candidate = "a" * 64
    return {
        "registrySha256": sha256(root / "references" / "gold-visual-baseline.json"),
        "referenceReceiptSha256": sha256(root / "references" / "gold-reference-receipt.json"),
        "mode": "INTERNAL_NON_REDISTRIBUTED",
        "referenceIds": reference_ids,
        "referenceAssets": board_assets,
        "selectionRationale": "The two anchors fit the communication job, page roles, material behavior, and typographic voice.",
        "candidateRenderHashes": [candidate],
        "comparisonPasses": [
            {"judgeId": "judge-forward", "order": "FORWARD", "confidence": 0.9, "scores": scores},
            {"judgeId": "judge-reverse", "order": "REVERSE", "confidence": 0.9, "scores": scores},
        ],
        "dimensionEvidence": evidence,
        "decision": decision,
    }


def build_evidence(root: Path, gold: dict[str, Any], findings: list[dict[str, Any]]) -> dict[str, Any]:
    candidate = "a" * 64
    high_scores = {name: 99 for name in EXPECTED_FLOORS}
    return {
        "schemaVersion": "2.0.0",
        "pptx": {"sha256": "b" * 64, "openable": True, "slideCount": 1, "width": 1920, "height": 1080, "renderer": "Microsoft PowerPoint", "rendererVersion": "test", "platform": "Windows"},
        "artifacts": {"powerPointPdfSha256": "c" * 64, "montageSha256": "d" * 64, "exportWidth": 3840, "exportHeight": 2160},
        "slides": [{"slideId": "slide-1", "renderSha256": candidate, "renderWidth": 3840, "renderHeight": 2160, "nativeCounts": {"text": 1, "image": 0, "shape": 1, "line": 0, "chart": 0, "table": 0}, "wholePageRaster": False}],
        "relationships": {"external": 0, "broken": 0},
        "fonts": {"declared": ["Arial"], "embedded": [], "missingGlyphs": [], "fallbacks": [], "inspection": {"verdict": "PASS", "method": "PowerPoint rendered inspection", "renderer": "Microsoft PowerPoint", "evidenceSha256": "e" * 64}},
        "assetReceiptCoverage": 1,
        "renderedAlignment": {"evidenceSha256": "f" * 64, "decision": "PASS", "maxAbsoluteDeviationPx": 0, "repairRounds": 0},
        "deckCoherence": {
            "directionHash": "1" * 64,
            "contractSha256": "2" * 64,
            "montageSha256": "d" * 64,
            "reviewMethod": "full-size PowerPoint slides plus complete montage review",
            "reviewedSlideIds": ["slide-1"],
            "pageFamilyOutliers": [],
            "backgroundModeOutliers": [],
            "typographyOutliers": [],
            "imageTreatmentOutliers": [],
            "accentShareOutliers": [],
            "adjacentTransitionFindings": [],
            "declaredExceptions": [],
            "decision": "PASS",
        },
        "findings": findings,
        "scores": high_scores,
        "visualJudgment": {"available": True, "confidence": 0.9, "maxOrderDelta": 0, "candidateRenderHashes": [candidate]},
        "goldBaseline": gold,
        "decision": "PASS",
        "repairPlan": [],
    }


def evaluate_expected_failure(director, payload: dict[str, Any], expected_exit: int, expected_token: str) -> None:
    with tempfile.TemporaryDirectory() as folder:
        path = Path(folder) / "evidence.json"
        path.write_text(json.dumps(payload), encoding="utf-8")
        try:
            director.command_evaluate_qa(SimpleNamespace(input=str(path)))
        except director.DirectorError as exc:
            serialized = json.dumps(exc.payload, ensure_ascii=False)
            if exc.code != expected_exit or expected_token not in serialized:
                raise AssertionError(f"unexpected QA failure: exit={exc.code} payload={serialized}") from exc
        else:
            raise AssertionError(f"engineering checks overrode required failure: {expected_token}")


def verify(root: Path) -> dict[str, Any]:
    errors: list[str] = []
    gold_path = root / "references" / "gold-visual-baseline.json"
    receipt_path = root / "references" / "gold-reference-receipt.json"
    ledger_path = root / "references" / "source-absorption-ledger.json"
    gold, receipt, ledger = load(gold_path), load(receipt_path), load(ledger_path)
    if sha256(gold_path) != EXPECTED_GOLD_SHA256:
        errors.append("Gold registry hash changed")
    if sha256(receipt_path) != EXPECTED_RECEIPT_SHA256:
        errors.append("Gold receipt hash changed")
    if len(gold.get("samples", [])) != 22 or receipt.get("styleCount") != 22 or receipt.get("assetCount") != 154 or len(receipt.get("assets", [])) != 154:
        errors.append("Gold sample/asset counts changed")
    if gold.get("policy", {}).get("dimensionFloor") != 88 or gold.get("policy", {}).get("overallFloor") != 90 or gold.get("policy", {}).get("closedTaxonomy") is not False:
        errors.append("Gold floors or open-registry policy changed")
    sources = {item.get("id"): item for item in ledger.get("sources", []) if isinstance(item, dict)}
    if not EXPECTED_SOURCE_IDS <= set(sources):
        errors.append("one or more inherited source entries were removed")
    for source_id in EXPECTED_SOURCE_IDS & set(sources):
        item = sources[source_id]
        if not item.get("absorbedMechanisms") or not item.get("rejected") or not item.get("unverified") or not item.get("licenseBoundary"):
            errors.append(f"source semantics weakened: {source_id}")
    director = import_director(root / "scripts" / "visual_director.py")
    if director.FLOORS != EXPECTED_FLOORS:
        errors.append("independent QA floors changed")
    text_surface = "\n".join(path.read_text(encoding="utf-8") for path in [root / "SKILL.md", root / "references" / "contracts.md", root / "scripts" / "visual_director.py"])
    for code in EXPECTED_FINDING_CODES:
        if code not in text_surface:
            errors.append(f"stable finding code missing: {code}")
    if errors:
        raise AssertionError("; ".join(errors))
    failing_scores = {name: 95.0 for name in gold["requiredDimensions"]}
    failing_scores[gold["requiredDimensions"][0]] = 87.0
    evaluate_expected_failure(director, build_evidence(root, build_gold(root, failing_scores, "FAIL"), []), director.EXIT_QUALITY, "goldBaseline")
    passing_gold_scores = {name: 95.0 for name in gold["requiredDimensions"]}
    veto = {"code": "OVERFLOW", "severity": "BLOCKING", "slideId": "slide-1", "layerId": "body", "message": "Injected hard veto.", "action": "Repair locally.", "preserve": ["accepted slide"]}
    evaluate_expected_failure(director, build_evidence(root, build_gold(root, passing_gold_scores, "PASS"), [veto]), director.EXIT_HARD_VETO, "OVERFLOW")
    drift = build_evidence(root, build_gold(root, passing_gold_scores, "PASS"), [])
    drift["deckCoherence"]["pageFamilyOutliers"] = ["slide-1: undeclared template grammar"]
    drift["deckCoherence"]["decision"] = "FAIL"
    evaluate_expected_failure(director, drift, director.EXIT_HARD_VETO, "PAGE_FAMILY_DRIFT")
    return {"ok": True, "goldSamples": 22, "goldAssets": 154, "inheritedSources": len(EXPECTED_SOURCE_IDS), "floors": EXPECTED_FLOORS, "engineeringCannotOverrideGold": True, "hardVetoCannotBeOverridden": True, "deckCoherenceDriftCannotBeOverridden": True}


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify inherited presentation-visual quality invariants.")
    parser.add_argument("--skill", required=True)
    args = parser.parse_args()
    try:
        result = verify(Path(args.skill).resolve())
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    except Exception as exc:
        print(json.dumps({"ok": False, "error": f"{type(exc).__name__}: {exc}"}, ensure_ascii=False, indent=2))
        return 1


if __name__ == "__main__":
    sys.exit(main())
