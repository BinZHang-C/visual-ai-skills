# Render QA Module

## Evidence order

1. Hash and open the real editable PPTX in Windows desktop PowerPoint.
2. Export every slide at 3840×2160 PNG, a PowerPoint PDF, and a montage.
3. Bind every artifact hash and dimension to the PPTX hash.
4. Inspect each slide at full size; use the montage only for deck rhythm.
5. Collect OOXML/object, relationship, font/glyph, asset, crop, native-editability, and renderer evidence.
6. Run Integrity.
7. Measure every declared Box/Ink/Content anchor relationship from PowerPoint evidence; normalize to 1920×1080 and fail absolute deviation greater than 2 px.
8. Evaluate `DeckCoherenceEvidence` against the complete montage and full-size renders; fail undeclared page-family outliers with `PAGE_FAMILY_DRIFT`.
9. Select two or three communication-fit Gold anchors, verify their hashes through `gold-reference-receipt.json`, and run one forward plus one reversed-order independent comparison.
10. Run Visual Quality only after Integrity, rendered alignment, and deck coherence pass; compute each Gold dimension from the two comparison passes.
11. Repair only safe dependents, compare inventories, rerender affected slides, and refresh every affected hash and decision. Stop after two rounds.

## Integrity hard vetoes

Fail on corrupted or unopenable files; PowerPoint open/export failure; missing PDF, renders, montage, alignment, or deck-coherence evidence; hash-lineage mismatch; broken relationships; missing/unknown-rights required assets; fabricated evidence; whole-page rasterization when native output is required; flattened essential content; overflow; unintended overlap; clipping; broken crop or chart; missing glyph; font fallback failure; unreadable text; accidental title wrap; insufficient contrast; `ALIGNMENT_DRIFT`; `ORPHAN_RULE`; `PAGE_FAMILY_DRIFT`; unsafe repair mutation; or repair-limit excess. If Windows PowerPoint is unavailable, return `REVIEW_REQUIRED` with `POWERPOINT_UNAVAILABLE`.

## Independent visual floors

| Dimension | Minimum |
|---|---:|
| content hit | 95 |
| style fidelity | 85 |
| visual execution | 85 |
| asset quality | 85 |
| technical integrity | 95 |
| page-family rhythm | 80 |
| weighted overall | 88 |

Evaluate overall only after every applicable floor, Gold baseline dimension, and hard veto passes. A high total cannot compensate for a failed dimension.

## Gold baseline evidence

Load `gold-visual-baseline.json` only on the evaluation side. Bind two or three relevant sample IDs, the baseline-registry hash, `gold-reference-receipt.json` hash, selected reference-asset hashes, all candidate render hashes, forward and reversed-order judge passes, six dimension rationales, and the comparison decision. Use `INTERNAL_NON_REDISTRIBUTED` mode because source screenshots are internal evaluation assets and are excluded from the package.

Return `REVIEW_REQUIRED` with `GOLD_BASELINE_EVIDENCE_MISSING` when the block or any required rationale is missing. Use `GOLD_BASELINE_REGISTRY_MISMATCH` or `GOLD_BASELINE_RECEIPT_MISMATCH` when either local reference contract changed. Use `GOLD_BASELINE_RENDER_MISMATCH` when the Gold block, visual judgment, and actual per-slide render hashes differ. Return `FAIL` when any applicable dimension is below 88 or the six-dimension mean is below 90.

Return `REVIEW_REQUIRED` when either independent judge is unavailable, confidence is below 0.75, reversed-order comparable scores differ by more than 15, or a result is fewer than 3 points above a threshold.

## Full-size inspection

Check title wrapping, CJK glyphs, type measures, safe areas, crop/focal point, contrast, native charts/tables, labels/units/sources, canonical visible-ink axes, declared optical offsets, line roles and endpoints, and the slide's role/claim fit.

For decks of eight or more slides, check scale, density, background mode, image treatment, accent share, narrative bridges, transitions, climax, and close. A contact sheet cannot replace full-size inspection.

Treat the montage as a separate coherence gate, not a thumbnail substitute. Compare every slide to its page-family contract and both adjacent slides. Concept alternatives must share one layout grammar; comparison pages must inherit the analytical family; deliberate dark or high-contrast pages must be predeclared pivots with a return to the base system.

Before authorizing full production, apply the same full-size and Gold review to the rational strategy, relationship/analysis, and immersive climax representative pages. Technical correctness cannot override a failed Visual DNA or representative-page gate.

## Repair order

1. truth, rights, lineage, and file integrity;
2. overflow, overlap, clipping, crop, glyph, contrast, rendered alignment, and orphan lines;
3. content reduction and prioritization;
4. composition or page-role fit;
5. asset or data-encoding replacement;
6. font-size reduction only after earlier options.

Preserve accepted work. Never default to full-deck regeneration.

For automatic repair, move only an explicitly allowed dependent decoration/helper. Never change copy, typography, image crop/focus, grid, hierarchy, page family, locked content, or undeclared objects. Require a pre/post inventory diff proving only authorized `left`/`top` fields changed.
