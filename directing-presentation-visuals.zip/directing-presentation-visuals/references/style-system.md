# Style System Module

## Contract

Translate free-form cues into continuous axes and mechanisms. A style label is evidence about intent, not an output ID.

| Axis | Low end | High end | Observable decisions |
|---|---|---|---|
| energy | restrained | expressive | scale contrast, crop tension, accent share |
| rigor | exploratory | systematic | grid strength, repetition, annotation |
| temporality | archival | speculative | type voice, material, image treatment |
| warmth | cool | warm | hue, light, human presence, surface |
| contrast | quiet | dramatic | luminance, scale, figure/ground |
| density | sparse | evidence-rich | measure, whitespace, metadata |
| materiality | flat | tactile/luminous | grain, paper, glass, metal, light |
| image agency | supporting | dominant | crop, scale, placement, text-safe area |

Add topology, type voice, and rhythm as categorical mechanisms. Do not compress them into the four legacy sliders.

## Direction candidate recipe

Create two or three candidates only when the brief leaves a real choice. Each candidate must differ on at least three structural dimensions: topology, image role, type scale/voice, density, material behavior, data language, background sequence, rhythm, or signature device. Color-only, font-only, and decoration-only variants fail.

Express the thesis as:

> Use **[attention/spatial/material mechanism]** to make **[content truth]** feel **[audience-relevant quality]**, so the audience can **[outcome]**.

Lock invariants separately from mutable axes. Page-role modules may vary only declared axes.

## StyleRecipe mechanism

Files under `style-recipes/` are narrow, composable visual mechanisms transformed from trusted sources. They may own axes, applicable page roles, variation choices, prompt hints for non-factual assets, anti-rules, and visual checks. They never own facts, rights, page semantics, data encoding, release decisions, or host actions.

Use `visual_director.py select-style --query "<communication job and cues>"` for deterministic local retrieval. Select only above the explicit score threshold, report the runner-up when present, and return `NEUTRAL_GRAMMAR` on zero match. Never fall back to the first recipe or treat a recipe as a whole-deck template.

## Using the 22-style Gold quality baseline

Retrieve only two or three entries from [gold-visual-baseline.json](gold-visual-baseline.json) before direction approval and Visual Quality. The 22 samples define an evaluation-only Gold floor across composition, typography, image–text integration, spatial rhythm, material treatment, and finish. They remain open calibration anchors rather than the product's permanent catalog. Do not copy page skeletons, expose reference pixels at the generation boundary, or infer rights from a design-status label.

Select references by communication fit, page roles, asset availability, and data needs. If no sample fits, compose a new grammar but retain the six dimension floors. If references fit equally, show the structural tradeoff or return `REVIEW_REQUIRED`; never choose the first row by registry order. Record IDs, transformed signals, registry and receipt hashes, selected reference fingerprints, candidate render hashes, two order-reversed runs, per-dimension rationale/defects/signals, and the computed decision. Keep the 154 source screenshots outside the distributable package; the path-free fingerprint receipt contains no pixels or source paths.

A candidate below any applicable dimension floor fails Gold even if its total score passes. Do not reduce the baseline to color, font, or style-name resemblance.

## Rhythm

Review at least eight slides when available. Vary scale (immersive/normal/detail), density (sparse/moderate/evidence-rich), background (light/dark/image-led), and action (reveal/compare/explain/prove/decide). Repeat system variables, not identical silhouettes.

## Common mistakes

- “Premium” becomes black and gold without brand evidence.
- “Futuristic” becomes a purple-blue gradient without a communication reason.
- “Whitespace” becomes empty space without hierarchy or pacing.
- “Magazine” becomes arbitrary collage without reading order, captions, or source truth.
- “Monochrome” becomes low contrast and loses data semantics.
- “Gold comparison” becomes a self-authored total score without reference IDs, render hashes, and six independent dimensions.
