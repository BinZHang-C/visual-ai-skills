# Source Inventory and Distribution Boundary

## Included lineage

- `directing-presentation-visuals` 2.0.1 from `ai-ppt-agent-v2`, baseline commit `a5c27f6`, MIT; version 3.0.0 refactored its reviewed direction, alignment, line-ownership, integrity, and rollback rules, and version 4.0.0 adds the release-gated PowerPoint evidence pipeline without deleting those mechanisms.
- OpenAI Codex Skill authoring and Presentations instructions were process references; no runtime code from those Skills is redistributed.
- The first-party `visual-ai-development-governance` presentation adapter informed the optional cross-stage truth, repeated-failure, parallel-edit, and recovery route. Its Git, cleanup, provider, video, ecommerce, industrial-product, and interior-architecture rules are not copied.
- The user-supplied V4 modification brief contributes workflow requirements and stated OPPO regression facts only. No OPPO slide content, Gold screenshot, or third-party visual asset is included.

## Calibration inputs not redistributed

- `PPT_22款标准视觉风格_Codex图片素材包`: 22 metadata entries and 154 JPEG screenshots. Its README permits internal reference/UI preview but supplies no redistribution license. This pack treats the transformed registry as an evaluation-only Gold quality floor and excludes every screenshot.
- `gc-minimal-zine-poster`: MIT repository used to study whitespace and small-anchor composition. No images or code are included.
- The machine-readable retain/transform/reject record is [source-absorption-ledger.json](source-absorption-ledger.json); every absorbed mechanism names its executable landing and remaining verification gap.
- `design-resources-for-developers`: MIT link index. Linked assets retain their own licenses; no linked asset is included.
- `ui-ux-pro-max`: mixed MIT, Apache-2.0, and OFL subtrees. No code, font, example, remote asset, package manifest, or lockfile is included.

## Trust decision

Third-party scripts were not executed. References were read as static text/data. The distributable contains only newly authored or previously reviewed first-party files under MIT.
