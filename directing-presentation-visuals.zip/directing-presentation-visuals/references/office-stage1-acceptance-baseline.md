# Office Stage 1 Acceptance Baseline

Use for a client-facing office chapter after the office design director has supplied complete page handoffs. This baseline governs collaborative preview acceptance, not publication or editable-PPTX release.

## Accepted behavior specimen

Tai Zi Wan DY03-06 P11–P18 B1＋1F was approved and frozen on 2026-09-18 as a Stage 1 visual chapter. The accepted PDF hash is `a66a3081bfbe372b00c21b7528c9dd09a3873e526aa17cab40a4603eb091011d`; montage hash is `3cbb8c3393332ee0de971d375959356743f9bd3bdc497e89e1461d18d0228800`.

Treat it as evidence that the workflow can produce a coherent chapter—not as a reusable layout, color recipe, image style or project answer.

## Visual behaviors to retain

- One clear audience-facing claim per page.
- Plans and relationship diagrams enlarged to decision scale, not left as raw-sheet thumbnails.
- Immersive pages use one dominant image and restrained copy.
- Concept imagery is paired with a readable project-location anchor when available.
- Project evidence, precedent mechanism and concept visualization remain visually distinguishable.
- The chapter varies plan-led, comparison, image-led and closure silhouettes inside one Visual DNA.
- The montage shows deliberate escalation and a final handoff to the next chapter.
- Full-size inspection occurs before delivery; collision, clipping and footer defects are repaired before human review.

## Collaborative A＋B gate

Mode A checks the complete framework, audience, missing families, narrative rise and placeholders before page production. Mode B checks the rendered page family for condition → strategy → spatial action → effect → node closure, readable evidence, non-repetition and chapter handoff.

Return `JOINT_GATE_PASS` or the appropriate revise state. Do not issue a publication or final-release status from these modes.

Score 1–5 for hierarchy, evidence readability, purposeful whitespace, page-family coherence and client-facing finish. Each must reach 4/5. Joint evidence accuracy and boundary honesty must each reach 5/5; either below 5 blocks the chapter.

## Freeze and regression

After explicit human approval, bind the PDF, montage, slide-image and receipt hashes in a new immutable freeze directory. Continue work in a separate Candidate. A later visual test cannot overwrite or reopen the approved specimen unless the user requests revision, project evidence changes, a source-role error is found or Stage 2 diverges from the approved preview.

