# Release Pipeline

## Ownership boundary

`directing-presentation-visuals` owns Visual DNA, page-family intent, contracts, Gold judgment, and release decision. The `Presentations` layer owns native editable PPTX construction from the approved lock and slide contracts. Windows desktop Microsoft PowerPoint is the only release renderer; other renderers may diagnose but cannot produce release evidence.

## Production handoff

Before handoff, read [two-stage-delivery.md](two-stage-delivery.md). Require either a hash-bound approved `VisualApprovalReceipt` or a recorded `deliveryMode: ONE_PASS_EDITABLE` user override. A Stage 1 preview package alone does not authorize native production.

Pass the approved preview hashes or override evidence, direction hash, slide contracts, asset receipts, and standard component contracts to `Presentations`. Use reusable layouts and named components rather than ad hoc coordinate calculation. Preserve stable shape names through production.

Critical objects require `objectId`, `shapeName`, `kind`, `semanticOwner`, `locked`, `autoRepair`, `maxAutoNudgePx`, and `relationshipIds`. Default titles, body, logos, hero images, charts, and tables to locked with `NONE` repair.

## PowerPoint release run

1. Verify the package and contracts.
2. Copy the candidate PPTX to a temporary diagnostic location; never instrument the source in place.
3. Open the copy through Windows PowerPoint automation.
4. Export each slide at 3840×2160 PNG, export PowerPoint PDF, and assemble a montage.
5. Create isolated diagnostic renders for declared `InkAnchor` objects. Use a supplied content mask or reviewed content-edge evidence for `ContentAnchor`; a picture box is not meaningful content evidence.
6. Normalize measurements to 1920×1080 logical pixels and evaluate every declared relationship.
7. Bind the complete montage to `DeckCoherenceEvidence`, inspect every slide and adjacent transition, and block `PAGE_FAMILY_DRIFT`.
8. Run Integrity, rendered alignment, deck coherence, and Gold judgment in that order.
9. If a safe repair is proposed, apply it only to a separate repair candidate, compare object inventories, rerender affected slides, and repeat. Allow at most two rounds.
10. Bind PPTX, PDF, slide PNGs, montage, alignment evidence, deck-coherence evidence, repair ledger, and final decision by SHA-256.

Use `scripts/powerpoint_release.ps1` for explicit operator rendering and guarded repairs. Use `scripts/rendered_alignment_qa.py` to measure isolated PowerPoint renders and generate evidence/repair proposals. Neither script is a host action.

## Anchor measurement

- `BoxAnchor`: derive from PowerPoint object geometry; use only when the relationship explicitly targets geometry.
- `InkAnchor`: derive from the first/last non-background pixels in an isolated PowerPoint render.
- `ContentAnchor`: derive from a reviewed content mask or diagnostic image that preserves meaningful content edges.

Store the source render hash, actual dimensions, normalized bounding box, measured coordinate, expected offset, deviation, tolerance, and decision. An entered `opticalOffsetPx` is an expectation, not proof.

## Safe repair gate

Permit only a declared dependent object with an allowlisted policy (`NUDGE_X`, `NUDGE_Y`, `NUDGE_XY`, `ADJUST_RULE_ENDPOINT`) and a proposed move no larger than both `maxAutoNudgePx` and 32 logical pixels. Forbid repair of locked objects and content kinds (`TITLE`, `BODY`, `LOGO`, `HERO_IMAGE`, `CHART`, `TABLE`).

Before accepting a repair, compare stable object inventories. Copy, font family, font size, weight, spacing, paragraph structure, width, height, rotation, crop, and all non-target objects must be unchanged. Only allowed position fields of declared targets may differ. Any mismatch is `UNSAFE_REPAIR_MUTATION` and blocks release.

Record round, object ID, relationship ID, pre-deviation, action, logical and point displacement, pre/post PPTX hash, pre/post render hash, inventory hash, and retest result.

## Package layout

Stage 1 preview package: non-editable visual PDF, per-slide images, montage, optional one-raster-per-slide PPTX, hashes, unresolved-decision notes, and approval status.

Stage 2 customer package: editable PPTX, PowerPoint PDF, per-slide PNGs, and montage.

Stage 2 QA package: approval receipt or one-pass override, artifact hashes, font/glyph receipt, asset/right receipts, native-layer evidence, `RenderedAlignmentEvidence`, `DeckCoherenceEvidence`, safe-repair ledger, selected Gold references, six rationales, forward/reverse judgments, and final `PASS`, `FAIL`, or `REVIEW_REQUIRED`.
