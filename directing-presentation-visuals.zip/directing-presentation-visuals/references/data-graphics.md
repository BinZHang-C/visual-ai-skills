# Data Graphics Module

## Start from the question

State the audience question, then select the smallest encoding that answers it.

| Relationship | Preferred encoding |
|---|---|
| ranking/comparison | sorted bar, aligned dot plot |
| trend | line or area with restrained annotation |
| part-to-whole | stacked bar; pie only for few stable parts |
| distribution | histogram, box plot, dot distribution |
| correlation | scatter with sample/scope |
| process | staged sequence with owned connectors |
| causality/system | directed diagram with labeled relationships |
| decision | criteria matrix or option tradeoff |

## Contract

Record dataset/source hash, scope, units, transformations, uncertainty, takeaway, highlighted series, label strategy, native object requirement, and calculation checks. Keep charts, labels, legends, tables, and diagrams native/editable.

Use direct labels when practical. Make the title state the implication, not the chart type. Use color semantically and sparingly. Preserve a visible zero baseline where the encoding requires it. Never create pseudo-3D volume, decorative gauges, or an attractive but unjustified scale.

## Missing data

If reliable values are absent, use an evidence-state table, validation plan, qualitative causal structure, or explicitly labeled illustrative mock data. Never present placeholder or synthetic metrics as factual results.

## Diagram connectors

Create connectors before nodes. Bind endpoints to named anchors; keep edges behind nodes and outside labels. Every line has a role, direction if applicable, and semantic owner. `ORPHAN_RULE` is a release blocker.

## Verification

Recalculate totals and derived values. Check units, labels, source scope, uncertainty, categorical ordering, axis bounds, and contrast from the rendered slide. A structurally editable chart can still fail visual quality.
