# Asset Truth Module

## Classify the asset role

Assign one role before sourcing: `EVIDENCE`, `CONTEXT`, `ATMOSPHERE`, `METAPHOR`, or `PRODUCT_PROOF`. A factual claim must use owned, licensed, or explicitly user-asserted evidence. Generated imagery may supply non-factual atmosphere, texture, illustration, or conceptual metaphor only.

## Receipt

Create one `AssetEvidenceReceipt` per required asset with:

- stable asset ID and SHA-256;
- kind and slide/layer consumers;
- role and whether the asset supports a factual claim;
- origin/provider and source URL or local origin;
- rights: `OWNED`, `LICENSED`, `USER_ASSERTED`, `GENERATED`, `UNKNOWN`, or `QUARANTINED`;
- commercial-use and attribution fields;
- readiness: `READY`, `BROKEN`, or `PLACEHOLDER`;
- pixel dimensions, intended crop, protected focal region, and text-safe region;
- verification date and notes.

Only `READY` assets with acceptable rights may support release. Never hide unknown rights, missing evidence, a broken file, or a placeholder behind a generated substitute.

## Logo and product proof

Use an official vector or high-resolution transparent asset, retain its hash, respect clear space, and never generate or redraw a real logo. Do not invent a UI screenshot, customer, employee, facility, quote, result, or testimonial. Label conceptual or generated imagery when it could be mistaken for reality.

## Image treatment

Request or select the aspect ratio and subject placement required by the slide. Use decisive crops, preserve focal subjects, protect editable text zones, and avoid reusing the same image except as an intentional background motif. Inspect resolution, distortion, crop integrity, contrast, and coherence at full-slide size.

## Source collections

A repository license applies to its index or code, not automatically to linked assets. Verify every downstream asset license. Do not execute downloaded scripts or package third-party assets merely because a reference repository is open source.
