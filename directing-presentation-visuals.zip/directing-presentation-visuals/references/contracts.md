# Artifact Contracts

The JSON Schemas in `schemas/` are authoritative for portable artifacts. A host application's stricter schemas remain authoritative for host execution.

## Lineage

```text
skill ID + version + package root hash
→ three cover-direction render hashes + approval
→ VisualDirectionLock + direction hash
→ three representative-page render hashes + Gold gate
→ non-editable full-deck preview PDF + per-slide render + montage hashes
→ VisualApprovalReceipt or user-declared ONE_PASS_EDITABLE override
→ SlideVisualContracts + direction hash
→ DeckCoherenceContract + direction hash
→ AssetEvidenceReceipts + consumer IDs
→ PPTX hash
→ Windows PowerPoint PDF + per-slide render + montage hashes
→ Integrity decision
→ RenderedAlignmentContract + RenderedAlignmentEvidence
→ DeckCoherenceEvidence + montage hash + reviewed slide IDs
→ Gold registry + hash-only reference receipt + forward/reverse comparison
→ Visual decision
→ safe-repair ledger + object-inventory diff + rerender hashes
→ release package hash
```

Accepted artifacts are immutable. Changing an input creates a new hash-bound version.

## Schemas

- `schemas/visual-direction-lock.schema.json`: approved three-direction cover gate, Visual DNA, axes, invariants, rhythm, and package lineage.
- `schemas/visual-approval-receipt.schema.json`: Stage 1 preview hashes, explicit user approval, approved slide IDs, requested changes, and content-freeze scope authorizing Stage 2.
- `schemas/slide-visual-contract.schema.json`: one slide's role, claim, topology, stable object contracts, anchor relationships, lines, assets, accessibility, and repair preservation.
- `schemas/deck-coherence-contract.schema.json`: shared invariants, page-family grammar, background-mode budget, image treatment, accent policy, planned exceptions, and montage gate.
- `schemas/asset-evidence-receipt.schema.json`: asset identity, role, rights, readiness, provenance, dimensions, and crop intent.
- `schemas/rendered-alignment-contract.schema.json`: named objects, Box/Ink/Content anchors, expected relationships, tolerance, and safe-repair policy.
- `schemas/rendered-alignment-evidence.schema.json`: PowerPoint diagnostic render hashes, normalized measurements, drift findings, repair proposals, and retest lineage.
- `schemas/render-evidence.schema.json`: PPTX, PowerPoint PDF, render and montage hashes, native object counts, relationship/font/alignment findings, deck-coherence evidence, selected Gold reference hashes, order-reversed comparisons, and release decision.

## Status vocabulary

Use `PASS`, `FAIL`, or `REVIEW_REQUIRED`. Missing evidence never becomes `PASS`. Use `VISUAL_PREVIEW_READY`, `AWAITING_VISUAL_APPROVAL`, `EDITABLE_PRODUCTION_AUTHORIZED`, and `FINAL_EDITABLE_RELEASED` only as workflow states, never as QA substitutes. Preserve `CONTRACT_CONFLICT`, `CAPABILITY_GAP`, `ALIGNMENT_DRIFT`, `ORPHAN_RULE`, `PAGE_FAMILY_DRIFT`, `GOLD_BASELINE_EVIDENCE_MISSING`, `GOLD_BASELINE_REGISTRY_MISMATCH`, `GOLD_BASELINE_RECEIPT_MISMATCH`, and `GOLD_BASELINE_RENDER_MISMATCH`. Add `POWERPOINT_UNAVAILABLE`, `POWERPOINT_EXPORT_FAILED`, `ALIGNMENT_EVIDENCE_MISSING`, `DECK_COHERENCE_EVIDENCE_MISSING`, `DECK_COHERENCE_REVIEW_REQUIRED`, `CONTENT_ANCHOR_EVIDENCE_MISSING`, `VISUAL_APPROVAL_MISSING`, `PREVIEW_HASH_MISMATCH`, `AUTO_REPAIR_FORBIDDEN`, `AUTO_REPAIR_LIMIT_EXCEEDED`, and `UNSAFE_REPAIR_MUTATION` without repurposing existing codes.
