# Host Integration

## Security boundary

The direction compiler remains renderer-neutral. The host owns content ingestion, model calls, asset acquisition, native deck generation, rendering, UI, and persistent objects. Windows desktop PowerPoint is nevertheless the only release renderer. The host may execute only:

```json
{
  "protocol": "HOST_ACTIONS_V1",
  "entrypoint": "directing-presentation-visuals",
  "actions": ["COMPILE_VISUAL_DIRECTION"],
  "timeoutMs": 2000
}
```

Do not auto-run package scripts. They are explicit operator tools, CI fixtures, and rollback material. Do not add `VALIDATE_SLIDE_CONTRACT` or `EVALUATE_VISUAL_EVIDENCE` as host actions until reviewed handlers and contract tests exist.

Do not add PowerPoint COM, file-system repair, `rendered_alignment_qa.py`, or `powerpoint_release.ps1` to the host action allowlist. The release pipeline must be initiated by an explicit operator or CI context with artifact-scoped paths.

## Host action input/output

`COMPILE_VISUAL_DIRECTION` consumes a sanitized brief, selected generation-safe grammar ID, page role, capabilities, and the verified package identity. It returns a `VisualDirectionLock` with no evaluation-only Gold images, anchor IDs, paths, pixels, or credentials.

The direction hash is SHA-256 over canonical lock content excluding `directionHash`. Store the execution trace with action, entrypoint, Skill ID, version, source hash, package root hash, request ID, and output hash.

## Renderer adapters

- Keep essential text, tables, charts, shapes, and diagrams native.
- Put sources in visible footnotes or speaker notes according to product policy.
- Verify fonts and rerender after fallback.
- Export a PNG for every slide and a montage for deck rhythm.
- For release, export from Windows PowerPoint at 3840×2160 plus PowerPoint PDF; other renderers are diagnostic only.
- Render declared anchor objects in a temporary diagnostic copy. Never instrument or repair the source PPTX in place.
- Pass only asset-level prompts to image generation; exclude factual text, data, logos, product UI, and citations.

## Failure behavior

An invalid active version may fall back once to the verified previous version. If both fail, disable only this Skill and continue the base workflow with a visible recoverable status. If PowerPoint is unavailable, return `REVIEW_REQUIRED`; do not substitute another renderer for release. Never silently execute package-local code.
