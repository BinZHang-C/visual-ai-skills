# Office Concept Deck Joint Gate

Use this reference only for client-facing office or workplace concept presentations and reports. It coordinates `interior-canvas-office-designer` as design director with `directing-presentation-visuals` as visual director. It does not impose one visual style, chapter count or project solution.

For framework and chapter-family acceptance during human collaboration, apply `office-stage1-acceptance-baseline.md` together with the office design director's approved chapter baseline. These are Mode A＋B checks, not publication acceptance.

## Authority split

**Office design director owns:**

- communication decision, client story and chapter order;
- project facts, unknowns, design judgments and evidence boundaries;
- spatial consequence, project location and required proof combination;
- whether a precedent is project evidence, a traceable reference mechanism or a replaceable placeholder;
- whether a page is professionally complete enough to face a client.

**Presentation visual director owns:**

- page role, topology, hierarchy, density and silhouette;
- image–text integration, dominant visual object and reading order;
- canonical margins, title axes, plan/image edges, captions, legends and visible-ink alignment;
- purposeful whitespace, page-family coherence, background rhythm and image treatment;
- representative renders, montage review, PowerPoint render evidence and visual release status.

Neither owner may silently overrule the other. A visually elegant page cannot pass without required spatial proof. A professionally correct page cannot pass when its proof is unreadable, fragmented, misaligned or presented as a process draft.

## OfficeSlideContentHandoff

Before visual production, require one handoff per retained slide:

```yaml
OfficeSlideContentHandoff:
  slide_id: ""
  chapter_id: ""
  page_role: ""
  client_question: ""
  intended_client_judgment: ""
  takeaway_title: ""
  single_claim: ""
  project_condition: []
  design_action: []
  spatial_consequence: []
  required_project_evidence: []
  required_visible_proof: []
  precedent_or_placeholder:
    source_ids: []
    role: NONE | REFERENCE_MECHANISM | REPLACEABLE_PLACEHOLDER
    replacement_requirement: ""
    forbidden_inference: ""
  predecessor_connection: ""
  successor_connection: ""
  density_intent: sparse | moderate | evidence-rich
  image_agency: supporting | co-dominant | dominant
  format_constraints: []
  unresolved_tbd: []
  semantic_owner: ""
```

A heading plus plausible copy is not a handoff. If the required proof is absent, preserve the page as `REVISE`; do not fill it with generic cards, copied case imagery or decorative whitespace.

## Format alignment contract

Lock shared axes before producing the full preview:

- one content boundary and title field per page family;
- one declared title baseline/left axis, with an explicit optical offset for CJK/Latin combinations when necessary;
- meaningful plan/image `ContentAnchor` aligned to the relevant title, caption or evidence field;
- consistent caption order: asset role → source/project location → supported proposition;
- legends, page numbers and source labels in stable locations unless the page role declares an exception;
- consistent treatment of project evidence, precedent reference and generated concept imagery so their truth roles cannot be confused;
- no unowned rule, divider, frame or color block.

Judge alignment from full-size renders, not object coordinates. A shared grid does not require identical silhouettes; it requires explainable relationships.

## Purposeful whitespace

Whitespace is a functional spatial relationship, not unused canvas. Every substantial empty region must perform at least one job:

- isolate the primary judgment;
- separate evidence layers;
- protect an image focal region or route diagram;
- create a deliberate rhythm reset at a cover, claim, pivot, climax or close;
- improve legibility at the intended presentation distance.

Reject `DECORATIVE_WHITESPACE` when evidence or plans are reduced to thumbnails while large empty fields remain; when missing content is disguised as minimalism; when text and image have no shared axis; or when several adjacent pages repeat the same sparse silhouette. Do not apply a universal whitespace percentage. Match whitespace to page role and evidence density.

## Office page-family minimums

### Project understanding / strategy

- One claim and one dominant proof object.
- Use an annotated plan, section, journey, relationship diagram or decisive project image—not an equal-card summary by default.
- A strategy must point to a project location and a visible spatial action.

### Plan / circulation / relationship

- Plans must be cropped and enlarged to the decision area.
- Routes, nodes, conflicts, thresholds and legends must be directly readable.
- A raw full-sheet screenshot or small PDF thumbnail is not proof.

### Concept / translation

- Show how the concept changes interface, form, light, material, service, movement or occupation.
- Pair an atmospheric climax with project-specific translation; do not rely on naming, adjectives or symbolic graphics alone.

### Space / effect

- Use a dominant spatial image with a small, readable project-location anchor when available.
- Label generated or precedent imagery by truth role. Do not present it as a current project effect.

### Material / lighting / furniture / art / signage / node

- Return to a space and proposition already introduced.
- Show system logic, application location and design consequence, not a detached mood board or shopping list.

## Real-project baseline

When the user supplies a complete professional tender or concept deck as a quality reference, treat it as a minimum maturity and completeness floor, not a template. Extract only communication mechanisms such as image agency, page-family coverage, plan readability, spatial proof combinations, annotation grammar, section rhythm and finish. Do not copy its project solution, proprietary artwork, branding, exact page skeleton or unsupported claims.

Before full production, compare three representative pages:

1. `RATIONAL_STRATEGY` — project strategy with visible spatial consequence;
2. `RELATIONSHIP_ANALYSIS` — plan/flow/adjacency evidence at readable scale;
3. `IMMERSIVE_CLIMAX` — a concept or spatial image-led page with disciplined text.

All three must pass both the design-director proof requirements and the applicable Gold visual floors.

## Joint review

Review content and form in this order:

1. Does the page answer one client question and earn one judgment?
2. Is the claim supported by current project evidence or honestly bounded reference material?
3. Is the spatial consequence visible at presentation distance?
4. Does the page role expose the relationship instead of hiding it in cards or prose?
5. Are title, text, image, plan, caption, legend and source labels aligned to a shared grammar?
6. Is whitespace purposeful for this role and density?
7. Does the page connect to the previous and next page without repetition?
8. Does the complete montage show scale, density and background variation inside one visual system?

Return one of:

- `JOINT_GATE_PASS`: content proof and rendered visual form both pass;
- `JOINT_GATE_REVISE_CONTENT`: content, project evidence or spatial consequence is incomplete;
- `JOINT_GATE_REVISE_VISUAL`: content is sufficient but hierarchy, scale, alignment, whitespace or page-family execution fails;
- `JOINT_GATE_REVISE_BOTH`: content and visual form are coupled failures;
- `REVIEW_REQUIRED`: required artifact or rendered evidence is missing.

For Mode A＋B, all five applicable quality dimensions must be at least 4/5, while evidence accuracy and boundary honesty must each be exactly 5/5. Human approval freezes the bound preview hashes; later candidates do not silently replace the accepted specimen.

Useful failure codes: `CONTENT_PROOF_GAP`, `EVIDENCE_THUMBNAIL_FAILURE`, `PROJECT_REFERENCE_ROLE_CONFLICT`, `DECORATIVE_WHITESPACE`, `FORMAT_ALIGNMENT_DRIFT`, `REPEATED_SILHOUETTE`, and `PAGE_FAMILY_DRIFT`.
