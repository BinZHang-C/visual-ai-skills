# Two-Stage Visual-First Delivery

## Default

Use two-stage delivery for a new deck or a substantial visual redesign. Stage 1 confirms the visual system with non-editable artifacts. Stage 2 begins native editable PowerPoint production only after explicit approval.

Bypass Stage 1 only when the user explicitly requests one-pass editable delivery, supplies an already approved direction/template, or asks for a narrowly scoped edit to an existing editable deck. Record the bypass as `deliveryMode: ONE_PASS_EDITABLE` with the user instruction that authorized it.

## Stage 1 — visual preview

Optimize for fast decisions about story, hierarchy, page rhythm, image mood, composition, density, and visual direction. Do not spend time on master slides, native chart construction, stable shape naming, full editability, or final PowerPoint repair unless needed to prove the direction.

Deliver:

- `visual-preview.pdf`, clearly labeled `VISUAL PREVIEW — NON-EDITABLE`;
- one full-resolution PNG or JPG per slide;
- one complete montage/contact sheet;
- optionally, an image-based PPTX with exactly one full-slide raster image per page;
- hashes for the PDF, slide images, montage, and optional raster PPTX;
- preview notes listing unresolved copy, data, image-rights, and content decisions.

Keep factual integrity active in Stage 1. Do not fabricate brands, facilities, people, quotations, metrics, screens, or sources. Generated imagery may still serve only non-factual atmosphere, metaphor, texture, or illustration. Label placeholder or generated assets visibly when their status could be misunderstood.

The Stage 1 preview may be created with raster-first composition or another fast visual method. It is intentionally not the editable source of truth. Its purpose is visual approval, not downstream editing.

## Approval gate

Do not infer approval from silence, download, praise, or the absence of requested changes. Obtain an explicit instruction such as “确认方向，生成可编辑 PPT” before Stage 2.

Bind approval in a `VisualApprovalReceipt`:

```json
{
  "deliveryMode": "TWO_STAGE",
  "approved": true,
  "approvedAt": "ISO-8601 timestamp",
  "userInstruction": "verbatim or faithful approval summary",
  "directionHash": "sha256",
  "previewPdfSha256": "sha256",
  "montageSha256": "sha256",
  "approvedSlideIds": ["slide-01"],
  "requiredChanges": [],
  "contentFreeze": "FULL | PARTIAL | NONE"
}
```

If the user requests changes, remain in Stage 1. Revise only the affected preview pages when the accepted system can be preserved, increment the preview version, regenerate the PDF/montage, and request approval again.

## Stage 2 — editable production

Use the approved preview and direction hash as immutable visual references. Build native text, shapes, diagrams, charts, tables, reusable layouts, and named components through the `Presentations` production layer. Preserve accepted composition, hierarchy, crop intent, page-family membership, and visual pacing unless the approval receipt authorizes changes.

Stage 2 activates the full release pipeline: Windows PowerPoint rendering, font/glyph evidence, native-layer evidence, rendered alignment, deck coherence, safe repair, hashes, PDF, per-slide PNGs, montage, and final QA ledger.

If native constraints require a visible departure from the approved preview, stop and request approval for the affected slides rather than silently redesigning them.

## Status language

- Stage 1 completion: `VISUAL_PREVIEW_READY`; never call it a final editable deck.
- Awaiting user confirmation: `AWAITING_VISUAL_APPROVAL`.
- Stage 2 authorized: `EDITABLE_PRODUCTION_AUTHORIZED`.
- Stage 2 complete after all release gates: `FINAL_EDITABLE_RELEASED`.
