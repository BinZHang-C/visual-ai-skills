# Page Role Module

## One contract per slide

Assign exactly one primary page role and one audience-facing claim. Choose a topology that exposes the semantic relationship; do not default to cards because the content has multiple points.

| Role | Job | Useful topology | Rhythm behavior |
|---|---|---|---|
| cover/hook | establish thesis and tension | singular object, full image, type statement | sparse, high contrast |
| context/problem | make stakes legible | contrast, annotated evidence, causality | moderate build |
| claim | assert one idea | dominant statement + one proof | sparse reset |
| comparison/decision | reveal a choice | aligned axes, paired evidence, criteria | controlled density |
| process/system | explain mechanism | sequence, containment, topology | progressive reveal |
| data/evidence | make pattern and implication obvious | native chart, direct labels | evidence-rich |
| quote/source | establish credibility | document crop, sourced quote | restrained |
| section/pivot | reset pace | low-density transition | breathing page |
| recommendation | focus action | option hierarchy + explicit ask | decisive |
| close | resolve thesis | returned motif + next step | sparse resolution |

## Required fields

Bind slide ID, sequence, role, direction hash, claim, takeaway title, evidence state, topology, hierarchy, density, silhouette, typography, whitespace, imagery, native layers, stable object contracts, anchor relationships, accessibility, continuity, and repair-preservation fields.

Before the full-deck preview, make three representative contracts: `RATIONAL_STRATEGY`, `RELATIONSHIP_ANALYSIS`, and `IMMERSIVE_CLIMAX`. Render all three through the chosen non-editable Stage 1 preview method and pass the applicable Gold floors. Shared Visual DNA does not permit repeated silhouettes: vary scale, density, spatial behavior, and focal mechanism. Windows PowerPoint rendering becomes mandatory only for the approved Stage 2 editable release.

## Standard components

- `TextRulePair`: bind text `InkAnchor` to its owned line; the line is the default repair dependent.
- `ImageTextAxis`: bind meaningful image `ContentAnchor` to text `InkAnchor`; require a reviewed content mask or content-edge receipt.
- `AlignedGroup`: declare a shared axis or equal-spacing relationship among named objects.
- `OwnedRule`: bind a line role, endpoints, semantic owner, and repair policy.

Every critical object has a stable `objectId` and PowerPoint `shapeName`. Record `kind`, `semanticOwner`, `locked`, `autoRepair`, `maxAutoNudgePx`, and `relationshipIds`. Lock titles, body text, logos, hero images, charts, and tables with `autoRepair: NONE` unless an explicit reviewed exception exists.

### Visible-ink alignment

Distinguish `BoxAnchor`, `InkAnchor`, and `ContentAnchor`. Declare named relationships with a canonical axis (`LEFT`, `CENTER_X`, `RIGHT`, `TOP`, `CENTER_Y`, `BOTTOM`, or `BASELINE`), anchor object, dependent object, expected offset, and tolerance no greater than 2 logical pixels. If CJK/Latin side bearings, weight, or optical size requires a correction, declare the expected offset and reason before rendering.

Measure rendered ink/content from 3840×2160 PowerPoint evidence normalized to 1920×1080. Emit `ALIGNMENT_DRIFT` when absolute deviation from the declared relationship is greater than 2 px. A declared offset or object coordinate is not evidence.

### Structural lines

Every structural line uses exactly one role:

- `LABEL_MARKER`: stays adjacent and aligned to its label.
- `REGION_SEPARATOR`: spans the regions it separates.
- `SEQUENCE`: connects ordered stages.
- `BOUNDARY`: closes a semantic frame.

Bind `startAnchor`, `endAnchor`, and `semanticOwner`. Create connectors before entity nodes so connectors remain behind labels and nodes. Emit `ORPHAN_RULE` when a line has no allowed role, bound endpoints, or explainable relationship. Omit purely decorative rules.

## Geometry

Use regular geometry when precision, comparison, or evidence dominates. Use irregular geometry only when it reinforces attention or meaning; preserve focal points, avoid shape soup, and keep text out of unstable masks. Verify every crop and custom shape after rendering.

## Repair

Preserve the claim, verified evidence, direction hash, accepted assets, native layers, sources, and approved neighboring slides. Default to moving the declared decorative dependent, never the content anchor. Require `maxAutoNudgePx ≤ 32`, compare pre/post object inventories, and rerender only affected slides. Stop after two rounds or if any copy, typography, crop, hierarchy, locked object, or undeclared object changes.
