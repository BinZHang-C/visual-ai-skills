# Deck Coherence Module

Use for full-deck production, montage review, visual-consistency feedback, or repair. It closes the gap where individual slides look polished but several pages behave like unrelated templates.

## Failure definition

Emit `PAGE_FAMILY_DRIFT` when an undeclared slide or group of slides departs from the locked Visual DNA in any of these ways:

- background mode or contrast becomes a new visual system instead of a planned pivot;
- title anchor, text-field grammar, type voice, or annotation hierarchy changes without a page-role reason;
- image color temperature, material palette, lighting, or crop language falls outside the shared image grammar;
- accent color becomes a dominant surface rather than its declared semantic role;
- concept alternatives use different presentation templates instead of one shared page family;
- a comparison, matrix, or data page adopts a separate report/dashboard aesthetic;
- adjacent slides create an accidental style jump visible in the PowerPoint montage.

Deliberate contrast is not drift. Bind every deliberate exception to a page role, slide ID, transition purpose, and return path to the base system.

## DeckCoherenceContract

Lock this before full production:

- `sharedInvariants`: at least three visible mechanisms that every page family preserves;
- `pageFamilies`: family ID, member slide IDs, shared layout grammar, allowed variation, and forbidden variation;
- `backgroundModeBudget`: declared modes, planned high-contrast slide IDs, maximum consecutive high-contrast slides, and zero undeclared modes;
- `imageTreatment`: target temperature, material palette, lighting behavior, crop grammar, and forbidden visual casts;
- `accentPolicy`: semantic role, approximate surface-share ceiling, and slides allowed to use a dominant accent;
- `montageGate`: full-deck PowerPoint montage required, adjacent transitions inspected, zero undeclared outliers.

Concept-direction pages must share one family contract. Let direction differences appear through spatial subject, mood, material emphasis, or a mirrored composition; do not introduce separate black bars, unrelated title systems, or incompatible color grades.

Comparison pages inherit the analytical family. A table may emphasize the selected option, but it must not create a new full-slide palette or dashboard language unless the lock declares that page as a pivot.

## Evidence gate

After Windows PowerPoint export, record `DeckCoherenceEvidence`:

- direction and contract hashes;
- the exact montage hash and all reviewed slide IDs;
- full-size slide review plus montage review as the method;
- page-family, background-mode, typography, image-treatment, accent-share, and adjacent-transition outlier lists;
- declared exceptions and their role/rationale;
- `PASS`, `FAIL`, or `REVIEW_REQUIRED`.

`PASS` requires all rendered slide IDs to be reviewed, the montage hash to match the release artifact, all undeclared outlier lists to be empty, and every exception to be predeclared. Missing evidence returns `REVIEW_REQUIRED`. Any undeclared outlier returns `FAIL` with `PAGE_FAMILY_DRIFT`.

## Local repair

Preserve accepted slides and content. Repair only the outlier family:

1. identify the nearest accepted page family by role;
2. restore shared background, title anchors, text-field grammar, accent behavior, and image treatment;
3. keep direction-specific meaning through subject, material emphasis, or mirrored composition;
4. re-render affected slides and the complete montage in PowerPoint;
5. refresh coherence evidence and hashes.

This is a design revision, not safe automatic alignment repair. Do not count it as a geometry-only auto-repair round, and do not regenerate the full deck when unaffected slides already pass.
