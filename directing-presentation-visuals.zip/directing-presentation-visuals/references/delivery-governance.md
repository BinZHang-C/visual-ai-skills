# Presentation Delivery Governance

Load this optional module only when the deck workflow crosses stages or sessions, changes an approved scope, repeats the same user-result failure, splits work across agents, produces save/reopen/export mismatch, or is about to make a disputed delivery claim.

## Do not activate

Do not activate for an ordinary first visual direction, a one-off page, a narrow low-risk edit, or the first locally repairable defect. Do not add a governance document when the current brief, approval and artifact lineage are already unambiguous. Governance must shorten the route to a real user result.

## Authority and ownership

- Humans own the communication job, commercial narrative, approved direction, brand deviation and final release decision.
- `core` owns communication job, Visual DNA and direction hash.
- `two-stage-delivery` owns delivery mode, preview hashes, `VisualApprovalReceipt`, content freeze and editable-production authorization.
- `asset-truth` owns `AssetEvidenceReceipts`, rights, provenance, crop intent and asset readiness.
- `deck-coherence` owns `DeckCoherenceContract`, page-family drift and montage-bound coherence evidence.
- `release-pipeline` and `render-qa` own PowerPoint evidence, safe repair and release status.
- `delivery-governance` owns only cross-stage truth, decision invalidation, readiness summary, failed-route memory, parallel-edit ownership and recovery point.

Do not duplicate or replace `VisualApprovalReceipt`, `AssetEvidenceReceipts`, `DeckCoherenceContract`, slide contracts, PowerPoint render evidence or release decisions.

## PresentationTruth

Maintain one current snapshot. Old facts remain in decision history, not in current truth.

```yaml
PresentationTruth:
  updatedAt: ""
  approvedBy: ""
  communicationJob: ""
  audienceOutcome: ""
  centralTakeaway: ""
  approvedNarrative: []
  approvedDirectionHash: ""
  deliveryMode: TWO_STAGE | ONE_PASS_EDITABLE
  contentFreeze: FULL | PARTIAL | NONE
  currentBriefSource: ""
  currentDeckOrPreviewHashes: []
  activeSourceIds: []
  unresolvedDecisions: []
  invalidatedArtifactHashes: []
```

Only human-approved instructions and directly verified artifact state enter current truth. Agent reports, screenshots, thumbnails and unbound exports are lower-level evidence.

## DecisionChangeRecord

Record a change when it invalidates or requires rechecking downstream pages or artifacts.

```yaml
DecisionChangeRecord:
  decisionId: ""
  status: added | refined | replaced | withdrawn
  priorRule: ""
  currentRule: ""
  humanInstruction: ""
  affectedSlideIds: []
  affectedArtifactHashes: []
  preservedSlideIds: []
  invalidatedApprovals: []
  requiredRechecks: []
```

An approved scope or narrative change invalidates dependent previews, slide contracts and approvals even when their files still open. A repair request that preserves the approved contract does not silently reopen unrelated decisions.

## PresentationReadiness

Reuse existing status language; do not invent a competing release scale.

- direction unresolved: report the open decision; do not claim preview readiness.
- `VISUAL_PREVIEW_READY`: Stage 1 artifacts exist and remain non-editable.
- `AWAITING_VISUAL_APPROVAL`: no approval may be inferred from silence, praise or download.
- `EDITABLE_PRODUCTION_AUTHORIZED`: a valid receipt or explicit one-pass override exists.
- release evidence incomplete: return `REVIEW_REQUIRED` with the missing evidence or invalidated hash.
- `FINAL_EDITABLE_RELEASED`: only after the existing Windows PowerPoint, Integrity, alignment, coherence, Gold and package gates pass.

For every status record evidence source, time, scope, what it cannot prove and the next required human or system action.

## RepeatedFailureClosure

Repeated failure means the same audience or delivery result fails a second time, even when the page, prompt, render or implementation changed cosmetically.

1. First failure: use the smallest applicable local correction under the owning module.
2. Second failure: stop repeating the route; compare current truth, approval hash, content source, asset rights, native build, PowerPoint render, persistence/export and capability evidence.
3. Third failure: change diagnostic or production route. Do not extend the two-round safe-repair cap or regenerate accepted pages by default.

```yaml
RepeatedFailureClosure:
  intendedResult: ""
  attemptEvidence: []
  unchangedSymptom: ""
  primaryFailureClass: truth | direction | content | asset | native-build | render | persistence-export | environment-capability
  invalidatedRoute: ""
  revisedHypothesis: ""
  smallestDiscriminatingCheck: ""
  owner: ""
  recoveryCondition: ""
```

This module records evidence and recommends the shortest next check. It does not execute repair, testing, publishing, Git or cleanup.

## ParallelEditMatrix

Before parallel work, record one semantic owner per deck, slide, page family, content block or asset. Include authoritative input, output path, affected IDs, dependency order, accepted hash and integration owner.

If upstream truth, narrative, source data or direction changes, mark every dependent task `recheck_required`. Resolve overlap by current human truth, rights and lineage, complete audience result, accessibility/editability, stronger evidence, smallest safe change and current stability—not by finish time or agent seniority.

## RecoveryPoint

Bind recovery to real artifacts, not chat recollection.

```yaml
RecoveryPoint:
  presentationTruthHash: ""
  decisionRecordIds: []
  directionHash: ""
  approvalReceiptHash: ""
  previewHashes: []
  nativePptxHash: ""
  renderAndMontageHashes: []
  completedSlideIds: []
  recheckRequiredSlideIds: []
  unresolvedFindings: []
  nextAuthorizedAction: ""
```

On resume, verify the referenced files and hashes before continuing. Missing or mismatched evidence becomes `REVIEW_REQUIRED`; do not reconstruct approval from memory.

## PresentationGovernanceSnapshot

Return the smallest useful human summary:

1. current presentation truth and human authority;
2. changed, invalidated and preserved decisions;
3. current readiness using existing status language;
4. repeated-failure or parallel-edit risks;
5. verified recovery point;
6. shortest next route and the one decision that genuinely requires the human.

No material change in truth, risk, readiness or recovery means no additional governance report.
