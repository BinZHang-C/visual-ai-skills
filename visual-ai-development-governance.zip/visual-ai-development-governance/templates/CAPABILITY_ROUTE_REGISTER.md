# 能力路由登记表

- 最后更新时间：YYYY-MM-DD HH:mm Z
- 证据来源：代码、配置、影响收据、只读验证与人类验收记录

本表从代码、配置和收据派生，可在需要时重建；它不是第五个活跃权威，不能覆盖 `PROJECT_TRUTH`、`DECISION_LEDGER`、`READINESS_LEDGER` 或 `CLEANUP_LEDGER`。

| Workflow/node class | Capability Owner | Stable binding | Candidate binding | Provider/API identity | Shared consumers | Retry/fallback | Maturity | Human-accepted package | Unknowns |
|---|---|---|---|---|---|---|---|---|---|
| 工作流/节点类别 | 最早直接证据的所有者 | 已批准冻结身份 | 仅目标能力的一个 Candidate，或无 | 安全类别、版本、schema 哈希和 route profile | 已批准 Stable 消费者 | 显式策略 | 成熟度状态 | 经人类接受的精确包身份，或无 | 待验证边界与最小探针 |

不得记录凭据、令牌、原始提示词、私有图像、完整请求体或原始 Provider 响应。
