#!/usr/bin/env python3
"""Read-only structural validator for governance memory ledgers."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import sys


REQUIRED = (
    "PROJECT_TRUTH.md",
    "DECISION_LEDGER.md",
    "READINESS_LEDGER.md",
    "CLEANUP_LEDGER.md",
)
ID_PATTERN = re.compile(r"\b(?:TRUTH|DEC|EVD|ASSET)-\d{8}-\d{3}\b")


def issue(code: str, file: str, detail: str) -> dict[str, str]:
    return {"code": code, "file": file, "detail": detail}


def validate(root: Path) -> list[dict[str, str]]:
    findings: list[dict[str, str]] = []
    texts: dict[str, str] = {}
    for name in REQUIRED:
        path = root / name
        if not path.is_file():
            findings.append(issue("missing_required_file", name, "required governance ledger is absent"))
            continue
        texts[name] = path.read_text(encoding="utf-8")

    seen: dict[str, str] = {}
    for name, text in texts.items():
        for record_id in ID_PATTERN.findall(text):
            if record_id in seen:
                findings.append(issue("duplicate_id", name, f"{record_id} also appears in {seen[record_id]}"))
            else:
                seen[record_id] = name

    truth = texts.get("PROJECT_TRUTH.md", "")
    current_rows = [line for line in truth.splitlines() if "当前唯一有效" in line and line.lstrip().startswith("|")]
    if len(current_rows) > 1:
        findings.append(issue("conflicting_current_truth", "PROJECT_TRUTH.md", "multiple current-authority rows require human resolution"))
    if re.search(r"未验证假设.*当前唯一有效|当前唯一有效.*未验证假设", truth):
        findings.append(issue("unverified_as_fact", "PROJECT_TRUTH.md", "an unverified assumption is marked as authoritative"))

    readiness = texts.get("READINESS_LEDGER.md", "")
    if re.search(r"成熟度.{0,20}(禁止|允许|授权).{0,20}(开发|合并|发布)|禁止继续开发", readiness):
        findings.append(issue("readiness_as_permission", "READINESS_LEDGER.md", "maturity language is being used as an execution permission"))

    cleanup = texts.get("CLEANUP_LEDGER.md", "")
    for line in cleanup.splitlines():
        if line.lstrip().startswith("|") and "ASSET-" in line and "删除候选" in line:
            cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
            if not any("恢复" in cell or "归档" in cell or "重建" in cell for cell in cells[3:]):
                findings.append(issue("cleanup_without_recovery", "CLEANUP_LEDGER.md", "deletion candidate has no recovery path"))
    return findings


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--format", choices=("json", "markdown"), default="json")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    if not root.is_dir():
        payload = {"valid": False, "error": "invalid_root", "root": str(root)}
        print(json.dumps(payload, ensure_ascii=False) if args.format == "json" else "# 验证失败\n\n- invalid_root")
        return 2
    findings = validate(root)
    if args.format == "json":
        print(json.dumps({"valid": not findings, "findings": findings}, ensure_ascii=False, indent=2))
    else:
        print("# 治理记忆验证\n")
        print("- 结果：" + ("通过" if not findings else "需要修正"))
        for finding in findings:
            print(f"- `{finding['code']}` {finding['file']}: {finding['detail']}")
    return 0 if not findings else 1


if __name__ == "__main__":
    sys.exit(main())
