param(
    [Parameter(Mandatory = $true)]
    [string]$Repository,
    [string]$BranchA = "",
    [string]$BranchB = ""
)

$ErrorActionPreference = "Stop"

function Invoke-ReadOnlyGit {
    param([string[]]$Arguments)
    $output = & git -C $Repository @Arguments 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw ($output -join "`n")
    }
    return @($output | ForEach-Object { [string]$_ })
}

if (-not (Test-Path -LiteralPath $Repository -PathType Container)) {
    [Console]::Error.WriteLine("invalid_repository")
    exit 2
}

try {
    $rootLines = @(Invoke-ReadOnlyGit -Arguments @("rev-parse", "--show-toplevel"))
    $headLines = @(Invoke-ReadOnlyGit -Arguments @("rev-parse", "HEAD"))
    $branchLines = @(Invoke-ReadOnlyGit -Arguments @("branch", "--show-current"))
    $root = $rootLines[0]
    $head = $headLines[0]
    $branch = $branchLines[0]
    $statusLines = @(Invoke-ReadOnlyGit -Arguments @("status", "--porcelain=v1"))
    $untracked = @($statusLines | Where-Object { $_.StartsWith("?? ") } | ForEach-Object { $_.Substring(3) })
    $trackedChanges = @($statusLines | Where-Object { -not $_.StartsWith("?? ") } | ForEach-Object { $_.Substring(3) })

    $worktreeLines = @(Invoke-ReadOnlyGit -Arguments @("worktree", "list", "--porcelain"))
    $worktrees = @($worktreeLines | Where-Object { $_.StartsWith("worktree ") } | ForEach-Object { $_.Substring(9) })

    $remote = $null
    try {
        $remoteLines = @(Invoke-ReadOnlyGit -Arguments @("remote", "get-url", "origin"))
        if ($remoteLines.Count -gt 0) { $remote = $remoteLines[0] }
    } catch {
        $remote = $null
    }

    $comparison = $null
    if ($BranchA -and $BranchB) {
        $baseLines = @(Invoke-ReadOnlyGit -Arguments @("merge-base", $BranchA, $BranchB))
        $base = $baseLines[0]
        $filesA = @(Invoke-ReadOnlyGit -Arguments @("diff", "--name-only", "$base..$BranchA"))
        $filesB = @(Invoke-ReadOnlyGit -Arguments @("diff", "--name-only", "$base..$BranchB"))
        $overlap = @($filesA | Where-Object { $filesB -contains $_ } | Sort-Object -Unique)
        $commitsA = @(Invoke-ReadOnlyGit -Arguments @("log", "--format=%H", "$BranchB..$BranchA"))
        $commitsB = @(Invoke-ReadOnlyGit -Arguments @("log", "--format=%H", "$BranchA..$BranchB"))
        $comparison = [ordered]@{
            branchA = $BranchA
            branchB = $BranchB
            mergeBase = $base
            filesOnlyInA = @($filesA | Where-Object { $filesB -notcontains $_ })
            filesOnlyInB = @($filesB | Where-Object { $filesA -notcontains $_ })
            overlappingFiles = $overlap
            uniqueCommitsA = $commitsA
            uniqueCommitsB = $commitsB
            interpretation = "facts_only_human_decision_required"
        }
    }

    $result = [ordered]@{
        schemaVersion = "visual-ai-git-state/v1"
        repository = $root
        head = $head
        branch = $branch
        dirty = ($statusLines.Count -gt 0)
        trackedChanges = $trackedChanges
        untrackedFiles = $untracked
        worktrees = $worktrees
        remote = $remote
        comparison = $comparison
    }
    $result | ConvertTo-Json -Depth 8
    exit 0
} catch {
    [Console]::Error.WriteLine("inspection_failed")
    exit 2
}
