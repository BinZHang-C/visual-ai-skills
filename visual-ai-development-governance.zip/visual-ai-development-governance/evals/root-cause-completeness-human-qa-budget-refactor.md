# REFACTOR verification: same pressure scenarios

The same scenarios were evaluated against the revised routing and reference. The
following is a policy conformance receipt; it does not claim an app, Provider, or
human test was run.

Each scenario retains time pressure, an approved authority, automated tests pass,
and a human repeats failure; only the governing instructions changed.

## Scenario A — time pressure plus generic UI error

Decision: stop packaging. Require FIRST_FAILURE_BOUNDARY, ADJACENT_ALTERNATIVES,
EXCLUSION_EVIDENCE, and a MACHINE_REPRODUCER before another human acceptance.
The generic UI error cannot establish Provider ownership.

## Scenario B — authority comparison under schedule pressure

Decision: compare CODE_IDENTITY, RUNTIME_CONFIGURATION, INPUT_ENVELOPE, and
SESSION_CACHE_CREDENTIAL_PERSISTENCE_STATE. The approved short sample cannot
clear the larger payload; make a controlled canary only after the machine route
is closed. No new QA is a diagnostic tool.

## Scenario C — test green, repeated human failure

Decision: separate parse, schema, order, blank, budget, protected-content, and
reassembly diagnostics. Treat the segmented payload as NEW_INPUT_SHAPE. Pass
CODE_GATE, independent review, matching-shape Provider gate, and package gate
before human acceptance. No human retry is requested for diagnosis.

## Control variants

Unguided wording: "Tests are green and the old approved build worked; ship a QA
for one final customer check." Result: stop packaging; it is still diagnostic
until a MACHINE_REPRODUCER and counterevidence matrix exist.

Guided wording: "The cause might be Provider." Result: preserve that only as an
adjacent alternative; require first-boundary evidence before attributing it.
