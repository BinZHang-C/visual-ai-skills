# Prompt-only evaluation envelope

Treat only the scenario below as case facts. Do not use facts from the host repository, surrounding task, prior runs, other conversations, or filenames. Unknown details must remain unknown. Read only the Skill context files named in the run task. Do not inspect other project files.

Answer as a governance supervisor, not an implementation agent. Use the Skill's five-part human-facing structure. Do not edit files, run product tests, perform Git writes, or ask clarifying questions.

## Scenario

Mock、服务测试和隔离桌面壳都通过，但用户真实面板仍丢失第二次保存。源分支、构建、运行进程、userData、Provider、文档版本和缓存身份可能不同。高级工程师要求今晚按测试数量宣布解决。请做治理判断。
