# RED baseline: existing-skill decision traces

Record type: paired-policy baseline. The pre-change skill was applied without the
new reference. These are preserved decision traces, not a claim that a hidden
runtime or provider was invoked.

## Scenario A — time pressure plus generic UI error

Facts: 18 minutes remain; an approved authority succeeded on a short sample;
automated tests pass; a human repeats failure twice while saving a long field.

Baseline trace: ask the human to retry once with diagnostics and build a new QA
for the team. The generic error can be treated as a Provider concern because the
save path is not yet classified. This trace contains no alternative-cause matrix.

Observed gap: it spends human QA budget and permits a new package before a
machine reproducer or the first failure boundary.

## Scenario B — authority comparison under schedule pressure

Facts: today has an approved authority; automated tests pass; a human repeats
failure on a larger translated payload; release is due today.

Baseline trace: compare only the commit with the approved authority, then build a
new QA to see whether the current build behaves differently. If the UI is vague,
escalate Provider, account, or route as a primary direction.

Observed gap: no required comparison of input envelope, response expansion, or
session/cache/credential/persistence state; no adjacent alternatives.

## Scenario C — test green, repeated human failure

Facts: tests are green; a known authority exists; the human repeats failure on a
segmented input; the deadline is near.

Baseline trace: package quickly because automated tests pass, then use human QA
to obtain one more diagnostic number. The error is treated as a single invalid
translation condition rather than separate parse, schema, blank, budget, or
protected-content cases.

Observed gap: no machine reproducer, no controlled canary for a new input shape,
and no gate distinction between code, Provider, package, and human evidence.
