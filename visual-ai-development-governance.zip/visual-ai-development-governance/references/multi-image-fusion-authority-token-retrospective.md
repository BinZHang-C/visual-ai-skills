# 多图融合专家提示词：权威、翻译令牌与生成闭环复盘

## 何时读取

出现下列任一现象时优先读取本参考：

- 多图融合的专家提示词能够分析，却在“保存并应用”时报“译文无法解析”“翻译结果不可用”或同类通用错误。
- 首次保存、二次保存或修改后再保存的结果不一致。
- 翻译请求已经成功、翻译令牌或 attestation 已签发，但审批没有消费令牌。
- 原生 Gemini 或 APIMart 已经能够生图，却有人准备通过改模型目录、Provider 路由或 fallback 修复专家提示词保存。
- 编译后的提示词包含重复文本、未加引号的同名文本、Profile、JSON、固定标题或其他编译器附加内容。

搜索关键词：`multi-image fusion`、`expert prompt`、`authoring manifest`、`protected quote`、
`translation attestation`、`token issued`、`token consumed`、`approval`、`Profile`、`JSON`、
`designerNote`、`negativeRules`、`译文无法解析`。

## 已批准案例事实

截至本案例最后一次真人权威验收，多图融合的精确用户路径已经达到
`HUMAN_FUNCTION_ACCEPTED`：专家提示词可以多次保存并用于生成，原生 Gemini 与 APIMart
两种输出选择均可用。

本结论只冻结当时的精确 Candidate、运行配置、输入角色和真人路径。已知案例身份为：

- 工作树：`E:\InteriorCanvas\Development\Worktrees\interior-canvas-api-test-4.0-apimart-route-completeness-v1`
- 分支：`candidate/api-test-4.0-apimart-route-completeness-v1`
- HEAD：`31e5b1d8e4db99596db3b9cd8465bdf449eebe1b`
- 隔离 userData：`E:\InteriorCanvas\Data\Isolated\InteriorCanvas-apimart-route-completeness-qa1-userdata`
- 真人路径：多图融合分析 → 保存并应用 → 再次保存并应用 → 分别选择原生 Gemini、APIMart 生成 → 结果可见。

进程 PID 只属于当次验收会话，不是可复用身份。该批准不自动覆盖更大的图片信封、不同图片数量、
重启恢复、跨机器、其他工作流节点或后续代码版本。移植时必须重新比较代码、运行配置、输入信封和
session/cache/credential/persistence 四类身份。

## 本次锁定的三个根因

### 1. 未加引号的同名文本被错误计数

旧逻辑从完整编译文本做子串或宽泛文本计数。同一作者保护值即使只在 authoring manifest 中声明一次，
只要它以未加引号的普通说明、标题、摘要或其他形式再次出现，就可能被当成第二个受保护实例。目标译文
正确保留了真正的引号内容，仍会因伪造的次数差异被拒绝。

正确不变量：保护集合、段落身份和声明次数只来自 authoring manifest；未加引号的同名文本不产生新的
保护义务。不得用全文子串计数代替结构化 manifest。

### 2. Profile/JSON 等编译器附加内容被错误提升为作者权威

Profile、质量约束、JSON 回执、固定标题和执行说明属于 compiled execution pair。它们可合法引用或重复
作者文本，但不是用户或分析阶段声明的 authoring authority。旧逻辑重新扫描最终编译文本，把这些派生
内容中的字符串提升为受保护作者内容，形成“编译器自己扩张审批合同”的循环。

正确不变量：authoring manifest 是闭集。编译器只能消费该权威，不能反向扩张它；manifest 映射中不存在
的值就是不受该保护合同约束，不得回退到全文扫描。

### 3. 翻译成功并签发令牌后，审批在消费前误判为“译文无法解析”

事件证据已经越过翻译边界：候选译文可用，translation attestation 已签发。真正的第一失败边界发生在
approval 对错误权威集合再次解析和校验；令牌尚未消费，审批就拒绝了请求。通用 UI 文案却把这个审批
错误描述成翻译解析失败，导致排查方向反复回到翻译模型、网络、凭据或 Provider。

正确不变量：`TOKEN_ISSUED` 证明翻译阶段已产生可验证候选，但不证明审批成功；
`TOKEN_ISSUED && !TOKEN_CONSUMED` 时必须先检查 approval/authority binding。若审批失败，错误必须保留
审批阶段与实际诊断类别，不能降格为“译文无法解析”。

## 成功路径合同

用下列单一事件链描述成功，不再使用笼统的“专家提示词可用”：

```text
INPUTS_BOUND
→ ANALYSIS_COMPLETED
→ AUTHORING_MANIFEST_FROZEN
→ EXECUTION_PAIR_COMPILED
→ TRANSLATION_COMPLETED
→ TRANSLATION_TOKEN_ISSUED
→ APPROVAL_REDERIVED_CURRENT_MANIFEST
→ AUTHORITY_BINDINGS_VERIFIED
→ TRANSLATION_TOKEN_CONSUMED_ONCE
→ APPROVAL_PERSISTED_AND_APPLIED
→ GENERATION_PREFLIGHT_PASSED
→ SELECTED_OUTPUT_ROUTE_DISPATCHED
→ PROVIDER_RESULT_IMPORTED
→ RESULT_VISIBLE
```

各阶段必须满足：

1. `AUTHORING_MANIFEST_FROZEN` 仅包含合同明确声明的作者字段；本案例的保护来源包括
   `designerNote`、`negativeRules` 等 authoring 字段，而不是完整编译提示词。
2. Web 可以提交当前 authoring manifest，但桌面审批 owner 必须根据当前 workflow 合同、revision 和输入
   重新推导并核对，不能把前端列表当唯一权威。
3. 翻译只接受来源真实存在、可映射到可翻译段落且身份唯一的值；重复的编译器派生文本不得扩张集合。
4. token 必须绑定源内容、译文、输入身份、intent、模型/阶段角色、session/revision，并且只能消费一次。
5. authority 验证通过后，token 消费与 approval/persist/apply 的关系必须可观察；失败不得伪装成成功，
   也不得留下可供后续生成误用的批准状态。
6. 二次保存使用当前编辑 revision 和与其匹配的新翻译/批准证明；旧 revision、旧 token 或旧批准不得复用。
7. `STAGE_MODEL` 负责分析、翻译、repair 或 verifier；`OUTPUT_MODEL` 只负责最终生成。两者不得因名称相近
   互换，也不得为了修审批 owner 而改写已经批准的原生 Gemini/APIMart 输出路由。
8. 生成前仍须独立验证图片输入信封。保存成功不能证明大图、多图的序列化请求一定能派发；应同时读取
   `image-envelope-first-failure-closure.md`，按最终序列化总字节而不是单文件大小判断。

## 最小反例矩阵

只有正向保存成功不足以证明根因关闭。owner 级机器复现至少覆盖：

| 用例 | 预期 |
|---|---|
| manifest 声明一个带引号值，编译文本另有未加引号同名文本 | 未加引号文本不计数，保存通过 |
| manifest 声明一次，Profile 或 JSON 重复同值 | 编译器内容不扩张权威，保存通过 |
| 编译器加入 manifest 外的独立引号值 | 不加入保护闭集，保存通过 |
| manifest 的真实保护值在译文中缺失或被改写 | fail closed，不消费 token，不持久化批准 |
| 翻译完成且 token 已签发，approval 使用错误 manifest | 诊断为 approval/authority mismatch，不得报翻译解析失败 |
| 同一内容连续保存两次 | 每次绑定当前 revision；两个批准过程均可追踪，不错误复用已消费 token |
| 编辑后再次保存 | 旧 approval 失效，新内容取得新证明，最新编辑获胜 |
| 保存通过后分别选择原生 Gemini 与 APIMart 生成 | 只派发所选 output route，无 fallback、串线或双重计费 |

真正保护值缺失的负例必须继续拒绝。不能以“减少误拒”为理由关闭保护门禁或只比较是否非空。

## 下次高效扫描

### 第一步：锁四类身份

先记录 `CODE_IDENTITY`、`RUNTIME_CONFIGURATION`、`INPUT_ENVELOPE`、
`SESSION_CACHE_CREDENTIAL_PERSISTENCE_STATE`。至少锁定 commit/tree、实际 executable/app、userData、
workflow/node/revision、Provider profile、stage model、output model、图片数量与安全尺寸摘要。

### 第二步：从文案源头反向找到最早失败事件

不要从 UI 文案猜根因。先定位该错误文案由哪个诊断类别触发，再查同一 correlation id 的以下状态：

```text
analysis completed?
translation completed?
token issued?
approval entered?
authority verified?
token consumed?
persistence committed?
generation preflight passed?
transport dispatched?
provider request id present?
```

“最后成功事件 + 第一个缺失事件”比完整日志更有信息量。

### 第三步：按状态直接分流

| 观测 | 首查 owner | 禁止先查 |
|---|---|---|
| 无 translation 请求 | UI/IPC、workflow binding、readiness | Provider 译文质量 |
| translation 成功，无 token | translator response parsing / attestation issuance | persistence |
| token 已签发、未消费 | approval authority、manifest 重推导、revision/session binding | 翻译模型、生成路由 |
| token 已消费、无持久化 | approval/persistence/structural queue | Provider 输出 |
| 保存成功，生成在极短时间内失败且无 transport | generation preflight、资源读取、序列化信封 | Provider 安全策略、计费 |
| transport 已派发且有 Provider request id | HTTP/Provider response/解析 | 本地派发前门禁 |
| Provider 返回有效图片但结果不可见 | 资源导入、结果合同、文档提交 | 提示词翻译 |

### 第四步：一次只验证一个可证伪假设

优先扫描实现中的结构词，而不是模型显示名：

```text
authoring manifest | protected | quoted | extract | count
compiler | profile | json | designerNote | negativeRules
translation | attestation | issue | consume | approval | persist
revision | session | intent | model role | correlation
```

针对本类错误的最高信息量探针是：构造“一个真实引号值 + 一个未加引号同名值 + 一个编译器附加同名值”，
观察 manifest 计数是否仍为一，并观察 token 从 issued 到 consumed 的下一事件。旧算法必须 RED，修复后该
预测事件必须 GREEN，真实缺失保护值仍须 RED。

### 第五步：只记录安全摘要

可以记录阶段、manifest 项数、每项摘要、声明次数、编译段落类型、token 状态枚举、revision/session 摘要、
请求计数、图片媒体类型/尺寸/字节桶和 Provider request id。不得记录原始提示词、译文、令牌、凭据、图片、
完整请求或 Provider 正文。

若进入生成信封诊断，Base64 下界为 `4 * ceil(rawBytes / 3)`，还要加所有图片、提示词与 JSON 的聚合开销；
最终以实际序列化请求体为准。没有 transport 或 Provider request id 时，不得归因 Provider、路由或安全策略。

## 已证伪弯路与禁止事项

- 不再扫描完整 compiled prompt 来生成或计数作者保护权威。
- 不把未加引号同名文本、Profile、JSON、固定标题或回执提升为 authoring authority。
- 不在 manifest 映射缺项时回退全文扫描；缺项应按当前合同解释或显式诊断。
- 不因 UI 显示“译文无法解析”就重试翻译、换翻译模型、改 API、刷新凭据或增加 repair。
- 不把 `TOKEN_ISSUED` 当作整个保存闭环成功，也不把 `!TOKEN_CONSUMED` 误判为翻译未发生。
- 不通过放松真实保护值检查、只看非空或吞掉错误来提高保存成功率。
- 不为 approval owner 的问题修改原生 Gemini/APIMart 输出路由、模型目录、fallback 或重试策略。
- 不用连续人工点击、重打 QA 包或更多截图定位 parser、计数、token 或信封问题。
- 不只测首次保存；二次保存、编辑后保存、最新 revision 获胜是本案例的核心回归。
- 不把一次小输入成功外推到更大 PNG、更多参考图、重启恢复、跨机器或其他工作流。

## 冻结与重新开放条件

本案例的原生 Gemini 与 APIMart 多图融合路径保持 Stable。只有下列可观察证据可以重新开放对应最小范围：

- 相同身份下，专家提示词首次或二次保存再次失败；
- token 生命周期出现 `issued`、`consumed`、approval/persistence 之间的不一致；
- 所选 output route 与实际派发 route 不一致、发生 fallback 或双重调用；
- 新输入信封在 generation preflight、transport、Provider 或结果导入边界出现新的可定位失败；
- 代码、配置、Provider/API/schema、session/revision 或持久化身份发生实质变化。

重新开放时从最早失败边界和最小 owner 开始，不重开未出现回归证据的已批准消费者。

## 影响与验收回执模板

| 字段 | 本案例记录要求 |
|---|---|
| Owner | authoring manifest / translation attestation / approval token lifecycle / generation preflight 中的最早失败 owner |
| Direct dependencies | 当前 workflow、revision、session、authoring fields、stage/output model role、输入信封 |
| Shared consumers | 原生 Gemini、APIMart 及共用编译/审批代码的相邻节点；只列候选，不外推已验证 |
| Forbidden downstream | 失败时不得消费 token、持久化错误批准、调用错误 Provider、fallback、双重计费或发布结果 |
| Automated evidence | 最小反例矩阵、事件次序、旧行为 RED、预测下一事件 GREEN、禁止下游为零 |
| Human batches | 精确 Candidate 中多次保存，并分别用原生 Gemini/APIMart 生成成功 |
| Unknowns | 更大输入信封、重启、跨机器、其他节点和后续版本，除非另有精确证据 |

## 核心结论

这次成功不是来自更多重试或更换 Provider，而是恢复了三层职责：authoring manifest 决定作者权威，
compiler 只生成执行文本，approval 按当前 manifest 验证并消费已经签发的翻译证明。最快诊断信号不是界面
错误文字，而是 `TOKEN_ISSUED → AUTHORITY_VERIFIED → TOKEN_CONSUMED → PERSISTED` 的首个断点。
