# 桌面取景、多图导入与多视角一致性 Authority 3.3 复盘

## 何时读取

以下任一现象出现时读取：

- SketchUp、3ds Max 等外部窗口能够被发现，但移动窗口、改变镜头、停止后重启预览或刷新目录后无法继续取景。
- 预览能显示，但与外部窗口的上下左右内容或比例不一致。
- 画布缩放、节点移动或全屏切换后，裁剪框无法到达边缘、坐标漂移或内容被遮挡。
- 点击“截取”就提前创建候选，比例选择、框选、取消和确认保存的生命周期互相污染。
- 多个截图候选无法独立勾选、排序、指定主图或一次导入当前画布。
- 多视角结果被拼成整图后裁切，主参考覆盖目标视角的镜头、结构或材料，或输出板被档案遮挡且不可移动。
- 已批准的新工具需要形成 tracked-clean 产品提交、唯一 EXE/ZIP、安装验证与回滚记录。

本参考保存一宗已完成案例的证据关系。项目专属 commit、路径、哈希和测试数字只能用于恢复该案例，不能证明另一个项目已经通过。

## 已批准成果与精确身份

案例产品身份：

- 产品名称：`权威3.3`。
- 分支：`authority/3.3`。
- 产品 commit：`641176008e076a9215eceaca54b9b094e85e83c9`。
- tree：`190456eb09afbf0cdaaf8b0da63006c61df846c2`。
- 工作树：`E:\InteriorCanvas\Development\Worktrees\interior-canvas-authority-3.2-r11-multiview-capture-integration`。
- 真人证据：SketchUp 桌面取景、预览缩放/拖动/裁剪/多选导出、紧凑 UI，以及多图角度一致性新增工具的精确路径 `HUMAN_FUNCTION_ACCEPTED=true`。
- 未覆盖：3ds Max 真人路径、跨物理电脑、代码签名、长时间高频捕获、崩溃恢复和未执行的 Provider/model/API/schema/profile 组合。

### 新增工具的冻结用户结果

桌面取景：

1. 目标目录独立识别受支持窗口；刷新不以截图首帧成功作为窗口存在条件。
2. 实时预览跟随外部镜头，但不自动创建候选。
3. 桌面取景普通态是 React Flow 画布节点，可随画布缩放与拖动；显式全屏使用同一组件状态。
4. 固定黑色预览 viewport 初始自适应居中；观察缩放为 50%–200%，缩小时黑色填充，内容可在闭合边界内拖动且不越出 viewport。
5. 观察缩放与偏移只属于实时 UI，不进入 candidate、crop 或 export。
6. 裁剪比例在截取前常驻可选；截取只建立 pending 冻结帧，框内可移动、四角可等比例缩放；确认保存后才进入候选栏。
7. Esc 只取消当前 pending 框选，不关闭全屏、窗口、会话或预览，也不删除已保存候选。
8. 候选支持逐项选择、全选、排序、主图与只导出勾选项；导入复用当前画布资源 owner。
9. 截取、缩放、状态和比例位于紧凑控制区；压缩 footer 释放的高度归还给预览舞台，不改变生命周期。

多图导入：

1. 只提交已勾选候选；主图若被指定，必须属于提交集合。
2. 保留候选顺序、主图、归一化裁剪和实际像素身份。
3. 每张图片作为独立资源进入画布；输入 bundle、批次板和结果节点分别可移动，不把多图预先拼成一张图。

多视角一致性与质量：

1. 每个目标视角独立请求、独立结果、独立重试和独立保存；禁止接触表、拼图或整图渲染后裁切。
2. 目标视角自身是镜头、透视、构图、空间结构、可见物体、材料身份和材料所在表面的唯一图像权威。
3. 参考图只约束质量与气质，不授权替换目标视角的风格、材料、结构或物体。
4. 质量合同为干净通透、细腻写实、材料微纹理/粗糙度/反射可信、空气和灯光层次清晰；禁止脏灰、泛黄、雾化、塑料感、过锐、噪点、假 HDR 和主参考覆盖。
5. 一致性档案不得遮挡结果；输出批次板可以移动，位置进入既有文档/run 持久化合同。

## 失败路径：负面教材

| 失败路径 | 为什么看似合理 | 已锁定的最早失败边界 | 下次最小证伪 |
|---|---|---|---|
| 用 `desktopCapturer` thumbnail 是否非空决定窗口是否存在 | 一次调用同时得到目录和图片，代码简单 | Windows Graphics Capture 首帧可暂时返回 0×0；旧目录把“暂不可取帧”误判成“窗口不存在” | 目录请求使用 0×0，只核对受支持标题/窗口身份；预览请求单独证明帧可用性 |
| 停止预览后把一次空目录当作目标已删除 | teardown 后立即刷新通常期待得到相同列表 | WGC session teardown 的暂态 source absence 清除了已确认目标身份 | 同一 App 进程保留已确认目标；验证 `stop → empty refresh → restart` |
| 400ms 预览与高分辨率候选并发捕获 | 预览和点击截图是两个独立 UI 动作 | WGC 请求竞争；镜头切换或候选 4096 请求期间返回空帧，继续截取被阻断 | 全部捕获串行；候选编辑/截取期间暂停轮询；断言最大并发为 1 |
| active session 空帧直接显示“窗口已关闭” | `NOT_FOUND` 文案比暂态状态简单 | session、target 和窗口仍存在，缺失的是当前 source/frame | 映射为可恢复 `CAPABILITY_NOT_READY`，保持 session/target/candidates，下一成功帧自动清错 |
| 截取后立即加入右栏并自动进入裁剪 | 减少一次“确认”点击 | capture、pending crop、saved candidate 三个权威被合并；比例预选与取消语义失真 | 建立 `live → pending → confirmed` 状态机；右栏数量只在 confirm 后增加 |
| 前端先删除候选，再异步释放后台 ID | UI 立即响应 | discard 失败会留下不可见额度占用；等待删除时切换候选会产生竞态 | 后台成功回执后才清 UI；失败保留可重试状态；独立复审释放失败与重入 |
| 用 `getBoundingClientRect()` 的缩放后尺寸计算节点内部 crop | DOM rect 直接反映屏幕位置 | React Flow viewport 坐标和节点内部 layout 坐标混用，50% 缩放被重复应用；portal 全屏切换未重新测量 | 用 `clientWidth/clientHeight` 建立本地 media rect；pointer 按 viewport/local 比例换算；presentation/fullscreen 变化重测 |
| 固定请求 `1600×1600` 或 `2560×2560`，再靠 renderer `contain` 修正 | 方形上限便于统一缓存与布局 | 源帧在进入 renderer 前已因错误 thumbnail 比例缺失上下内容 | Win32 原生宽高是请求比例权威；最长边受限等比例请求；最小化时读取正常还原矩形 |
| 把预览 zoom/pan 复用于 crop/export | 一套 transform 看似能同时服务观察和截图 | 观察位置改变了候选像素与归一化 crop，导出不再对应源图 | 预览 viewport/content 分层；进入 pending/saved crop 强制完整原图 `(0,0)/100%` |
| 使用同样基于 WGC 的桌面自动化工具做最终视觉对照 | 自动化能读取两个窗口并截图 | 测量工具与被测 Electron 竞争同一 WGC，SketchUp 首帧超时，产生观测干扰 | 自动化只用于非竞争证据；最终来源画面等价在不运行该工具的干净真人会话确认 |
| 把多视角做成一张接触表请求再拆图 | 调用少、批次看起来一致 | 各目标视角不再拥有独立镜头/结构/材料权威，氛围和材料容易共同偏航 | 断言每个目标一条请求、additional references 为零、每个结果独立资产 |
| 用主参考统一所有视角材料与风格 | “一致性”容易被理解为复制主图 | 主参考覆盖目标视角，改变原有材料和空间事实 | 提示词与请求合同明确 target-only authority；参考只约束质量/气质 |
| 把输出板位置留在 React 临时状态或固化在档案旁 | 初次渲染位置正确 | 画布缩放、重开或结果增多后被档案遮挡，位置不可恢复 | 输出板是独立可拖动节点；位置写入受约束 document/run 合同 |
| 默认 5 秒超时下把测试超时当产品失败 | 失败出现在新增测试附近 | 同文件 4 个预算超时使清理未执行，继而污染后续 1 项；不是功能断言失败 | 聚焦同文件提高到 15 秒并先确认 43/43，再以同预算跑全套；记录为 harness/预算证据 |

### 失败分类

- 目录与 frame 耦合、状态机混合、坐标系混用、方形请求、临时状态持久化：`implementation_defect`。
- WGC 暂态、捕获竞争、自动化测量干扰、高 DPI/多屏未知：`integration_environment`。
- 把一致性理解成主参考覆盖、把批次理解成拼图：若需求已经明确则为 `understanding_gap`；若用户后来收窄规则则为 `requirement_evolution`，不得倒推责怪旧实现。

## 成功路径与根因锁定方法

### 桌面取景 owner 分层

使用三条独立生命周期，而不是一个“截图是否成功”的布尔值：

1. `window directory`：只证明受支持窗口身份存在。
2. `live preview`：证明当前 session 可取得临时帧；失败为 waiting，不删除目录身份。
3. `explicit candidate capture`：由用户点击触发，串行取得冻结帧；进入 pending 后等待确认保存。

根因只在以下证据同时成立时锁定：旧行为在真实 owner 边界 RED；最小改动前写出的下一事件真实出现；禁止下游仍为零。此案的重要 RED/GREEN 包括：

- 0×0 thumbnail 的 SketchUp 仍出现在目录。
- 捕获请求序列按目录/预览/候选分层，且最大并发为 1。
- `stop → empty refresh → restart` 不丢失已确认目标。
- active session 空帧保持 waiting，恢复帧后自动回到 live。
- pending 未确认不进入右栏；Esc 不删除 saved candidate；discard 失败不遗忘后台 ID。
- 50% React Flow 缩放、全屏 portal 和精确底边都映射到同一本地 crop 空间。
- 原生 `2000×1200` 窗口得到 `1600×960` / `2560×1536`，而不是方形请求。
- 50%–200% 观察 zoom/pan 不改变 candidate/crop/export。

### 多图与多视角 owner 分层

1. 候选选择 owner 决定提交集合；资源导入 owner 为每张候选建立独立资源并保留顺序/裁剪/主图。
2. 多视角档案 owner 只保存人类批准的跨视角约束，不成为新的图像主参考。
3. generation owner 为每个目标视角创建独立任务；目标资源指纹和已应用档案 identity 必须在异步提交点复核。
4. result owner 为每个目标保存独立资产；batch board 只聚合审阅和位置，不参与 Provider 合成。
5. 质量策略是硬约束，但不得以“提升质量”为名改变目标材料、镜头或结构。

### 证据与真人预算

- 自动测试负责目录、并发、状态机、坐标换算、schema、资源顺序、每目标独立请求和位置持久化。
- Provider 合同未变化且未新增调用时，不为 UI/本地捕获修改重开 live canary。
- 真人只确认外部窗口对照、缩放/拖动/裁剪手感、紧凑 UI 可读性，以及多视角最终视觉质量。
- 用户批准只冻结精确 SketchUp 与本批次多视角路径；3ds Max、跨机器、重启恢复等继续列为未知。

## 从批准到部署的记录步骤

治理 skill 只记录和监督，以下动作必须由获授权的执行代理或人类完成：

1. **冻结真人结果：** 写明精确用户路径、未覆盖范围、reopen 条件、Owner、Direct dependencies、Shared consumers、Forbidden downstream、Automated evidence、Human batches、Unknowns。
2. **形成单一产品身份：** 从已批准语义并集创建一个 tracked-clean 产品 commit 与唯一权威分支；治理 docs-only seal 不得冒充产品提交。
3. **排除平行实验：** API Test、云路由、Provider/模型实验等不属于本批次的内容不得整分支并入；共享文件做三方差异与逐 hunk 语义并集。
4. **运行与风险相称的代码门禁：** owner focused → 相邻冻结消费者 → 最终集成树所需全套；区分断言失败与 harness timeout/原生进程污染。
5. **构建唯一 portable：** 从 clean commit 执行 production build；记录 payload 文件数、逻辑字节、reparse 数、manifest 与 ledger 哈希，确认不含正式 TestData、凭据或用户图片。
6. **隔离启动：** 使用独立 `userData` 启动精确 Electron/app path，回读进程、窗口、bundle 与参数身份；不得借用旧进程截图作为新包证据。
7. **单文件安装 smoke：** 用目标 Windows PowerShell 版本验证当前用户安装、桌面/开始菜单快捷方式 target/arguments/working directory、启动、卸载和 userData 保留；安装器签名或跨机器未测必须保留为未知。
8. **封存 EXE/ZIP/manifest：** 记录绝对路径、bytes、SHA-256、产品 commit/tree、packageId 与回滚包；失败候选进入 Failed/隔离区，不覆盖 Approved。
9. **保留回滚：** Authority 3.2 r11/r10/r5 等已批准包不删除、不覆盖；没有另行授权不 push、不部署、不切换正式快捷方式。

### Authority 3.3 部署回执

| 项目 | 精确记录 |
|---|---|
| 产品门禁 | Product Contracts `329/329`；Web `1090/1090`；Desktop `1803/1803`，另有 1 个显式 live-provider skip；双端 typecheck、Desktop i18n、production build、`git diff --check` 通过 |
| EXE | `E:\InteriorCanvas\Releases\Approved\InteriorCanvas-Authority-3.3-Setup.exe`；166,473,728 bytes；SHA-256 `a1b635806b704fff3ce979a10779e9c9008a572ea71745bd16e9169c9410437f` |
| ZIP | 单根 ZIP；167,107,254 bytes；SHA-256 `8977dd69dc384ac2f393d86982edda89e0426cb3d3960c3dcccd719dbcf63e7a` |
| Portable manifest | 105 files；407,958,770 bytes；ledger `860d6926639ec36b969e5ad6a408b5f207e2a839389f662d44f6db36a4c5ae84`；0 reparse points；无正式 TestData/凭据 |
| 物理门禁 | 隔离 Electron 启动、Windows PowerShell 单文件安装、快捷方式身份、卸载及 userData 保留通过 |
| 当前边界 | `PACKAGED_APP_PASSED=true`；未 push；未做代码签名、跨机器或 3ds Max 真人验收 |

## 重新开放与移植

只有以下事实可以重开最小冻结范围：

- 精确冻结路径出现可观察回归，如目标消失、镜头移动后不能再截取、预览内容缺失、crop 越界、pending 提前入栏、未选候选被导入、目标视角材料/结构漂移、拼图裁切、输出板位置丢失。
- Provider/model/API/schema/profile、桌面捕获合同、资源/文档持久化合同或运行身份发生变化。

移植到云端架构或新稳定线时：

1. 以产品 commit/tree 为源，不以治理 docs-only commit 或安装目录为源码。
2. 对源提交、共同祖先和目标 Candidate 做只读三方差异。
3. 桌面 IPC/service、CanvasWorkspace、GenerationDock、质量策略等共享 owner 禁止整文件覆盖。
4. 逐 hunk 保留目标的 Provider/Gateway/auth/model/cloud 专属逻辑与本案例已批准的本地工具语义。
5. 形成一个独立集成 Candidate；只有 Provider 合同变化才重开对应 live canary。
6. 新集成树必须重新取得自己的 package 身份和真人批准；Authority 3.3 的 EXE 回执不能自动转移。

## 不要做什么

- 不用更多刷新、重启、自动化截图或新 QA 包代替 first-failure boundary。
- 不因一次空帧清除窗口、session、候选或用户选择。
- 不让轮询与显式截图并发竞争捕获 owner。
- 不把 viewport 观察 transform 当成源图 crop transform。
- 不用 renderer 的 `contain/cover` 掩盖源 thumbnail 比例错误。
- 不把主参考、材料说明图或接触表当作目标视角的图像 authority。
- 不把全套测试数量、构建成功或安装 smoke 扩大为未执行的真人视觉质量证据。
- 不整文件覆盖共享 owner，不整分支 cherry-pick，不删除旧批准回滚包。
- 不把本案例的路径、哈希、测试数字或真人结论写成当前项目事实。
