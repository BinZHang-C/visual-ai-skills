# Root-cause completeness and human QA budget

## When to read

Read this reference when the same user outcome has failed twice, when a human has
already repeated a functional check, when automatic evidence conflicts with the
real path, or before proposing another QA package for diagnosis. Also read it for
a NEW_INPUT_SHAPE, segmented payload, or a changed Provider envelope.

## Non-negotiable stops

- On the second failure of the same user outcome, NO_NEW_QA: do not build another
  QA package as a diagnostic instrument. First obtain a MACHINE_REPRODUCER, or
  record specific evidence that makes the old failure evidence inapplicable.
- HUMAN_QA_BUDGET: a human decides final function and quality. A human is not a
  parser, route, budget, persistence, or race-condition probe. After one failure
  of the same class, require a MACHINE_REPRODUCER, COUNTEREVIDENCE_MATRIX, and a
  CONTROLLED_CANARY before the next human acceptance attempt.
- Before code change, packaging, or a new human QA, identify the
  FIRST_FAILURE_BOUNDARY and preserve ADJACENT_ALTERNATIVES with
  EXCLUSION_EVIDENCE. A single most-likely cause is not root-cause closure.

## Root-cause completeness contract

Record, in order:

1. FIRST_FAILURE_BOUNDARY: the earliest recorded stage whose invariant failed.
2. ADJACENT_ALTERNATIVES: the immediately earlier and later boundaries, plus any
   plausible peer boundary that could produce the same symptom.
3. EXCLUSION_EVIDENCE: the concrete event, receipt, or reproducible observation
   that rules out each alternative; label unresolved alternatives as unresolved.
4. MACHINE_REPRODUCER: one automated composition or owner-level case that fails
   under the old behavior and exposes the observed mechanism.
5. COUNTEREVIDENCE_MATRIX: behavior, contemporary evidence, missing evidence,
   incorrect inference, rework caused, and the one next discriminating probe.

Do not collapse JSON parse failure, schema mismatch, ID/order mismatch, blank
translation, UTF-8 budget overflow, protected-content drift, and compilation or
reassembly failure into one actionless error. Persist a distinct diagnostic class
and safe size/identity summaries for each.

## One falsifiable real-behavior loop

Use this loop after identity and the FIRST_FAILURE_BOUNDARY are known:

1. `ONE_FALSIFIABLE_HYPOTHESIS`: state one mechanism, its single discriminating
   prediction, and the observation that would reject it. Do not combine adjacent
   alternatives into a broad repair.
2. `REAL_BEHAVIOR_RED`: make the old behavior fail at the real owner boundary,
   not only in a mock, surrogate parser, or UI-message assertion.
3. Change only the smallest owner capable of preventing the mechanism. Predict
   the immediate next lifecycle event before observing it.
4. `NEXT_EVENT_PREDICTION`: accept the repair only when that exact next event is
   observed in the locked identity. A generic later success does not substitute.
5. `DOWNSTREAM_ZERO`: when the boundary must close, prove approvals, execution,
   Provider calls, charges, and user-data writes prohibited by that failure stay
   at zero.

Before human acceptance, use mixed-input, concurrency, and re-entry
counterexamples where applicable. Independent P0/P1/P2 review must distinguish
release blockers, material regressions, and residual risk. Run human QA only in
an isolated empty-cache state after diagnostics have closed; this clean state is
not evidence about an untested persisted-session path.

## Authority comparisons and new shapes

An approved authority is a scoped success, never proof that shared code has no
latent boundary. Compare all four dimensions before reusing it:

- CODE_IDENTITY: commit, blobs, and semantic patch.
- RUNTIME_CONFIGURATION: profile, model, route, environment, and retry policy.
- INPUT_ENVELOPE: source size, field/segment shape, response expansion, and
  verifier or repair envelope size.
- SESSION_CACHE_CREDENTIAL_PERSISTENCE_STATE: session, cache, credential state,
  document/version state, and persistence namespace.

For a NEW_INPUT_SHAPE, a short-input canary may establish only Provider identity.
It cannot establish the new payload category. Require the matching owner tests,
then a CONTROLLED_CANARY for the changed shape before packaging.

## Gate order and human handoff

Keep evidence separate: CODE_GATE, independent repair review, Provider-contract
gate for the exact shape, PACKAGE_GATE, then human acceptance. Passing an earlier
gate never substitutes for a later one.

Before any new QA package, answer in writing: "Is this package verifying product
function, or still helping locate root cause?" If it is locating root cause,
stop packaging. Human acceptance resumes only after the machine reproducer,
counterevidence matrix, and controlled canary have closed the diagnostic route.

An independent reviewer must attack fix coverage, overlapping boundaries/spans,
maximum legal input, frozen consumers, and whether diagnostics distinguish the
next failure.

## Human decisions retained

Only humans decide acceptable user-quality tradeoffs, release timing, spending or
external state changes, scope expansion, and whether the stated evidence supports
final acceptance. This reference constrains diagnosis; it does not grant product
changes, test execution, packaging, release, or Git writes.
