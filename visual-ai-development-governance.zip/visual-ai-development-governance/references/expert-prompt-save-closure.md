# 专家提示词保存闭环

## 何时读取

视觉分析已返回可编辑草稿，但“保存并应用”沉默、超时或失败；首次、修复重试、验证或持久化的表现不同；或通用错误文案无法判断失败是否真正到达保存端时读取。

## 单一生命周期

不把“专家提示词可用”合并成一个状态。沿下列顺序记录最早失败边界：

1. UI 组织有序输入与 workflow 身份。
2. 分析 IPC 进入 workflow 专属 analysis service 和专属 execution。
3. Provider 视觉响应经解析与证明后成为可编辑草稿。
4. 保存请求进入 workflow 专属 translation service。
5. translator 生成候选；首轮失败时才进入有界 repair。
6. verifier 对完整源文与候选做独立语义验证。
7. 验证通过后才允许 approval、persistence/apply 和后续 generation。

复用 API/schema/凭据存储与安全网络基础，不复用可变运行实例、会话、缓存或 in-flight 状态。目标 workflow 必须有显式绑定；已批准消费者继续使用原 Stable 默认值。

## 请求尺寸合同

不能只验证单个文本字段的上限。必须对每个实际 envelope 建立容量不变式：

```text
translatorLimit >= source + instructions + schema envelope
repairLimit >= source + bounded failure evidence + repair instructions
verifierLimit >= source + translated candidate + protected terms + schema envelope
```

- repair 不应再携带上轮完整候选；保留失败类别、长度、指纹和完整权威源文即可定向纠错。
- verifier 同时包含源文和候选，常大于 translator 或 repair；不得沿用未经容量计算的通用默认上限。
- 尺寸放宽只绑定目标实例。不通过截断权威源文、降低验证强度、提升共享默认值或隐式回退来“保存成功”。
- 上限必须在 Provider 已公开能力和产品输入契约内；超界时显式失败。

## 用调用序列定位边界

| 最后可见事件 | 优先归属 | 下一最小探针 |
|---|---|---|
| 无 Provider 请求 | 本地 schema、配置、凭据或网络前置 | 记录安全请求摘要和本地错误码 |
| vision 成功，无 text 请求 | 分析到保存的 UI/IPC 交接 | 核对 workflow、语言会话和草稿身份 |
| 只有首个 text 请求 | translator 响应解析或 repair 在派发前被拒 | 记录候选指纹、失败类别与 repair envelope 长度 |
| 第二个 text 请求成功且候选指纹非空，但无 verifier 请求 | verifier envelope 本地校验/容量边界 | 用产品最大合法源文+候选做真实 composition RED |
| verifier 成功后才报保存失败 | approval、persistence/apply 或最新编辑竞争 | 关联验证回执、文档版本和持久化键 |

通用 UI 文案不是归属证据。只有真正进入 persistence/apply 才可把问题称为“保存端失败”。

## MANIFEST_AUTHORITY_CLOSURE

当结构化翻译已经成功、attestation 可用，但启用高级约束或保护项后 approval
仍返回 stale，必须区分三种内容身份：

- **Authoring manifest：** 用户、分析或产品合同明确声明需要翻译或逐字保护的源字段；
  它是受保护值、出现次数和段落身份的唯一权威。
- **Compiled execution pair：** 编译器为模型执行而生成的 prompt/negative prompt；可以合法
  重复 manifest 内容，也可以加入固定标题、解释或带引号的规则。
- **Translated execution pair：** manifest 翻译并重新编译后的执行文本；它只需满足 manifest
  声明的保护合同，不能被要求复刻编译器派生文本的表面次数或引号形态。

审批校验必须以 manifest 的值和出现次数为闭集。编译器派生内容不得反向扩张翻译权威：

1. 同一受保护值被编译器重复引用时，只要求保留 manifest 声明的次数。
2. 编译器加入 manifest 外的另一段引号文字时，该文字不能自动成为受保护值。
3. 已提供 manifest 权威映射时，“映射中不存在”表示不属于该保护合同；不得回退到全文扫描。
4. manifest 内真实受保护值少一次、被改写或丢失时仍须 fail-closed；不能为了放行编译器文本而
   降低这一门禁。

最小所有者级反例矩阵：

| 反例 | 期望 |
|---|---|
| manifest 声明一次，编译器重复同一值 | 目标保留一次即可通过 |
| 编译器加入 manifest 外的不同引号值 | 不扩张保护集合，应通过 |
| manifest 声明的值在目标中缺失 | 拒绝 |
| manifest 同一值真实声明多次，目标次数不足 | 拒绝 |

不能只写“新实现通过”的正例。回归必须证明旧算法会因编译器重复或独立引号误拒绝，同时证明
真正丢失 manifest 保护内容仍会失败。若首次补丁仅改变计数来源，但仍遍历全文提取集合或保留
全文回退，则根因尚未闭合。

这类故障的安全诊断只记录阶段、身份、段落数、权威计数和摘要；不读取或回显提示词正文、图片、
凭据或完整模型响应。translation/verifier 成功只能排除其自身阶段，不能替代 approval owner 的
机器复现。第二次同类失败后，在新的 QA 包前应用 `NO_NEW_QA` 与 `MACHINE_REPRODUCER`；真人只做
最终最窄功能验收。

## 最小回归与验收

- composition RED 使用生产 workflow 绑定和真实最大合法 envelope，网络只在最后交通边界 fake。
- GREEN 必须观察完整事件序列：analysis → translator → 必要时 repair → verifier → approve/persist；错误共享路由调用数为零。
- 故障注入恢复旧上限或旧共享绑定时，所有者级测试必须再次失败。
- 自动证据分开记录分析、首次保存、修改后二次保存、最新编辑获胜；只有实际执行过重开/重启才声明耐久恢复通过。
- 真人批准按最窄路径冻结，不外推到其他 workflow、Provider、输入类别或重启稳定性。
- 高级约束触发的保存故障还必须覆盖 `MANIFEST_AUTHORITY_CLOSURE` 的四个反例；只覆盖同值重复、
  未覆盖 manifest 外不同引号值，不足以宣布 owner 已闭合。

## 成功关键

成功不是“多重试一次”，而是同时闭合三个边界：workflow 独立运行实例、repair/verifier 完整 envelope 的容量契约、以及验证通过前零 approval/persistence 的失败关闭。这三项中任一未闭合，分析成功都不能代证保存可用。
