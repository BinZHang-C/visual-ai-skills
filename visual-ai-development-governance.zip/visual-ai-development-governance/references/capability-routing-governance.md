# 能力路由治理

## 何时读取

当需要在 Workflow、Gateway、API 合同、网络/环境、外部 Provider、响应解析和下游状态之间归类失败，或一个共享路由可能影响多个节点/消费者时读取。

## 最早直接证据的分类

| 边界 | 证据谓词 | 不要推断 |
|---|---|---|
| Workflow | gateway 派发前编译 payload、角色或序号不同，或仅一个 workflow 产生错误合同 | Gateway 或 Provider 缺陷 |
| Gateway | 网络派发前解析、profile、deployment 或 capability 选择失败/不同 | API 拒绝 |
| API contract | 请求到达 Provider，因端点、API 版本、schema、请求体、功能或大小被拒绝 | VPN 不稳定，除非路由证据不同 |
| network/environment | DNS、TLS、超时、代理/VPN、路由、进程、凭据 profile 或打包身份在有效 Provider 响应前改变结果 | 提示词或 schema 损坏 |
| external Provider | 配额、授权、计费、故障、限流或有文档的服务限制 | 本地实现缺陷 |
| response parsing | 成功 Provider 响应到达，但 envelope、文本、JSON、schema 或 locale 校验失败 | 请求传输失败 |
| downstream state | 分析成功后，approval、save、apply、reopen 或 execution 状态失败 | 分析失败 |

证据横跨多个边界时保留竞争假设，并只提出一个最小区分探针；不能为了给出答案而强制单一根因。在该探针隔离最早直接证据前，不得建议先改 Workflow、Gateway、API、网络/环境、Provider、解析或其他任一层。

## 能力目录计数与刷新

Provider 就绪界面的能力数量应解释为当前合格 deployments 的**聚合唯一能力集合**，不是某个当前选中模型的能力数量。数量从 N 变为 N+1 只能证明聚合集合发生变化，不能证明当前选中模型获得了新增能力；必须比较刷新前后的精确能力集合，并记录贡献该能力的 deployment/modelId。

当目录缺失或超过 TTL，且精确 capability 在 Provider 派发前以 `NO_ELIGIBLE_DEPLOYMENT` 等证据失败时，可以先执行一次非计费目录刷新，再重新解析同一个精确 capability。该动作是恢复路由证据，不是模型 fallback，也不得把能力借给不支持它的模型；刷新后仍不可用则 fail closed，不降级 capability、不静默换用不等价模型。

刷新回执至少记录 provider/profile、catalog generation、observedAt/expiresAt、请求的精确 capability、刷新前后能力集合、贡献 deployment/modelId、最终 modelId，以及是否发生 Provider 生成调用。不得记录凭据、原始响应或私有输入；能力计数只能作为提示，不能代替精确集合与模型证据。

## 版本隔离与共享影响

Candidate 必须显式绑定到目标 workflow，不先替换无版本共享默认值。所有已批准消费者继续冻结在 Stable。共享默认值提升是与目标修复分开的决定，需要独立影响收据、回归证据和人类接受。每个 capability 只能有一个活跃 Candidate，并保留最近可恢复 Rollback。

共享路由影响多个节点时，先列出消费者和各自 Stable 身份，再确认目标绑定与最小探针；节点上看到的症状不等于共享 Gateway 是所有者。

## 专家提示词节点闭环

“专家提示词”不是一个阶段。按可观察结果依次区分：**输入分析**、**草稿编辑**、**翻译、校验与审批**、**保存与应用**、**重开与恢复**、**生成执行**。分析成功不能证明保存成功，一次保存成功不能证明多次保存成功；只有最早失败阶段及其直接证据决定修复所有者。

分析所有者路径按 `UI → preload/IPC → composition → workflow 专属 analysis service → workflow 专属 execution → execution transport → Provider → response parsing/attestation` 追踪。分析成功后的路径另按 `translation/verification/approval → persistence/apply → generation` 追踪。不得用同一错误文案把这些阶段合并，也不得因分析、保存或生成其中一段通过就推定整条链通过。

复用原则是：**复用合同，不复用运行实例**。可以复用已批准节点的 API 版本、端点类别、模型类别、请求配置、schema、纯函数合同、凭据存储和安全网络基础设施；目标 workflow 必须有显式绑定、workflow 专属 execution 和独立 analysis service，不共享可变会话、缓存、in-flight 状态或无版本默认路由。不得修改共享默认路由来修单个节点，也不得复制整套 adapter/profile/deployment，除非最早证据确实落在这些所有者。

先在真实 composition 边界做 RED：使用目标 workflow 的真实角色/序号、输入数量与生产绑定，让旧路径暴露原错误；网络只在最终边界使用 fake。GREEN 必须断言目标 API 合同、每个输入的角色/序号、返回 schema、正确调用次数，以及错误共享路由调用数为零。随后做一个变异：重新绑定到旧共享服务，目标测试必须再次失败；恢复后相邻 Stable 身份和调用数不变。

Provider 合同身份完全相同——能力、模型/API、端点、请求体/schema、输入类别和环境假设均未变化——且改动只在 composition 所有者绑定时，复用已有 live 合同证据，不得重复 live canary。任一合同字段或环境假设变化时，回到 canary-first 门禁。

自动证据分别覆盖分析、首次保存、修改后二次保存、最新编辑获胜；若改动 persistence、rehydration 或文档身份，再覆盖重开后保存。真人批次也按这些阶段记录，不把“按钮可点”当成功：至少完成目标节点分析、首次保存、修改后二次保存；只有真实走过重开才声明重开与恢复通过。已批准节点保持冻结，无可观察回归不得重测。

## 安全路由身份与派生登记

## Route-role binding for contract tests

`ROUTE_ROLE_BINDING` applies when a test fixture, output contract, or route
receipt names a model. Record the lifecycle role before comparing aliases:

- `STAGE_MODEL` is a translator, repairer, verifier, analyzer, or other
  intermediate-stage identity.
- `OUTPUT_MODEL` is the generator identity for the terminal artifact.

The contract must resolve the expected `OUTPUT_MODEL` from the current authority
route for the generation capability. It must not write the translator or verifier
alias into `outputSpec.modelAlias`, even if the aliases share a Provider family.
Likewise, a generated-output alias must not substitute for translator or verifier
identity.

Require a contract test with the correct role bindings and a role-swapped
mutation: place the `STAGE_MODEL` into `outputSpec.modelAlias` and assert the
test must fail before any package or human QA. The test receipt should state the
current authority route, each role, the relevant contract field, and whether the
failure was rejected locally or by the approval service. Do not classify a
role-swapped contract rejection as a product/provider failure until the first
failing boundary proves that ownership.

安全身份字段可以包含：workflow/node class、capability owner、Stable/Candidate/Rollback binding、Provider 类别、模型别名/类别、API 版本、端点类别、schema 哈希、请求大小区间、route profile/region、重试/回退策略、maturity、包身份和未知项。

`CAPABILITY_ROUTE_REGISTER` 从代码、配置和收据重建，用于对比而非决策；它不是第五个活跃权威，不能替代 `PROJECT_TRUTH`、`DECISION_LEDGER`、`READINESS_LEDGER` 或 `CLEANUP_LEDGER`。不得放入凭据、令牌、原始提示词、私有图像、完整请求/响应或原始 Provider 响应。

## 不要做什么

- 不以错误文案、单个节点症状或一次测试通过推断路由所有者。
- 不把 Candidate 作为共享默认值，不重开冻结 Stable 消费者，也不合并多个活跃 Candidate。
- 不把专家提示词分析、编辑、审批、保存、重开和生成合并为一个“可用”状态。
- 不因借鉴已批准节点而共享其运行实例、可变状态或默认路由，也不无证据复制整套 Provider 系统。
- 不把登记表作为配置源、运行时路由器、第五权威或敏感信息容器。
