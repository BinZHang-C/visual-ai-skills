# 已批准工作流的冻结、移植与优化

## 何时读取

出现以下任一情况时读取本参考：

- 一个视觉 AI 工作流已经获得真人批准后，需要冻结封装或写入长期记忆。
- 需要把已批准能力移植到更新版本、稳定分支或另一台机器的安装包。
- 同一功能经历多次“修好—回归—再修”，需要复盘失败和弯路。
- 准备在一致跑通后优化结构、性能、测试或可维护性。

核心原则：真人批准的是一条可观察的完整用户路径及其身份，不是某几个文件。冻结先于移植，语义并集先于覆盖，端到端一致跑通先于优化。

## 一致跑通合同

### 1. 生命周期必须完整

按真实用户顺序记录并验证：

`readiness → 输入分析 → 编辑 → 保存并应用 → 生成 → 结果交互与结果位置 → 重开/恢复（若本轮声明覆盖）`

不得用其中一个阶段成功推导另一个阶段成功。分析成功不等于保存成功；保存成功不等于生成成功；生成成功不等于结果位置能持久化。

### 2. 身份必须闭合

最少同时绑定并记录：

- 源提交与 tree、集成提交与 tree。
- 构建产物、manifest 与受控文件哈希。
- 运行进程的 executable、app 路径、启动参数和 userData。
- Provider/profile/model/API version/schema/能力路由等 Provider 合同身份。
- 文档、工作流节点、资源、revision、语言 session、分析/批准 authority。

源提交、构建、运行进程、userData、Provider 和文档身份中任何一项未知，都不能把截图升级为完整根因或稳定性证明。

### 3. 证据阶梯不得混用

只按实际达到的等级声明：

1. `CODE_REVIEW_APPROVED`
2. `LIVE_PROVIDER_CONTRACT_PASSED`
3. `PACKAGED_APP_PASSED`
4. `HUMAN_FUNCTION_ACCEPTED`

Mock、fixture 和序列化测试不能替代真实 Provider；真实 Provider canary 不能替代打包 APP；打包启动不能替代完整真人生命周期。

### 4. 异步权威必须线性化

- 操作开始时捕获 identity key；在每个 await 后重新检查 session、revision、binding、资源指纹和当前节点。
- 文档写入进入既有 `structural queue`，不能用旧快照覆盖新文档。
- 最新权威获胜；过期操作不得发布资源、结果、任务成功或执行状态。
- 若一次外部副作用无法回滚，应在报告中区分“历史资源可能存在”和“有效工作流不得引用”，并把 crash recovery 留作显式残余。

## 失败与弯路台账

每次复盘记录“现象—误导方向—真实边界—下次最小证伪”，不要只记录最终补丁。

| 弯路 | 为什么会误导 | 下次如何避开 |
|---|---|---|
| 先改 UI 或按钮，再确认 service readiness | UI 可用不代表专用路由、session 与能力已就绪 | 先做 readiness identity probe，再打开交互 |
| 把 mock/fake network 的绿灯称为真实闭环 | fixture 往往返回理想 JSON，掩盖 Provider 400、非 STOP、缺图或模型能力差异 | Provider 合同变化先跑受控 live canary |
| 把通用错误文案当根因 | 一个错误码可能折叠请求、响应、解析、导入和本地合成 | 在最早未知边界增加闭合 stage trace，不记录正文或凭据 |
| 未定位根因就反复打 QA 包和让人点击 | 重复真人运行只重复低信息量失败并增加版本混淆 | 先做一个最小 falsifier；只有证据等级提升才重包 |
| 为单一工作流改共享默认路由 | 会重开已经冻结的消费者 | 专用 capability/input kind/owner，冻结消费者保留原路由 |
| 把分析、保存、生成合成一个“可用”状态 | 后段 authority、revision 或批准可能已失效 | 生命周期逐段收据与独立门禁 |
| 自造 language session 或缓存 readiness | 真实 session 旋转后旧权威仍看似可用 | 订阅当前 session；pending/error/identity mismatch 都 fail closed |
| 只在 Provider 调用前检查 authority | Provider、资源或 run commit 等待期间可能变旧 | 每个 await 后复核，尤其资源与 executed commit 后 |
| 用 Portal/屏幕坐标固定面板 | 节点拖动、缩放、重开后界面脱离 owner | 将面板放入节点 transform 子树，位置属于节点内部 |
| 输出位置只放 React 临时状态 | 文档刷新后 snap back | 结果位置写入受约束的 document/run 合同 |
| 编辑后继续复用旧 revision/approval | 用户看到新内容，生成却使用旧批准 | dirty comparison + 保存中禁生成 + 新 revision/approval |
| 把全套测试的陈旧 fixture 或 5 秒 timeout 当产品回归 | 修产品会掩盖测试所有者问题 | 先 isolated reproduce；fixture-only closure 与产品修复分开 |
| 测试夹具身份错误被误判为真实集成缺陷 | 例如 credential 解密类型或请求角色错误，网络根本未发生 | 记录 network call count 与首个失败边界 |
| 移植时整文件覆盖共享 owner | 会抹掉目标版本中已经批准的新行为 | 做三方差异与语义并集，逐 hunk 保留两边 authority |
| 刚批准就重构共享服务 | 证据尚只覆盖一个身份，重构会扩大故障域 | 优化另起 Candidate，先做非行为性清理 |

当新证据推翻旧假设时，将旧路线标为“已证伪”，禁止以换名称的方式再次尝试。

## 成功路线

1. 写出一个完整、可观察的用户结果和禁止影响的冻结消费者。
2. 把生命周期拆成 readiness、输入分析、编辑、保存并应用、生成、结果发布/结果位置六类 owner。
3. 在最早未知边界写最小 RED；fake 只停在 network 边界，production composition/IPC/UI 必须是真实链。
4. 绑定 source/resource/revision/session/model/approval identity，并检查所有异步提交点。
5. 只有 Provider 合同变化时才跑受控 live canary；成功前不打物理 QA 包。
6. 代码、类型、聚焦控制和必要全套通过后构建唯一 Candidate。
7. 真人只执行本轮声明的精确路径；失败先取闭合 stage，不先改下一层。
8. 成功后建立冻结胶囊，再停止修改该路径。
9. 需要进入更新版本时，在独立工作树做语义并集移植。
10. 最终声明只覆盖已验证身份、生命周期与恢复范围；未知项继续保留。

## 冻结胶囊

真人批准后立即生成一个可恢复的冻结胶囊，至少包含：

- 产品源 commit/tree、治理 seal、集成 commit/tree，彼此不可混称。
- 物理 QA 路径、manifest、payload ledger、关键 runtime/native 哈希和快捷方式身份。
- 人类实际执行的步骤、输入角色、成功结果及未测试范围。
- owner、直接依赖、共享依赖、冻结消费者、禁止下游和 reopen 条件。
- 自动、live、打包、真人四级证据以及每级时间/身份。
- 回滚点、旧包保留策略、TestData 只引用不读取的边界。

冻结胶囊用于恢复真值，不把整个目录当可移植代码，也不允许较低等级的新测试重开冻结消费者。

## 语义并集移植

1. 记录目标稳定基线及其已批准行为；在独立工作树执行。
2. 未经明确授权不得默认 `fetch`、`pull`、push 或改变远端状态，避免隐式网络状态变化。
3. 对源批准提交、共同祖先、目标稳定树做三方差异。
4. 共享文件禁止整文件覆盖；逐 hunk 建立语义并集：目标稳定行为 + 已批准工作流，不携带过期实验。
5. 用 patch-id/range-diff/blob/行为测试证明批准补丁保留，同时审计目标专属逻辑未删除。
6. 只形成一个集成 commit 和单一 Candidate，并保留明确回滚点。
7. 先跑 owner focused tests 与冻结消费者控制，再对最终集成树跑一次所需全量门禁；不要机械地对 A、B、集成树重复全量证据。
8. 当 Provider 合同身份未变、受控构建哈希与权威输入未变时，可以复用 live 证据，并明确“复用”而非伪称本轮重跑；若 Provider/API/schema/model/session 合同变化则必须重开 canary。
9. 只有 clean、review 通过、身份与证据闭合后，才用 `--ff-only` 更新稳定分支；不默认推送。

## 稳定性评估

分别评级，不给一个笼统“稳定”：

- **功能稳定性：** 精确生命周期是否真人重复跑通。
- **权威稳定性：** resource/revision/session/model/approval 是否绑定当前值。
- **异步稳定性：** 每个 await 后是否防止 stale publish；structural queue 是否覆盖写入。
- **路由稳定性：** 专用工作流是否与冻结消费者隔离。
- **集成稳定性：** 语义并集后的最终树是否保留两边批准行为。
- **恢复稳定性：** 重开、重启、跨机器、崩溃窗口是否有证据。

推荐结论格式：

`对 <commit/tree + package + userData + Provider contract> 的 <精确用户路径> 已稳定；<重复批次/重启/跨机器/crash recovery> 仍未知。`

“一次成功”可冻结为批准事实，但不能自动升级为高频稳定或恢复稳定。

## 优化合同

优化只能在一致跑通后进行，而且必须另起 Candidate；冻结消费者与批准包保持 Stable。

优化顺序从低风险到高风险：

1. 文档、测试命名、fixture factory 与只读报告去重。
2. 将超大 harness 拆为纯解析器、纯 body builder 和纯断言 helper，保持字节级合同不变。
3. 用可重复基准证明性能瓶颈后再优化；不以主观“更快”改并发或缓存。
4. 最后才抽取共享合同；优先共享类型/验证器，不共享运行时实例、路由或状态。

每个优化 Candidate 必须：

- 声明不变量、变更预算和回滚点。
- 保留原 dedicated tests，并先证明行为等价。
- 不使用非确定输出 golden 作为唯一 oracle；验证结构、身份、边界和不变量。
- 不默认引入 feature flag、shadow mode、双路 Provider 调用或多个活跃 Candidate。
- 若改变 Provider/API/schema/model/session/approval/持久化合同，重新走相应 canary、打包和真人门禁。

## 不要做什么

- 不因“代码更整洁”重开已冻结路径。
- 不把同一失败先验合并成一个根因；先找最早可证伪边界。
- 不以重复真人运行代替诊断证据。
- 不用整文件 checkout、复制旧 app/dist 或强制 reset 完成移植。
- 不在 canary 失败时增加 fallback、重试或第二模型掩盖合同错误。
- 不重复全量证据来制造确定感；证据必须对应新风险。
- 不删除批准包、回滚点、冻结胶囊或 TestData authority。
