# 2026-08-16 Visual AI Development Governance Skill — deployment review

## Scope and status

- Source root: `.codex/skills/visual-ai-development-governance`
- Reviewed change range: `d236181..2933d45`, plus this post-deployment evidence correction.
- Status: `DEPLOYED_AND_VERIFIED`; the independently approved exact 19-path candidate was deployed and its repository/installed identity was verified.
- Installed root: `C:/Users/HP/.codex/skills/visual-ai-development-governance` was read only during pre-deployment comparison, then received only the reviewed 19 paths; no deletion or unrelated installed-Skill write occurred.
- Product runtime, credentials, TestData, project governance files, and `main` were not touched.

## Exact deployment candidate contract

The deployment set is exactly the paths below. `outputs/2026-08-16-visual-ai-development-governance-skill-manifest.sha256` is a special case: it attests every other live file, but cannot attest itself without a circular hash. Its source identity must instead be checked by direct SHA-256 during the approved copy operation and by the reviewed Git commit after Task 4 is committed.

All other candidates, including this review, must have one and only one matching line in the 2026-08-16 manifest. The manifest test enumerates the complete live tree (excluding only the manifest itself), so it detects omissions, additions, or post-review edits.

| Relative path | Reason | Required identity check |
|---|---|---|
| `SKILL.md` | Routes repeated-work, frozen-scope, impact, and new-chat triggers. | 2026-08-16 manifest SHA-256 |
| `evals/evals.json` | Adds cases 24–27. | 2026-08-16 manifest SHA-256 |
| `evals/lightweight-memory-pressure-results.json` | Records paired pressure grades. | 2026-08-16 manifest SHA-256 |
| `evals/pressure/contexts/lightweight-memory-round-1-manifest.sha256` | Preserves round-1 provenance. | 2026-08-16 manifest SHA-256 |
| `evals/pressure/contexts/lightweight-memory-round-2-manifest.sha256` | Preserves round-2 provenance. | 2026-08-16 manifest SHA-256 |
| `evals/pressure/lightweight-memory-baseline.md` | Preserves baseline output. | 2026-08-16 manifest SHA-256 |
| `evals/pressure/lightweight-memory-with-skill.md` | Preserves first revised-skill output. | 2026-08-16 manifest SHA-256 |
| `evals/pressure/lightweight-memory-with-skill-round-2.md` | Preserves successful revised-skill output. | 2026-08-16 manifest SHA-256 |
| `evals/repeated-failure-pressure-results.json` | Preserves earlier pressure evidence compatibility. | 2026-08-16 manifest SHA-256 |
| `references/lightweight-development-memory.md` | Defines the compact four-authority contract. | 2026-08-16 manifest SHA-256 |
| `templates/DECISION_LEDGER.md` | Extends an existing ledger with reusable issue signatures. | 2026-08-16 manifest SHA-256 |
| `templates/READINESS_LEDGER.md` | Extends an existing ledger with frozen acceptance. | 2026-08-16 manifest SHA-256 |
| `tests/test_current_manifest.py` | Requires a current complete live-tree manifest; no skip remains. | 2026-08-16 manifest SHA-256 |
| `tests/test_eval_assets.py` | Validates the four new evaluation cases. | 2026-08-16 manifest SHA-256 |
| `tests/test_lightweight_development_memory.py` | Enforces the lightweight-memory structural contract. | 2026-08-16 manifest SHA-256 |
| `tests/test_pressure_evidence.py` | Validates pressure-evidence provenance and results. | 2026-08-16 manifest SHA-256 |
| `tests/test_reference_integrity.py` | Includes the new reusable reference in integrity coverage. | 2026-08-16 manifest SHA-256 |
| `outputs/2026-08-16-visual-ai-development-governance-skill-review.md` | This independent-review input. | 2026-08-16 manifest SHA-256 |
| `outputs/2026-08-16-visual-ai-development-governance-skill-manifest.sha256` | Complete-tree attestation. | Direct source/installed SHA-256 plus reviewed Git commit |

No design document, implementation plan, SDD work file, product file, or project-specific governance ledger is a deployment candidate.

## Historical-snapshot boundary

`outputs/2026-08-15-visual-ai-development-governance-skill-manifest.sha256` remains a dated historical snapshot. It is not regenerated or compared to the changing live tree. The current-manifest test validates its syntax separately and validates the 2026-08-16 live tree only with the new manifest.

## Independent-review questions

Reject this candidate if review finds any of the following:

1. Duplicated lightweight-memory reference prose in `SKILL.md` instead of routing to the reference.
2. Project-specific incidents, identities, commit IDs, TestData, credentials, or prompts in the reusable Skill.
3. New execution authority, a new ledger family, or a background memory service.
4. A weakened human-acceptance, safe-Git, archive, or deletion boundary.
5. A missing/extra manifest path, a changed hash, a skipped current-manifest check, or any failed validation.

## Pre-deployment evidence (historical)

Run, from the source root's repository worktree, and attach exact output to the task report:

```powershell
python C:/Users/HP/.codex/skills/.system/skill-creator/scripts/quick_validate.py .codex/skills/visual-ai-development-governance
python -m unittest discover -s .codex/skills/visual-ai-development-governance/tests -p "test_*.py" -v
git diff --check
```

After independent approval, the operator copied the exact candidate list, computed source/installed SHA-256 for every path, and ran the same validation against the installed root. The completed evidence is recorded below.

## Independent-review disposition

The independent review approved the repository-side candidate. It found no duplicated lightweight-memory reference prose, project facts, new execution authority, new ledger family, or weakened human/Git/archive/delete boundary. The reviewed copy set remains the exact 19 paths above; no design document, plan, SDD record, product file, project ledger, credential, or TestData path is authorized for deployment.

The official validator was re-run against the repository root in a temporary dependency environment and passed:

```powershell
$env:PYTHONUTF8 = '1'
uv run --with pyyaml python C:/Users/HP/.codex/skills/.system/skill-creator/scripts/quick_validate.py .codex/skills/visual-ai-development-governance
```

This resolved the earlier host-runtime `PyYAML` absence without modifying the managed Python runtime.

## Post-deployment verification

- Repository and installed roots each contain 76 non-cache Skill files; the complete trees have zero source-only paths, zero installed-only paths, and zero SHA-256 differences.
- The approved deployment subset matched **19/19** source/installed SHA-256 checks.
- `quick_validate.py` passed against both source and installed roots with `PYTHONUTF8=1` and `uv run --with pyyaml`.
- The complete Python Skill suite passed against both source and installed roots: **38/38** in each location, including the active current-manifest test with no skip.
- Task 4 was recorded in Git as `2933d45 docs(governance): record lightweight memory deployment`.
- No product runtime, project governance ledger, TestData, credential, `main`, or unrelated installed Skill was changed.
