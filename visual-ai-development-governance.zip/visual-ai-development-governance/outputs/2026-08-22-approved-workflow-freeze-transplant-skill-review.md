# Approved workflow freeze/transplant extension review

Date: 2026-08-22

## Scope

This extension adds one routed reference for the lifecycle after human approval:

- freeze the approved identity and evidence as a recovery capsule;
- transplant it into an updated stable version by semantic union;
- optimize only after consistent end-to-end operation, in a separate Candidate.

It does not grant permission to edit product code, run Provider calls, package applications, push branches, or delete assets.

## RED pressure findings

Three baseline scenarios exposed gaps in the prior skill:

1. Repeated cross-stage failures were prematurely merged into one state-sync root cause and scheduled for repeated human runs.
2. Transplant guidance defaulted to `fetch/pull`, repeated A/B/integration full suites, and implicit push/PR steps.
3. Post-approval optimization proposed non-deterministic golden outputs, default shadow/feature-flag migration, and shared runtime extraction too early.

## GREEN pressure findings

After the extension:

1. Repeated failures were split by lifecycle owner, identity was checked first, and a single earliest-boundary falsifier preceded any new human run.
2. Transplant used an isolated worktree, three-way semantic union, no implicit network or remote write, one final integrated full gate, and scoped evidence reuse.
3. Optimization kept Stable frozen, used one separate Candidate, started with non-behavioral cleanup, retained dedicated tests and rejected non-deterministic golden output as the sole oracle.

No GREEN response introduced a broader product route, extra Provider call, or automatic external Git mutation.

## Project grounding

The rules were distilled from the approved InteriorCanvas 3D Stage A path, including its failures around readiness, language session, revision/approval identity, post-await stale publication, panel anchoring, result-position persistence, fixture drift, canary ordering and semantic transplant. Project-specific facts remain in the repository report and are not embedded as universal product requirements.

## Verdict

`RED_PRESSURE_CAPTURED=true`

`GREEN_PRESSURE_PASSED=true`

`REFERENCE_IS_GENERIC=true`

`GOVERNANCE_WEIGHT_INCREASE=bounded`

`PRODUCT_EXECUTION_AUTHORITY_CHANGED=false`
