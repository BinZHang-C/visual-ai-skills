from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
REFERENCE = ROOT / "references" / "capability-routing-governance.md"


class ExpertPromptWorkflowClosureTests(unittest.TestCase):
    def test_reference_defines_the_expert_prompt_lifecycle_and_owner_path(self):
        text = REFERENCE.read_text(encoding="utf-8")
        self.assertIn("## 专家提示词节点闭环", text)
        for stage in [
            "输入分析",
            "草稿编辑",
            "翻译、校验与审批",
            "保存与应用",
            "重开与恢复",
            "生成执行",
        ]:
            self.assertIn(stage, text)
        for owner in [
            "UI → preload/IPC → composition",
            "workflow 专属 analysis service",
            "execution transport → Provider",
            "response parsing/attestation",
            "translation/verification/approval",
            "persistence/apply",
        ]:
            self.assertIn(owner, text)

    def test_reference_requires_contract_reuse_without_runtime_instance_sharing(self):
        text = REFERENCE.read_text(encoding="utf-8")
        self.assertIn("复用合同，不复用运行实例", text)
        for allowed in ["凭据存储", "安全网络基础设施", "纯函数合同"]:
            self.assertIn(allowed, text)
        for isolated in ["workflow 专属 execution", "独立 analysis service"]:
            self.assertIn(isolated, text)
        self.assertIn("不得修改共享默认路由", text)
        self.assertIn("合同身份完全相同", text)
        self.assertIn("不得重复 live canary", text)

    def test_reference_requires_composition_red_mutation_and_repeated_save_evidence(self):
        text = REFERENCE.read_text(encoding="utf-8")
        for gate in [
            "真实 composition",
            "角色/序号",
            "错误共享路由调用数为零",
            "重新绑定到旧共享服务",
            "首次保存",
            "修改后二次保存",
            "重开后保存",
        ]:
            self.assertIn(gate, text)
        self.assertIn("分析成功不能证明保存成功", text)
        self.assertIn("一次保存成功不能证明多次保存成功", text)


if __name__ == "__main__":
    unittest.main()
