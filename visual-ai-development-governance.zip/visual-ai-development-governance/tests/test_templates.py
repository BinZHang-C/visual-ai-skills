from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1]
TEMPLATES = [
    "PROJECT_TRUTH.md",
    "DECISION_LEDGER.md",
    "READINESS_LEDGER.md",
    "CLEANUP_LEDGER.md",
    "PARALLEL_BRANCH_MATRIX.md",
    "HANDOFF_BRIEF.md",
    "GIT_READINESS_SUMMARY.md",
    "BRANCH_INTEGRATION_REVIEW.md",
    "RETROSPECTIVE.md",
    "CAPABILITY_ROUTE_REGISTER.md",
]


class TemplateTests(unittest.TestCase):
    def test_templates_have_stable_metadata_and_no_execution(self):
        for name in TEMPLATES:
            path = ROOT / "templates" / name
            self.assertTrue(path.exists(), f"missing {name}")
            text = path.read_text(encoding="utf-8")
            self.assertIn("最后更新时间", text)
            self.assertIn("证据来源", text)
            self.assertNotRegex(text, r"\b(?:TODO|TBD)\b")
            self.assertNotRegex(text, r"(?i)git\s+(commit|push|merge|rebase|cherry-pick|reset|clean)\b")
            self.assertNotRegex(text, r"(?i)Remove-Item|rm\s+-rf")

    def test_four_memory_templates_keep_distinct_authority(self):
        truth = (ROOT / "templates" / "PROJECT_TRUTH.md").read_text(encoding="utf-8")
        decisions = (ROOT / "templates" / "DECISION_LEDGER.md").read_text(encoding="utf-8")
        readiness = (ROOT / "templates" / "READINESS_LEDGER.md").read_text(encoding="utf-8")
        cleanup = (ROOT / "templates" / "CLEANUP_LEDGER.md").read_text(encoding="utf-8")
        self.assertIn("TRUTH-YYYYMMDD-NNN", truth)
        self.assertIn("当前唯一有效", truth)
        self.assertIn("DEC-YYYYMMDD-NNN", decisions)
        self.assertIn("旧规则", decisions)
        self.assertIn("EVD-YYYYMMDD-NNN", readiness)
        self.assertIn("成熟度", readiness)
        self.assertIn("ASSET-YYYYMMDD-NNN", cleanup)
        self.assertIn("恢复方式", cleanup)

    def test_human_facing_summaries_use_five_part_output(self):
        for name in [
            "HANDOFF_BRIEF.md",
            "GIT_READINESS_SUMMARY.md",
            "BRANCH_INTEGRATION_REVIEW.md",
            "RETROSPECTIVE.md",
        ]:
            text = (ROOT / "templates" / name).read_text(encoding="utf-8")
            for heading in [
                "## 当前事实",
                "## 发现的冲突或风险",
                "## 自我质疑结论",
                "## 建议的下一阶段路线及验收门禁",
                "## 需要人类决定的事项",
            ]:
                self.assertIn(heading, text, f"{name} missing {heading}")

    def test_branch_matrix_covers_overlap_and_human_options(self):
        matrix = (ROOT / "templates" / "PARALLEL_BRANCH_MATRIX.md").read_text(encoding="utf-8")
        for term in ["目标重叠", "文件重叠", "语义重叠", "时序依赖", "TASK-YYYYMMDD-NNN"]:
            self.assertIn(term, matrix)
        review = (ROOT / "templates" / "BRANCH_INTEGRATION_REVIEW.md").read_text(encoding="utf-8")
        for term in ["等价补丁", "部分集成", "疑似丢失", "选项 A", "选项 B"]:
            self.assertIn(term, review)


if __name__ == "__main__":
    unittest.main()
