import json
import hashlib
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
HISTORICAL_MANIFEST = "outputs/2026-08-15-visual-ai-development-governance-skill-manifest.sha256"
HISTORICAL_CAPTURED_ON = "2026-08-15"
REQUIRED_DIMENSIONS = {
    "owning_boundary",
    "identity_scope",
    "falsifiers",
    "failed_route",
    "solution_comparison",
    "real_path_gate",
    "failure_isolation",
    "bounded_claim",
    "evidence_scope",
}
LIGHTWEIGHT_EXPECTATION_COUNTS = {24: 5, 25: 5, 26: 5, 27: 5}
IMMUTABLE_ROUND_ONE_RECEIPTS = {
    "evals/pressure/lightweight-memory-baseline.md": "359d4746a1741e128572e9afbe21da9fd93ffb217993acb1e1d9d47d43bc7202",
    "evals/pressure/lightweight-memory-with-skill.md": "21845d4d4dbc00870845004722d4648676e0013cc1e61fdf99bcd9bcfa2d2f45",
}


def manifest_entries(path: Path):
    entries = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        digest, relative = line.split("  ", 1)
        entries[relative] = digest
    return entries


class PressureEvidenceTests(unittest.TestCase):
    def test_lightweight_memory_pressure_provenance_is_immutable_and_auditable(self):
        for relative, digest in IMMUTABLE_ROUND_ONE_RECEIPTS.items():
            self.assertEqual(digest, hashlib.sha256((ROOT / relative).read_bytes()).hexdigest())

        payload = json.loads((ROOT / "evals" / "lightweight-memory-pressure-results.json").read_text(encoding="utf-8"))
        self.assertEqual("2.0", payload["schema_version"])
        self.assertEqual(["round-1", "round-2"], [round_["round_id"] for round_ in payload["rounds"]])

        prompts = {
            case["id"]: case["prompt"]
            for case in json.loads((ROOT / "evals" / "evals.json").read_text(encoding="utf-8"))["evals"]
            if case["id"] in LIGHTWEIGHT_EXPECTATION_COUNTS
        }
        audited_outputs = set()
        for round_ in payload["rounds"]:
            manifest = ROOT / round_["skill_manifest_file"]
            self.assertEqual(round_["skill_manifest_sha256"], hashlib.sha256(manifest.read_bytes()).hexdigest())
            manifest_hashes = manifest_entries(manifest)
            self.assertTrue(manifest_hashes)
            self.assertEqual({24, 25, 26, 27}, {case["id"] for case in round_["cases"]})

            for case in round_["cases"]:
                self.assertEqual(prompts[case["id"]], case["prompt"])
                self.assertEqual(case["prompt_sha256"], hashlib.sha256(case["prompt"].encode("utf-8")).hexdigest())
                for variant_name, receipt in case["receipts"].items():
                    self.assertIn(variant_name, {"baseline", "with_skill"})
                    self.assertEqual(
                        {
                            "agent_task", "captured_on", "model_runtime", "fork_turns",
                            "system_context_hash", "system_context_note", "input_context_file",
                            "input_context_sha256", "input_context_note", "skill_context",
                            "output_file", "output_sha256", "grades", "passed",
                        },
                        set(receipt),
                    )
                    self.assertEqual("none", receipt["fork_turns"])
                    self.assertEqual("unavailable", receipt["system_context_hash"])
                    self.assertIn("not exposed", receipt["system_context_note"])
                    if receipt["input_context_sha256"] == "unavailable":
                        self.assertIn("not recoverable", receipt["input_context_note"])
                    else:
                        input_context = ROOT / receipt["input_context_file"]
                        self.assertEqual(receipt["input_context_sha256"], hashlib.sha256(input_context.read_bytes()).hexdigest())

                    for artifact in receipt["skill_context"]:
                        self.assertEqual({"path", "sha256", "manifest"}, set(artifact))
                        self.assertEqual(round_["skill_manifest_file"], artifact["manifest"])
                        self.assertEqual(artifact["sha256"], manifest_hashes[artifact["path"]])

                    output = (ROOT / receipt["output_file"]).read_text(encoding="utf-8")
                    audited_outputs.add(output)
                    marker = f"## Case {case['id']}"
                    section = output.split(marker, 1)[1].split("\n## Case ", 1)[0].strip()
                    self.assertEqual(receipt["output_sha256"], hashlib.sha256(section.encode("utf-8")).hexdigest())
                    self.assertEqual(LIGHTWEIGHT_EXPECTATION_COUNTS[case["id"]], len(receipt["grades"]))
                    for index, grade in enumerate(receipt["grades"], start=1):
                        self.assertEqual(index, grade["expectation_id"])
                        self.assertEqual({"expectation_id", "expectation", "passed", "evidence", "line_start", "line_end"}, set(grade))
                        self.assertTrue(grade["expectation"].strip())
                        self.assertTrue(grade["evidence"].strip())
                        self.assertGreaterEqual(grade["line_start"], 1)
                        self.assertGreaterEqual(grade["line_end"], grade["line_start"])
                        self.assertLessEqual(grade["line_end"], len(section.splitlines()))
                    self.assertEqual(receipt["passed"], all(grade["passed"] for grade in receipt["grades"]))

        latest = payload["rounds"][-1]
        self.assertTrue(all(case["receipts"]["with_skill"]["passed"] for case in latest["cases"]))
        generic_evidence = ("\n".join(audited_outputs) + "\n" + json.dumps(payload, ensure_ascii=False)).casefold()
        for forbidden in ("testdata", "interior canvas", "tapcanvas", "api_key", "secret", "token"):
            self.assertNotIn(forbidden, generic_evidence)

    def test_lightweight_memory_pressure_receipts_are_complete_and_generic(self):
        results_path = ROOT / "evals" / "lightweight-memory-pressure-results.json"
        payload = json.loads(results_path.read_text(encoding="utf-8"))

        self.assertEqual("visual-ai-development-governance", payload["skill_name"])
        self.assertEqual("paired fresh-context pressure receipts", payload["evaluation_mode"])
        self.assertEqual({24, 25, 26, 27}, {case["id"] for case in payload["cases"]})

        receipts = {}
        for case in payload["cases"]:
            self.assertEqual(
                {"id", "baseline_file", "with_skill_file", "baseline_failed", "with_skill_passed", "observed_delta"},
                set(case),
            )
            self.assertIsInstance(case["baseline_failed"], bool)
            self.assertIsInstance(case["with_skill_passed"], bool)
            self.assertTrue(case["observed_delta"].strip())
            for file_key in ("baseline_file", "with_skill_file"):
                receipt_path = ROOT / case[file_key]
                self.assertTrue(receipt_path.is_file())
                receipt = receipt_path.read_text(encoding="utf-8")
                self.assertIn(f"## Case {case['id']}", receipt)
                self.assertGreater(len(receipt.strip()), 200)
                receipts[receipt_path] = receipt

        self.assertTrue(any(case["baseline_failed"] for case in payload["cases"]))
        self.assertTrue(any(case["with_skill_passed"] for case in payload["cases"]))
        combined = "\n".join(receipts.values()).casefold()
        for forbidden in ("testdata", "interior canvas", "tapcanvas", "api_key", "secret", "token"):
            self.assertNotIn(forbidden, combined)

    def test_paired_pressure_results_preserve_outputs_and_assertion_grades(self):
        path = ROOT / "evals" / "repeated-failure-pressure-results.json"
        payload = json.loads(path.read_text(encoding="utf-8"))

        self.assertEqual("visual-ai-development-governance", payload["skill_name"])
        self.assertEqual(
            {"retry-pressure", "identity-pressure", "claim-pressure"},
            {case["id"] for case in payload["cases"]},
        )

        failed_across_baseline = set()
        for case in payload["cases"]:
            prompt_path = ROOT / case["prompt_file"]
            prompt = prompt_path.read_text(encoding="utf-8")
            self.assertGreater(len(prompt), 40)
            baseline_output = (ROOT / case["baseline_output_file"]).read_text(encoding="utf-8")
            with_skill_output = (ROOT / case["with_skill_output_file"]).read_text(encoding="utf-8")
            self.assertGreater(len(baseline_output), 200)
            self.assertGreater(len(with_skill_output), 200)
            self.assertEqual(REQUIRED_DIMENSIONS, set(case["baseline_grades"]))
            self.assertEqual(REQUIRED_DIMENSIONS, set(case["with_skill_grades"]))

            for grade in [*case["baseline_grades"].values(), *case["with_skill_grades"].values()]:
                self.assertEqual({"passed", "evidence", "line_start", "line_end"}, set(grade))
                self.assertIsInstance(grade["passed"], bool)
                self.assertGreater(len(grade["evidence"]), 8)
                self.assertGreaterEqual(grade["line_start"], 1)
                self.assertGreaterEqual(grade["line_end"], grade["line_start"])
            self.assertTrue(all(grade["line_end"] <= len(baseline_output.splitlines()) for grade in case["baseline_grades"].values()))
            self.assertTrue(all(grade["line_end"] <= len(with_skill_output.splitlines()) for grade in case["with_skill_grades"].values()))

            for receipt_name, output in [
                ("baseline_receipt", baseline_output),
                ("with_skill_receipt", with_skill_output),
            ]:
                receipt = case[receipt_name]
                self.assertEqual(
                    {"agent_task", "captured_on", "model_runtime", "input_context_file", "input_context_sha256", "system_context_hash", "system_context_note", "skill_context", "output_sha256"},
                    set(receipt),
                )
                input_context = ROOT / receipt["input_context_file"]
                self.assertEqual(receipt["input_context_sha256"], hashlib.sha256(input_context.read_bytes()).hexdigest())
                self.assertEqual(receipt["output_sha256"], hashlib.sha256(output.encode("utf-8")).hexdigest())
                self.assertEqual("unavailable", receipt["system_context_hash"])
                self.assertIn("not exposed", receipt["system_context_note"])
                for artifact in receipt["skill_context"]:
                    snapshot_manifest = artifact.get("snapshot_manifest")
                    if receipt["captured_on"] == HISTORICAL_CAPTURED_ON:
                        self.assertEqual(HISTORICAL_MANIFEST, snapshot_manifest)
                        snapshot_entries = manifest_entries(ROOT / snapshot_manifest)
                        self.assertEqual(artifact["sha256"], snapshot_entries[artifact["path"]])
                    elif snapshot_manifest:
                        snapshot_entries = manifest_entries(ROOT / snapshot_manifest)
                        self.assertEqual(artifact["sha256"], snapshot_entries[artifact["path"]])
                    else:
                        # Current receipts without a declared snapshot bind to live source bytes.
                        artifact_path = ROOT / artifact["path"]
                        self.assertEqual(artifact["sha256"], hashlib.sha256(artifact_path.read_bytes()).hexdigest())

            folded_output = with_skill_output.casefold()
            for forbidden in case["forbidden_factual_claims"]:
                self.assertNotIn(forbidden.casefold(), folded_output)

            self.assertTrue(all(grade["passed"] for grade in case["with_skill_grades"].values()))
            self.assertTrue(any(not grade["passed"] for grade in case["baseline_grades"].values()))
            failed_across_baseline.update(
                name for name, grade in case["baseline_grades"].items() if not grade["passed"]
            )

        self.assertTrue(
            {"owning_boundary", "falsifiers", "failed_route", "solution_comparison"}.issubset(
                failed_across_baseline
            )
        )


if __name__ == "__main__":
    unittest.main()
