import json
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]


class UnicodeSemanticTests(unittest.TestCase):
    def test_skill_keeps_required_simplified_chinese_meaning(self):
        text = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        expected = [
            "\u6cbb\u7406\u4e0e\u8bb0\u5fc6",
            "\u5f53\u524d\u4e8b\u5b9e",
            "\u53d1\u73b0\u7684\u51b2\u7a81\u6216\u98ce\u9669",
            "\u81ea\u6211\u8d28\u7591\u7ed3\u8bba",
            "\u9700\u8981\u4eba\u7c7b\u51b3\u5b9a\u7684\u4e8b\u9879",
        ]
        for phrase in expected:
            self.assertIn(phrase, text)

    def test_trigger_queries_are_real_chinese_not_mojibake(self):
        cases = json.loads((ROOT / "evals" / "trigger-evals.json").read_text(encoding="utf-8"))
        self.assertTrue(cases[0]["query"].startswith("\u6211\u8981\u4ece\u96f6\u89c4\u5212"))
        by_id = {case["id"]: case for case in cases}
        self.assertTrue(by_id["N10"]["query"].startswith("\u65e0\u9650\u753b\u5e03\u53f3\u4fa7\u9762\u677f"))
        self.assertTrue(by_id["N16"]["query"].startswith("\u8bf7\u67e5\u4e00\u4e0b\u5f53\u524dProvider"))
        mojibake_markers = ["\u92ae", "\u93c2", "\u935b"]
        for case in cases:
            self.assertFalse(any(marker in case["query"] for marker in mojibake_markers))


if __name__ == "__main__":
    unittest.main()
