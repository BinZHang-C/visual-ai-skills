from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
REFERENCE = ROOT / "references" / "capability-routing-governance.md"


class CatalogCapabilityRefreshGovernanceTests(unittest.TestCase):
    def test_reference_distinguishes_aggregate_readiness_from_per_model_support(self):
        text = REFERENCE.read_text(encoding="utf-8")
        for invariant in [
            "聚合唯一能力集合",
            "不能证明当前选中模型获得了新增能力",
            "比较刷新前后的精确能力集合",
            "贡献该能力的 deployment/modelId",
        ]:
            self.assertIn(invariant, text)

    def test_reference_treats_catalog_refresh_as_evidence_recovery_not_fallback(self):
        text = REFERENCE.read_text(encoding="utf-8")
        for invariant in [
            "Provider 派发前",
            "一次非计费目录刷新",
            "不是模型 fallback",
            "重新解析同一个精确 capability",
            "仍不可用则 fail closed",
        ]:
            self.assertIn(invariant, text)

    def test_reference_requires_refresh_receipt_without_sensitive_payloads(self):
        text = REFERENCE.read_text(encoding="utf-8")
        for field in [
            "observedAt/expiresAt",
            "刷新前后能力集合",
            "最终 modelId",
            "是否发生 Provider 生成调用",
        ]:
            self.assertIn(field, text)
        self.assertIn("不得记录凭据、原始响应或私有输入", text)


if __name__ == "__main__":
    unittest.main()
