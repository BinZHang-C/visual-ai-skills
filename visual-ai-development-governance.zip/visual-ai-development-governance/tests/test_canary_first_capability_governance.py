import hashlib
import json
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
BASELINE_SKILL_SHA256 = "162DAE2A12270ED3B48B519F4D12332A4C89851BAC6739A7B6F4EBA006278971"
RECORDED_CURRENT_SKILL_SHA256 = "8235BB244B5672183BFC1AAD209CD4CC4ADE2D5DB7B681FF0392310E579897DD"
BASELINE_CONCLUSIONS = {
    "provider-contract-deadline": ("failed", "packaged_before_live_canary"),
    "provider-cost-deadline": ("failed", "packaged_before_live_canary"),
    "shared-route-change": ("passed", None),
    "failure-classification": ("passed", None),
    "multi-version-pressure": ("passed", None),
}
CANONICAL_PROMPT_SHA256 = {
    "provider-contract-deadline": "194EDE1BC5F5AEDA67A1ED96577DDA7C9A2116EF5AEB28A5A85CC169F9A461F6",
    "provider-cost-deadline": "194EDE1BC5F5AEDA67A1ED96577DDA7C9A2116EF5AEB28A5A85CC169F9A461F6",
    "shared-route-change": "9FBDA84AFDBFF5BFD194C161FF46F1923A8E7B7B3246E755D5C6DE647D1F0254",
    "failure-classification": "3F1D624D2E63F8FECE801D0843CED718A8E1B6A55983D025385DCBAF5C127BD7",
    "multi-version-pressure": "3FD72E8DDE83866CCFD899BF775FA2490834034BF8C2330184C3971E4E2C3C9B",
}
CANONICAL_EVAL_IDS = {
    "provider-contract-deadline": 28,
    "provider-cost-deadline": 28,
    "shared-route-change": 29,
    "failure-classification": 30,
    "multi-version-pressure": 31,
}
FRESH_OUTPUT_SHA256 = {
    "provider-contract-deadline": "660692AE94C3D14BF74290D205B46C2EF224E10E5E891CEA19F059C9971F1DE9",
    "provider-cost-deadline": "A08EE0CA34539B8EAE490A9013F1301C058AD67E5686419D44CED9119B70EEDC",
    "shared-route-change": "C9E9591279FECA1DC90F1B9262747DF0ED67E4FD4A2A836760E0A5A522B1D418",
    "failure-classification": "894EF3085ED8699022C2348AA5FD83BC919749D15F5B565456DF78BF6310245F",
    "multi-version-pressure": "6979FB2EC462AA2957702A7098FD55E78368E2922F6BAC0B681385263C8600F7",
    "route-register-pressure": "D09956EBB6FF91AE4B5E3A3BF269D7366733A49F2A5C18079A86CC95FE41EF1C",
}
FRESH_OUTCOMES = {
    "provider-contract-deadline": "passed",
    "provider-cost-deadline": "passed",
    "shared-route-change": "passed",
    "failure-classification": "passed",
    "multi-version-pressure": "passed",
    "route-register-pressure": "passed",
}


class CanaryFirstCapabilityGovernanceTests(unittest.TestCase):
    def test_pressure_results_preserve_the_five_historical_baseline_conclusions(self):
        payload = json.loads(
            (ROOT / "evals" / "canary-first-pressure-results.json").read_text(encoding="utf-8")
        )
        self.assertEqual(1, payload["schema_version"])
        self.assertEqual("visual-ai-development-governance", payload["skill_name"])
        self.assertEqual(BASELINE_SKILL_SHA256, payload["baseline_skill_sha256"])
        self.assertEqual(RECORDED_CURRENT_SKILL_SHA256, payload["current_skill_sha256"])
        self.assertEqual(set(BASELINE_CONCLUSIONS), {case["id"] for case in payload["cases"]})
        evals_by_id = {
            case["id"]: case
            for case in json.loads((ROOT / "evals" / "evals.json").read_text(encoding="utf-8"))["evals"]
        }

        for case in payload["cases"]:
            expected_fields = {
                "id",
                "prompt_sha256",
                "provenance_note",
                "canonical_prompt_sha256",
                "baseline_outcome",
                "failure",
                "rationalization_excerpt",
                "revised_outcome",
                "revised_evidence_excerpt",
                "revised_output_sha256",
            }
            if case["id"] == "failure-classification":
                expected_fields.add("observed_rationalization")
            self.assertEqual(expected_fields, set(case))
            self.assertEqual("unavailable", case["prompt_sha256"])
            self.assertIn("original dispatched prompt bytes were not retained", case["provenance_note"])
            self.assertIn("reconstructed canonical", case["provenance_note"])
            self.assertEqual(CANONICAL_PROMPT_SHA256[case["id"]], case["canonical_prompt_sha256"])
            self.assertEqual(64, len(case["canonical_prompt_sha256"]))
            int(case["canonical_prompt_sha256"], 16)
            canonical_prompt = evals_by_id[CANONICAL_EVAL_IDS[case["id"]]]["prompt"]
            self.assertEqual(
                case["canonical_prompt_sha256"],
                hashlib.sha256(canonical_prompt.encode("utf-8")).hexdigest().upper(),
            )
            self.assertEqual(BASELINE_CONCLUSIONS[case["id"]], (case["baseline_outcome"], case["failure"]))
            self.assertTrue(case["rationalization_excerpt"].strip())
            self.assertEqual(FRESH_OUTCOMES[case["id"]], case["revised_outcome"])
            self.assertTrue(case["revised_evidence_excerpt"].strip())
            self.assertEqual(FRESH_OUTPUT_SHA256[case["id"]], case["revised_output_sha256"])
            self.assertEqual(64, len(case["revised_output_sha256"]))
            int(case["revised_output_sha256"], 16)
            if case["id"] == "failure-classification":
                self.assertEqual(
                    {
                        "excerpt": "先改解析器：Provider 已成功但本地 JSON 校验拒绝，最早直接证据落在响应解析边界。",
                        "output_sha256": "715A8152EF5E11D5B7A085977DACFD6E93E68047B6BEFD857DAF5D34B320FF0A",
                    },
                    case["observed_rationalization"],
                )

        green_only_cases = payload["green_only_cases"]
        self.assertEqual(1, len(green_only_cases))
        route_register = green_only_cases[0]
        self.assertEqual(
            {
                "id",
                "provenance_note",
                "revised_outcome",
                "revised_evidence_excerpt",
                "revised_output_sha256",
            },
            set(route_register),
        )
        self.assertEqual("route-register-pressure", route_register["id"])
        self.assertIn("not a historical baseline", route_register["provenance_note"])
        self.assertEqual("passed", route_register["revised_outcome"])
        self.assertTrue(route_register["revised_evidence_excerpt"].strip())
        self.assertEqual(FRESH_OUTPUT_SHA256[route_register["id"]], route_register["revised_output_sha256"])

    def test_revised_pressure_results_close_each_historical_failure_before_deployment(self):
        payload = json.loads(
            (ROOT / "evals" / "canary-first-pressure-results.json").read_text(encoding="utf-8")
        )
        self.assertEqual(
            FRESH_OUTCOMES,
            {
                case["id"]: case["revised_outcome"]
                for case in [*payload["cases"], *payload["green_only_cases"]]
            },
        )

    def test_historical_pressure_hash_is_not_rewritten_by_later_skill_revisions(self):
        # The receipt describes the revision evaluated at capture time. Later
        # governance changes must create a new manifest, not falsify this record.
        self.assertEqual(
            RECORDED_CURRENT_SKILL_SHA256,
            json.loads((ROOT / "evals" / "canary-first-pressure-results.json").read_text(encoding="utf-8"))["current_skill_sha256"],
        )


if __name__ == "__main__":
    unittest.main()
