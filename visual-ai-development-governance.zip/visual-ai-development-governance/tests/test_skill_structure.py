from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1]


class SkillStructureTests(unittest.TestCase):
    def test_skill_has_identity_triggers_workflow_and_boundaries(self):
        path = ROOT / "SKILL.md"
        self.assertTrue(path.exists(), "SKILL.md must exist")
        text = path.read_text(encoding="utf-8")
        self.assertRegex(text, r"(?m)^name:\s*visual-ai-development-governance\s*$")
        description = re.search(r"(?m)^description:\s*(.+)$", text)
        self.assertIsNotNone(description)
        for trigger in ["需求", "重复失败", "并行", "Git", "视觉"]:
            self.assertIn(trigger, description.group(1))
        for section in [
            "## Mission",
            "## Success Bar",
            "## Operating Loop",
            "## Mode Selection",
            "## Five-Part Output",
            "## Decision Rules",
            "## Boundaries",
            "## Common Failure Modes",
            "## Final Review",
            "## References",
        ]:
            self.assertIn(section, text)
        for heading in [
            "当前事实",
            "发现的冲突或风险",
            "自我质疑结论",
            "建议的下一阶段路线及验收门禁",
            "需要人类决定的事项",
        ]:
            self.assertIn(heading, text)
        for memory in [
            "PROJECT_TRUTH",
            "DECISION_LEDGER",
            "READINESS_LEDGER",
            "CLEANUP_LEDGER",
        ]:
            self.assertIn(memory, text)
        self.assertIn("不代理编码", text)
        self.assertIn("不执行 Git 写操作", text)
        self.assertIn("成果成熟度", text)
        for term in [
            "Canary-first",
            "CODE_REVIEW_APPROVED",
            "LIVE_PROVIDER_CONTRACT_PASSED",
            "PACKAGED_APP_PASSED",
            "HUMAN_FUNCTION_ACCEPTED",
            "新规则优先",
            "自我批评",
        ]:
            self.assertIn(term, text)
        self.assertLessEqual(len(text.splitlines()), 500)
        self.assertNotRegex(text, r"(?i)git\s+(commit|push|merge|rebase|cherry-pick|reset|clean)\b")


if __name__ == "__main__":
    unittest.main()
