from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
SKILL = ROOT / "SKILL.md"
REFERENCE = ROOT / "references" / "root-cause-completeness-and-human-qa-budget.md"
BASELINE = ROOT / "evals" / "root-cause-completeness-human-qa-budget-baseline.md"
REFACTOR = ROOT / "evals" / "root-cause-completeness-human-qa-budget-refactor.md"


class RootCauseCompletenessAndHumanQaBudgetTests(unittest.TestCase):
    def test_skill_routes_repeated_human_qa_and_new_input_shape_to_the_new_reference(self):
        text = SKILL.read_text(encoding="utf-8")
        for term in [
            "ROOT_CAUSE_COMPLETENESS", "HUMAN_QA_BUDGET", "MACHINE_REPRODUCER", "NEW_INPUT_SHAPE",
            "root-cause-completeness-and-human-qa-budget.md",
        ]:
            self.assertIn(term, text)

    def test_reference_requires_first_boundary_alternatives_and_a_human_qa_stop(self):
        text = REFERENCE.read_text(encoding="utf-8")
        for term in [
            "FIRST_FAILURE_BOUNDARY", "ADJACENT_ALTERNATIVES", "EXCLUSION_EVIDENCE", "MACHINE_REPRODUCER", "NO_NEW_QA",
            "HUMAN_QA_BUDGET", "COUNTEREVIDENCE_MATRIX", "CONTROLLED_CANARY", "CODE_GATE", "PACKAGE_GATE", "NEW_INPUT_SHAPE",
            "CODE_IDENTITY", "RUNTIME_CONFIGURATION", "INPUT_ENVELOPE", "SESSION_CACHE_CREDENTIAL_PERSISTENCE_STATE",
        ]:
            self.assertIn(term, text)

    def test_pressure_baseline_and_refactor_receipts_cover_three_time_pressure_cases(self):
        for receipt in [BASELINE, REFACTOR]:
            text = receipt.read_text(encoding="utf-8")
            for term in ["Scenario A", "Scenario B", "Scenario C", "time pressure", "approved authority", "automated tests pass", "human repeats failure"]:
                self.assertIn(term, text)
        baseline = BASELINE.read_text(encoding="utf-8")
        for rationalization in ["ask the human to retry", "build a new QA", "compare only the commit", "Provider", "alternative-cause matrix"]:
            self.assertIn(rationalization, baseline)
        refactor = REFACTOR.read_text(encoding="utf-8")
        for guard in ["stop packaging", "MACHINE_REPRODUCER", "FIRST_FAILURE_BOUNDARY", "ADJACENT_ALTERNATIVES", "human acceptance"]:
            self.assertIn(guard, refactor)

    def test_route_contract_distinguishes_stage_model_from_output_model(self):
        skill = SKILL.read_text(encoding="utf-8")
        routing = (ROOT / "references" / "capability-routing-governance.md").read_text(encoding="utf-8")
        for term in ["ROUTE_ROLE_BINDING", "STAGE_MODEL", "OUTPUT_MODEL", "outputSpec.modelAlias"]:
            self.assertIn(term, skill + routing)
        for term in [
            "translator", "verifier", "generator", "current authority route",
            "contract test", "role-swapped", "must fail",
        ]:
            self.assertIn(term, routing)

    def test_governance_routes_a_closed_contract_repair_to_the_companion_skill(self):
        self.assertIn(
            "repairing-route-contracts",
            SKILL.read_text(encoding="utf-8"),
        )


if __name__ == "__main__":
    unittest.main()
