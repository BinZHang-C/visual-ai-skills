from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "inspect_git_state.ps1"
SEED = ROOT / "tests" / "fixtures" / "git-overlap-repo" / "README.md"


def run(*args: str, cwd: Path) -> str:
    result = subprocess.run(args, cwd=cwd, capture_output=True, text=True, encoding="utf-8")
    if result.returncode:
        raise AssertionError(result.stdout + result.stderr)
    return result.stdout.strip()


def fingerprint(repo: Path) -> dict[str, str]:
    files = hashlib.sha256()
    for path in sorted(p for p in repo.rglob("*") if p.is_file() and ".git" not in p.parts):
        files.update(path.relative_to(repo).as_posix().encode())
        files.update(path.read_bytes())
    return {
        "head": run("git", "rev-parse", "HEAD", cwd=repo),
        "branches": run("git", "show-ref", "--heads", cwd=repo),
        "status": run("git", "status", "--porcelain=v1", cwd=repo),
        "files": files.hexdigest(),
    }


class GitStateInspectorTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.repo = Path(self.temp.name)
        shutil.copy2(SEED, self.repo / "README.md")
        run("git", "init", "-b", "main", cwd=self.repo)
        run("git", "config", "user.email", "fixture@example.invalid", cwd=self.repo)
        run("git", "config", "user.name", "Fixture", cwd=self.repo)
        run("git", "add", "README.md", cwd=self.repo)
        run("git", "commit", "-m", "base", cwd=self.repo)
        run("git", "switch", "-c", "feature-a", cwd=self.repo)
        (self.repo / "shared.txt").write_text("A\n", encoding="utf-8")
        run("git", "add", "shared.txt", cwd=self.repo)
        run("git", "commit", "-m", "feature a", cwd=self.repo)
        run("git", "switch", "main", cwd=self.repo)
        run("git", "switch", "-c", "feature-b", cwd=self.repo)
        (self.repo / "shared.txt").write_text("B\n", encoding="utf-8")
        run("git", "add", "shared.txt", cwd=self.repo)
        run("git", "commit", "-m", "feature b", cwd=self.repo)
        (self.repo / "untracked.txt").write_text("dirty\n", encoding="utf-8")

    def tearDown(self):
        self.temp.cleanup()

    def test_script_contains_no_mutating_commands(self):
        text = SCRIPT.read_text(encoding="utf-8")
        for forbidden in [
            "git commit", "git push", "git merge", "git rebase", "git reset", "git clean",
            "Remove-Item", "Move-Item", "Set-Content", "Add-Content",
        ]:
            self.assertNotIn(forbidden.lower(), text.lower())

    def test_inspection_reports_facts_and_does_not_mutate_repository(self):
        before = fingerprint(self.repo)
        result = subprocess.run(
            [
                "powershell", "-NoProfile", "-File", str(SCRIPT),
                "-Repository", str(self.repo), "-BranchA", "feature-a", "-BranchB", "feature-b",
            ],
            capture_output=True,
            text=True,
            encoding="utf-8",
        )
        self.assertEqual(0, result.returncode, result.stdout + result.stderr)
        payload = json.loads(result.stdout)
        self.assertEqual("feature-b", payload["branch"])
        self.assertTrue(payload["dirty"])
        self.assertIn("untracked.txt", payload["untrackedFiles"])
        self.assertIn("shared.txt", payload["comparison"]["overlappingFiles"])
        self.assertGreaterEqual(len(payload["worktrees"]), 1)
        self.assertEqual(before, fingerprint(self.repo))

    def test_invalid_repository_fails_without_side_effect(self):
        result = subprocess.run(
            ["powershell", "-NoProfile", "-File", str(SCRIPT), "-Repository", str(self.repo / "missing")],
            capture_output=True,
            text=True,
            encoding="utf-8",
        )
        self.assertEqual(2, result.returncode)


if __name__ == "__main__":
    unittest.main()
