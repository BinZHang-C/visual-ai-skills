from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1]
ADAPTERS = [
    "infinite-canvas.md",
    "presentation-agent.md",
    "video-editing.md",
    "image-to-video.md",
    "ecommerce-visual.md",
    "industrial-product.md",
    "interior-architecture.md",
]


class AdapterRoutingTests(unittest.TestCase):
    def test_adapters_declare_routing_and_boundaries(self):
        for name in ADAPTERS:
            path = ROOT / "references" / "adapters" / name
            self.assertTrue(path.exists(), f"missing {name}")
            text = path.read_text(encoding="utf-8")
            for key in ["applies_when:", "combine_with:", "does_not_cover:"]:
                self.assertIn(key, text)
            for section in [
                "## 事实来源",
                "## 对象身份",
                "## 人类控制权",
                "## 生命周期风险",
                "## 专项成果标准",
                "## 人类最终验收",
                "## 不要做什么",
            ]:
                self.assertIn(section, text)

    def test_domain_specific_rules_are_not_generic_copies(self):
        ppt = (ROOT / "references" / "adapters" / "presentation-agent.md").read_text(encoding="utf-8")
        self.assertIn("叙事", ppt)
        self.assertIn("母版", ppt)
        self.assertNotIn("端口必须", ppt)

        video = (ROOT / "references" / "adapters" / "video-editing.md").read_text(encoding="utf-8")
        self.assertIn("时间线", video)
        self.assertNotIn("SKU 必须", video)

        industrial = (ROOT / "references" / "adapters" / "industrial-product.md").read_text(encoding="utf-8")
        self.assertIn("尺寸来源", industrial)
        self.assertIn("工程事实", industrial)

        ecommerce = (ROOT / "references" / "adapters" / "ecommerce-visual.md").read_text(encoding="utf-8")
        self.assertIn("SKU", ecommerce)
        self.assertIn("infinite-canvas", ecommerce)


if __name__ == "__main__":
    unittest.main()
