from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "validate_governance_memory.py"
VALID = ROOT / "tests" / "fixtures" / "valid-memory"


def tree_hash(root: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(p for p in root.rglob("*") if p.is_file()):
        digest.update(path.relative_to(root).as_posix().encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


class GovernanceMemoryValidatorTests(unittest.TestCase):
    def run_validator(self, root: Path):
        return subprocess.run(
            [sys.executable, str(SCRIPT), "--root", str(root), "--format", "json"],
            capture_output=True,
            text=True,
            encoding="utf-8",
        )

    def test_valid_memory_is_accepted_without_mutation(self):
        before = tree_hash(VALID)
        result = self.run_validator(VALID)
        self.assertEqual(0, result.returncode, result.stdout + result.stderr)
        payload = json.loads(result.stdout)
        self.assertTrue(payload["valid"])
        self.assertEqual(before, tree_hash(VALID))

    def test_missing_file_is_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            target = Path(temp)
            for source in VALID.iterdir():
                if source.name != "CLEANUP_LEDGER.md":
                    (target / source.name).write_bytes(source.read_bytes())
            result = self.run_validator(target)
            self.assertEqual(1, result.returncode)
            self.assertIn("missing_required_file", result.stdout)

    def test_duplicate_truth_id_and_conflicting_current_facts_are_rejected(self):
        fixture = ROOT / "tests" / "fixtures" / "conflicting-memory"
        result = self.run_validator(fixture)
        self.assertEqual(1, result.returncode)
        self.assertIn("duplicate_id", result.stdout)
        self.assertIn("conflicting_current_truth", result.stdout)

    def test_unverified_fact_permission_language_and_unsafe_cleanup_are_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            target = Path(temp)
            for source in VALID.iterdir():
                (target / source.name).write_bytes(source.read_bytes())
            (target / "PROJECT_TRUTH.md").write_text(
                (target / "PROJECT_TRUTH.md").read_text(encoding="utf-8")
                + "\n| TRUTH-20260813-099 | 未验证假设 | 当前唯一有效 | 无 |\n",
                encoding="utf-8",
            )
            (target / "READINESS_LEDGER.md").write_text(
                (target / "READINESS_LEDGER.md").read_text(encoding="utf-8")
                + "\n该成熟度禁止继续开发。\n",
                encoding="utf-8",
            )
            (target / "CLEANUP_LEDGER.md").write_text(
                "# 清理记忆\n最后更新时间：现在\n证据来源：未知\n"
                "| ASSET-20260813-099 | cache | 删除候选 | 无 |\n",
                encoding="utf-8",
            )
            result = self.run_validator(target)
            self.assertEqual(1, result.returncode)
            for code in ["unverified_as_fact", "readiness_as_permission", "cleanup_without_recovery"]:
                self.assertIn(code, result.stdout)

    def test_invalid_root_returns_usage_error(self):
        result = self.run_validator(ROOT / "does-not-exist")
        self.assertEqual(2, result.returncode)
        self.assertIn("invalid_root", result.stdout)


if __name__ == "__main__":
    unittest.main()
