import json
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
REFERENCE = ROOT / "references" / "approved-workflow-freeze-transplant.md"
PRESSURE_RESULTS = ROOT / "evals" / "approved-freeze-transplant-pressure-results.json"


class ApprovedWorkflowFreezeTransplantTests(unittest.TestCase):
    def test_skill_routes_human_approved_freeze_transplant_and_optimization(self):
        skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        self.assertIn("approved-workflow-freeze-transplant.md", skill)
        for trigger in ["真人批准后", "冻结封装", "更新版本", "一致跑通", "优化"]:
            self.assertIn(trigger, skill)

    def test_reference_defines_the_complete_reusable_contract(self):
        self.assertTrue(REFERENCE.exists(), "missing approved-workflow-freeze-transplant.md")
        text = REFERENCE.read_text(encoding="utf-8")
        for section in [
            "## 何时读取",
            "## 一致跑通合同",
            "## 失败与弯路台账",
            "## 成功路线",
            "## 冻结胶囊",
            "## 语义并集移植",
            "## 稳定性评估",
            "## 优化合同",
            "## 不要做什么",
        ]:
            self.assertIn(section, text)

    def test_contract_closes_identity_lifecycle_async_and_evidence_gaps(self):
        text = REFERENCE.read_text(encoding="utf-8")
        for term in [
            "readiness", "输入分析", "编辑", "保存并应用", "生成", "结果位置",
            "源提交", "构建", "运行进程", "userData", "Provider", "文档",
            "CODE_REVIEW_APPROVED", "LIVE_PROVIDER_CONTRACT_PASSED",
            "PACKAGED_APP_PASSED", "HUMAN_FUNCTION_ACCEPTED",
            "每个 await 后", "structural queue", "最新权威",
        ]:
            self.assertIn(term, text)

    def test_transplant_and_optimization_keep_stable_authority_closed(self):
        text = REFERENCE.read_text(encoding="utf-8")
        for term in [
            "独立工作树", "禁止整文件覆盖", "三方差异", "语义并集", "--ff-only",
            "Provider 合同身份未变", "复用 live 证据", "冻结消费者",
            "单一 Candidate", "回滚点", "一致跑通后", "另起 Candidate",
        ]:
            self.assertIn(term, text)

    def test_pressure_results_capture_baseline_failures_and_green_expectations(self):
        self.assertTrue(PRESSURE_RESULTS.exists(), "missing pressure-results evidence")
        payload = json.loads(PRESSURE_RESULTS.read_text(encoding="utf-8"))
        self.assertEqual(payload["schemaVersion"], "visual-ai-governance-pressure/v1")
        self.assertEqual(len(payload["scenarios"]), 3)
        combined = json.dumps(payload, ensure_ascii=False)
        for term in [
            "根因先验合并", "重复真人运行", "隐式网络状态变化", "重复全量证据",
            "非确定输出 golden", "语义并集", "冻结胶囊", "一致跑通",
        ]:
            self.assertIn(term, combined)


if __name__ == "__main__":
    unittest.main()
