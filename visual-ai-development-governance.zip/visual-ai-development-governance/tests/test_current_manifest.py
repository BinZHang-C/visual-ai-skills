import hashlib
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
HISTORICAL_MANIFEST = ROOT / "outputs" / "2026-08-15-visual-ai-development-governance-skill-manifest.sha256"
DEPLOYMENT_MANIFEST = ROOT / "outputs" / "2026-08-23-visual-ai-development-governance-skill-manifest.sha256"


class CurrentManifestTests(unittest.TestCase):
    def test_skill_tree_forces_lf_checkout(self):
        attributes = (ROOT / ".gitattributes").read_text(encoding="utf-8")
        self.assertIn("* text eol=lf", attributes.splitlines())

    def test_dated_manifest_is_a_well_formed_historical_snapshot(self):
        entries = {}
        for line in HISTORICAL_MANIFEST.read_text(encoding="utf-8").splitlines():
            digest, relative = line.split("  ", 1)
            self.assertRegex(digest, r"^[0-9a-f]{64}$")
            self.assertNotIn("\\", relative)
            self.assertNotIn(relative, entries)
            entries[relative] = digest

        self.assertIn("SKILL.md", entries)
        self.assertIn("references/repeated-failure-closure.md", entries)

    def test_deployment_manifest_covers_and_hashes_the_complete_skill_tree(self):
        self.assertTrue(
            DEPLOYMENT_MANIFEST.exists(),
            "Task 4 must publish the complete live-tree deployment manifest",
        )

        entries = {}
        for line in DEPLOYMENT_MANIFEST.read_text(encoding="utf-8").splitlines():
            digest, relative = line.split("  ", 1)
            self.assertRegex(digest, r"^[0-9a-f]{64}$")
            self.assertNotIn("\\", relative)
            self.assertNotIn(relative, entries)
            entries[relative] = digest

        expected = {
            path.relative_to(ROOT).as_posix()
            for path in ROOT.rglob("*")
            if path.is_file() and path != DEPLOYMENT_MANIFEST
            and "__pycache__" not in path.parts
            and path.suffix != ".pyc"
        }
        self.assertEqual(expected, set(entries))
        for relative, expected_digest in entries.items():
            actual = hashlib.sha256((ROOT / relative).read_bytes()).hexdigest()
            self.assertEqual(expected_digest, actual, relative)


if __name__ == "__main__":
    unittest.main()
