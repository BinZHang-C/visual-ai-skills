from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
REFERENCE = ROOT / "references" / "lightweight-development-memory.md"


class LightweightDevelopmentMemoryTests(unittest.TestCase):
    def test_skill_routes_repeated_work_and_impact_to_reference(self):
        skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        self.assertIn("lightweight-development-memory.md", skill)
        for term in ["重复工作", "冻结", "影响面", "新对话"]:
            self.assertIn(term, skill)

    def test_reference_defines_four_authorities_and_receipt(self):
        text = REFERENCE.read_text(encoding="utf-8")
        for term in [
            "当前真值", "问题签名", "冻结验收", "影响与验收回执",
            "直接依赖", "共享消费者", "禁止下游", "真人复测", "未验证风险",
        ]:
            self.assertIn(term, text)

    def test_templates_support_reuse_without_new_ledgers(self):
        decisions = (ROOT / "templates" / "DECISION_LEDGER.md").read_text(encoding="utf-8")
        readiness = (ROOT / "templates" / "READINESS_LEDGER.md").read_text(encoding="utf-8")
        self.assertIn("稳定问题签名", decisions)
        self.assertIn("已证伪路线", decisions)
        self.assertIn("冻结验收清单", readiness)
        self.assertIn("文件哈希", readiness)
        self.assertIn("重新开放条件", readiness)


if __name__ == "__main__":
    unittest.main()
