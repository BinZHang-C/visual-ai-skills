import json
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
REFERENCE = ROOT / "references" / "repeated-failure-closure.md"


class RepeatedFailureClosureTests(unittest.TestCase):
    def test_skill_routes_repeated_and_conflicting_evidence_to_reference(self):
        skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        self.assertIn("repeated-failure-closure.md", skill)
        for trigger in ["第二次", "真实用户", "重试", "重开", "重启"]:
            self.assertIn(trigger, skill)

    def test_reference_defines_all_five_transferable_contracts(self):
        self.assertTrue(REFERENCE.exists(), "missing repeated-failure-closure.md")
        text = REFERENCE.read_text(encoding="utf-8")
        for section in [
            "## 何时读取",
            "## 根因分析合同",
            "## 方案比较合同",
            "## 执行合同",
            "## 输出合同",
            "## 验收合同",
            "## 不要做什么",
        ]:
            self.assertIn(section, text)

    def test_root_cause_contract_separates_identity_boundaries_and_falsifiers(self):
        text = REFERENCE.read_text(encoding="utf-8")
        for term in [
            "事件时间线", "用户动作", "可见结果", "持久化状态", "执行状态",
            "源分支", "构建", "运行进程", "userData", "Provider", "文档版本",
            "观察事实", "根因假设", "证伪证据", "置信度",
            "症状边界", "归属边界", "下游边界",
        ]:
            self.assertIn(term, text)
        self.assertIn("复现失败", text)
        self.assertIn("预测成功修正", text)
        self.assertIn("保留多个假设", text)

    def test_evidence_scope_prevents_host_workspace_contamination(self):
        text = REFERENCE.read_text(encoding="utf-8")
        for term in ["证据作用域", "评测场景", "宿主工作区", "不得导入", "未知项"]:
            self.assertIn(term, text)
        skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        self.assertIn("证据作用域", skill)
        self.assertIn("宿主项目记忆", skill)

    def test_solution_and_execution_contracts_close_the_old_route(self):
        text = REFERENCE.read_text(encoding="utf-8")
        for route in ["症状补丁", "稳定闭环", "权威重构"]:
            self.assertIn(route, text)
        for field in ["要消除的未知", "保留风险", "回滚点", "验收证据"]:
            self.assertIn(field, text)
        self.assertIn("即使某类不适用，也必须列出三行", text)
        self.assertIn("不得省略或移到表外", text)
        for guard in ["更多重试", "更宽回退", "更多 Mock"]:
            self.assertIn(guard, text)
        for step in range(1, 11):
            self.assertRegex(text, rf"(?m)^{step}\. ")
        for evidence in ["所有者级失败测试", "真实路径回归门禁", "故障注入", "禁止下游调用"]:
            self.assertIn(evidence, text)

    def test_output_template_and_acceptance_keep_claims_bounded(self):
        reference = REFERENCE.read_text(encoding="utf-8")
        template = (ROOT / "templates" / "RETROSPECTIVE.md").read_text(encoding="utf-8")
        slots = [
            "失败签名与生命周期阶段", "证据阶梯", "身份矩阵", "假设与证伪台账",
            "失败路线台账", "选定方案与拒绝方案", "执行顺序与回滚点",
            "验收矩阵", "剩余未知项",
        ]
        for slot in slots:
            self.assertIn(slot, reference)
            self.assertIn(slot, template)
        for gate in [
            "首次保存", "多次单字段编辑并保存", "未修改保存", "最新编辑获胜",
            "关闭并重开", "重启", "安全 trace", "真实用户",
        ]:
            self.assertIn(gate, reference)
        self.assertIn("更窄的结论", reference)
        self.assertIn("不得自动扩大", reference)

    def test_pressure_evals_require_owner_diagnosis_and_narrow_claims(self):
        payload = json.loads((ROOT / "evals" / "evals.json").read_text(encoding="utf-8"))
        cases = {case["id"]: case for case in payload["evals"]}
        self.assertTrue({21, 22, 23}.issubset(cases))
        combined = json.dumps([cases[21], cases[22], cases[23]], ensure_ascii=False)
        for term in ["归属边界", "证伪", "失败路线", "真实路径", "不得扩大"]:
            self.assertIn(term, combined)


if __name__ == "__main__":
    unittest.main()
