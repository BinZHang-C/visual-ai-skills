import json
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]


class EvalAssetTests(unittest.TestCase):
    def test_functional_evals_cover_required_scenarios(self):
        payload = json.loads((ROOT / "evals" / "evals.json").read_text(encoding="utf-8"))
        self.assertEqual("visual-ai-development-governance", payload["skill_name"])
        self.assertEqual(32, len(payload["evals"]))
        required = {"id", "prompt", "expected_output", "files", "expectations"}
        for case in payload["evals"]:
            self.assertEqual(required, set(case))
            self.assertGreaterEqual(len(case["expectations"]), 4)
        ids = {case["id"] for case in payload["evals"]}
        self.assertEqual(set(range(1, 33)), ids)

        cases_by_id = {case["id"]: case for case in payload["evals"]}
        local_edit = json.dumps(cases_by_id[10], ensure_ascii=False)
        for term in ["局部修改", "蒙版", "完整形体", "植物"]:
            self.assertIn(term, local_edit)

        style_transfer = json.dumps(cases_by_id[11], ensure_ascii=False)
        for term in ["风格迁移", "专家提示词", "读取", "保存"]:
            self.assertIn(term, style_transfer)

        lifecycle_cases = json.dumps([cases_by_id[index] for index in range(12, 21)], ensure_ascii=False)
        for term in ["绑定", "取消", "恢复", "验收", "偏航", "重开", "旧项目", "Provider", "交接"]:
            self.assertIn(term, lifecycle_cases)

        repeated_failure_cases = json.dumps([cases_by_id[index] for index in range(21, 24)], ensure_ascii=False)
        for term in ["归属边界", "证伪", "失败路线", "真实路径", "不得扩大"]:
            self.assertIn(term, repeated_failure_cases)

        lightweight_memory_cases = json.dumps([cases_by_id[index] for index in range(24, 28)], ensure_ascii=False)
        for term in ["问题签名", "冻结", "影响与验收回执", "不读取完整聊天历史", "未验证风险"]:
            self.assertIn(term, lightweight_memory_cases)

        canary_cases = json.dumps([cases_by_id[index] for index in range(28, 33)], ensure_ascii=False)
        for term in [
            "canary",
            "打 QA 包",
            "费用",
            "Candidate",
            "Stable",
            "Rollback",
            "Gateway",
            "API",
            "Workflow",
            "派生",
            "第五个",
        ]:
            self.assertIn(term, canary_cases)

    def test_trigger_evals_are_balanced_and_near_match(self):
        cases = json.loads((ROOT / "evals" / "trigger-evals.json").read_text(encoding="utf-8"))
        self.assertEqual(40, len(cases))
        self.assertEqual(20, sum(1 for case in cases if case["should_trigger"]))
        self.assertEqual(20, sum(1 for case in cases if not case["should_trigger"]))
        for case in cases:
            self.assertEqual({"id", "query", "should_trigger", "rationale"}, set(case))
            self.assertGreater(len(case["query"]), 20)
        trigger_text = json.dumps(cases, ensure_ascii=False)
        for term in ["取消", "费用", "验收", "偏航", "旧项目", "Provider"]:
            self.assertIn(term, trigger_text)
        by_id = {case["id"]: case for case in cases}
        self.assertEqual({"P17", "P18", "P19", "P20"}, {case_id for case_id in by_id if case_id.startswith("P")})
        self.assertEqual({"N17", "N18", "N19", "N20"}, {case_id for case_id in by_id if case_id in {"N17", "N18", "N19", "N20"}})

    def test_rubric_and_review_document_human_control(self):
        rubric = (ROOT / "outputs" / "2026-08-13-visual-ai-development-governance-eval-rubric.md").read_text(encoding="utf-8")
        for term in ["1–5", "路线更短", "关键冲突", "低打扰", "人类控制权", "适配器", "越权执行"]:
            self.assertIn(term, rubric)

    def test_current_review_is_authoritative_for_repeated_failure_extension(self):
        rubric = (ROOT / "outputs" / "2026-08-15-visual-ai-development-governance-eval-rubric.md").read_text(encoding="utf-8")
        review = (ROOT / "outputs" / "2026-08-15-visual-ai-development-governance-skill-review.md").read_text(encoding="utf-8")
        for term in ["功能评测 1–23", "三组配对压力场景", "边界归属", "真实路径门禁", "有限结论"]:
            self.assertIn(term, rubric)
        for term in ["32 项测试", "23 个功能评测", "已安装", "关闭重开", "重启", "Provider", "未验证"]:
            self.assertIn(term, review)


if __name__ == "__main__":
    unittest.main()
