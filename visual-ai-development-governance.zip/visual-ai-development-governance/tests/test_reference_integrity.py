from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
REFERENCES = [
    "governance-loop.md",
    "lifecycle-event-map.md",
    "failure-taxonomy.md",
    "readiness-standards.md",
    "git-readiness.md",
    "cleanup-guidance.md",
    "repeated-failure-closure.md",
    "lightweight-development-memory.md",
    "canary-first-development-governance.md",
    "capability-routing-governance.md",
    "image-envelope-first-failure-closure.md",
]


class ReferenceIntegrityTests(unittest.TestCase):
    def test_reference_files_are_routed_and_bounded(self):
        texts = {}
        for name in REFERENCES:
            path = ROOT / "references" / name
            self.assertTrue(path.exists(), f"missing {name}")
            text = path.read_text(encoding="utf-8")
            texts[name] = text
            self.assertIn("## 何时读取", text)
            self.assertIn("## 不要做什么", text)
            self.assertNotIn("TBD", text)
            self.assertNotIn("TODO", text)

        readiness = texts["readiness-standards.md"]
        for state in ["探索中", "可继续开发", "接近可交付", "达到通行标准"]:
            self.assertIn(state, readiness)
        self.assertIn("不是开发许可", readiness)

        git_text = texts["git-readiness.md"]
        self.assertIn("只读", git_text)
        self.assertIn("人类", git_text)
        self.assertIn("Commit 前", git_text)
        self.assertIn("Push 或 PR 前", git_text)
        self.assertIn("Merge 前", git_text)

        cleanup = texts["cleanup-guidance.md"]
        for category in ["保留", "隔离归档", "删除候选"]:
            self.assertIn(category, cleanup)
        self.assertIn("默认优先隔离归档", cleanup)

        lifecycle = texts["lifecycle-event-map.md"]
        for stage in ["需求与权威", "产品路线", "人类操作", "工作流执行", "结果验收", "迭代与恢复", "并行集成与发布", "生产环境与外部能力"]:
            self.assertIn(stage, lifecycle)
        for dimension in ["人类动作", "产品影响", "真实证据", "成果通行标准"]:
            self.assertIn(dimension, lifecycle)

        skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        self.assertIn("lifecycle-event-map.md", skill)
        self.assertIn("image-envelope-first-failure-closure.md", skill)

        envelope = texts["image-envelope-first-failure-closure.md"]
        for term in [
            "FIRST_FAILURE_BOUNDARY",
            "Base64",
            "DNS/transport",
            "request/input-too-large",
            "execution receipt",
        ]:
            self.assertIn(term, envelope)


if __name__ == "__main__":
    unittest.main()
