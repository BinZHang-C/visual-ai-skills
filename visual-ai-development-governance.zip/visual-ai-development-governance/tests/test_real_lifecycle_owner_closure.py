from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
SKILL = ROOT / "SKILL.md"
REPEATED = ROOT / "references" / "repeated-failure-closure.md"
ROOT_CAUSE = ROOT / "references" / "root-cause-completeness-and-human-qa-budget.md"
LIFECYCLE = ROOT / "references" / "lifecycle-event-map.md"
RETROSPECTIVE = ROOT / "templates" / "RETROSPECTIVE.md"


class RealLifecycleOwnerClosureTests(unittest.TestCase):
    def test_root_skill_routes_real_behavior_failures_to_the_closure(self):
        text = SKILL.read_text(encoding="utf-8")
        for term in [
            "REAL_LIFECYCLE_OWNER_CLOSURE",
            "真实版本", "userData", "第一个缺失事件", "真实行为 RED",
            "最小 owner", "预测的下一事件", "下游仍为零", "空缓存隔离 QA",
        ]:
            self.assertIn(term, text)

    def test_repeated_failure_contract_requires_one_falsifiable_owner_loop(self):
        text = REPEATED.read_text(encoding="utf-8")
        required_in_order = [
            "锁定真实版本与 userData",
            "完整生命周期事件图",
            "最后成功事件 / 第一个缺失事件",
            "每轮只提出一个可证伪假设",
            "真实行为 RED",
            "修改最小 owner",
            "预测的下一事件真实出现",
            "禁止下游仍为零",
            "混合输入/并发/重入反例",
            "独立 P0/P1/P2 复审",
            "空缓存隔离 QA 真人验收",
        ]
        positions = [text.index(term) for term in required_in_order]
        self.assertEqual(positions, sorted(positions))

    def test_root_cause_and_lifecycle_define_evidence_and_stop_conditions(self):
        root_cause = ROOT_CAUSE.read_text(encoding="utf-8")
        lifecycle = LIFECYCLE.read_text(encoding="utf-8")
        for term in ["ONE_FALSIFIABLE_HYPOTHESIS", "REAL_BEHAVIOR_RED", "NEXT_EVENT_PREDICTION", "DOWNSTREAM_ZERO"]:
            self.assertIn(term, root_cause)
        for term in ["REAL_VERSION_LOCK", "USERDATA_LOCK", "最后成功事件", "第一个", "缺失事件"]:
            self.assertIn(term, lifecycle)

    def test_retrospective_captures_the_closure_receipt(self):
        text = RETROSPECTIVE.read_text(encoding="utf-8")
        for term in [
            "真实版本与 userData 锁定", "事件图与首个缺失事件", "单一可证伪假设",
            "真实行为 RED", "最小 owner", "下一事件预测", "下游为零",
            "混合输入/并发/重入", "P0/P1/P2", "空缓存隔离 QA 真人验收",
        ]:
            self.assertIn(term, text)

    def test_owner_proof_gate_is_a_fail_closed_state_machine(self):
        skill = SKILL.read_text(encoding="utf-8")
        repeated = REPEATED.read_text(encoding="utf-8")
        for state in [
            "IDENTITY_UNPROVEN", "BOUNDARY_UNPROVEN", "OWNER_CANDIDATE", "OWNER_PROVEN",
        ]:
            self.assertIn(state, skill)
        for gate in [
            "身份门", "边界门", "假设门", "RED 门", "Owner 门", "预测门", "零副作用门",
            "对抗门", "独立复审门", "真人门",
        ]:
            self.assertIn(gate, repeated)
        self.assertIn("OWNER_PROVEN", repeated)
        self.assertIn("不能称为根因", repeated)


if __name__ == "__main__":
    unittest.main()
