# Git overlap fixture

The test creates an isolated temporary repository from this seed and verifies read-only inspection.
